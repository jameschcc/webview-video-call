<?php

// msg definitions
define('MSG_S2C_NEWCALL', 1);
define('MSG_S2C_TERMINATECALL', 2);
define('MSG_S2C_REJECT', 3);
define('MSG_S2C_AUDIT', 4);

define('MSG_C2S_STARTCALL', 1);
define('MSG_C2S_ENDCALL', 2);
define('MSG_C2S_REJECT', 3);
define('MSG_C2S_AUDITACK', 4);
define('MSG_C2S_HEARTBEAT', 5);

// state definitions
