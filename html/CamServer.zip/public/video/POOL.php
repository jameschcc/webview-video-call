<?php
namespace app\http\controller;

require_once "vendor/autoload.php";

use PHPSocketIO\SocketIO;
use Workerman\Worker;

function log($msg, $isError=false)
{
    $trimmedMsg = preg_replace('/\s/', ' ', $msg);
    $trimmedMsg= ($isError?'ERROR: ':'INFO: ').$trimmedMsg;
    // $isError ? $trimmedMsg='ERROR: '.$trimmedMsg : null;
    $date=date('Y-m-d'); $time=date('Y-m-d h:i:s ## ');
    $m = "$time $trimmedMsg\n";
    print_r($m."\n");
    file_put_contents("log/pool-$date.log", "$m", FILE_APPEND);
}

class Server
{
    public $s2cMsgs, $serverMsgsTranslations;
    public function sendMsg($uniq, $msgType, $strOrObj) {
        if($uniq)
            $sender_io->to($to)->emit('new_msg', $content);
        else
            $sender_io->emit('new_msg', $content);
    }
    public function init()
    {
        if(!is_file("/usr/share/nginx/html/logs/socketlogs/log_of_POOL.log"))
        {
            file_put_contents("/usr/share/nginx/html/logs/socketlogs/log_of_POOL.log",'');
        }
        $this->s2cMsgs = json_decode('{"tellRing":["uniq","callId"],"tellAnswer":["uniq","callId"],"tellDevListUpdate":[],"tellCallClear":["callId"],"tellPcUpdate":["uniq","callId"],"tellAudit":[],"tellReject":["uniq","callId"],"tellCandidates":["callId", "candidates"],"disconnect":["uniq"]}');

        $this->serverMsgsTranslations = json_decode('{"tellRing":"msgCallRing","tellAnswer":"msgCallAnswer","tellDevListUpdate":"msgDeviceListUpdate","tellCallClear":"msgCallClear","tellPcUpdate":"msgCallPcUpdate","tellAudit":"msgAudit","tellReject":"msgReject","tellCandidates":"msgAddCandidates","disconnect":"disconnect"}');
    }

    ////////////
    // sendRslt($http_connection, $code, $objOrMsg)
    // returns: bool
    // input:   code(0=success, 1=fail), rsltMsg(message if fail, or obj or null if ok)
    public function sendRslt($http_connection, $code, $objOrMsg=null)
    {
        return $http_connection->send(json_encode(array('code'=>$code, 'rslt'=>$objOrMsg)));
    }


public function geturl($url){
        log($url);
        $headerArray =array("Content-type:application/json;","Accept:application/json");
                    log("HER0A...");
        $ch = curl_init();
                    log("HERE1A...");
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE); 
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE); 
        curl_setopt($ch, CURLOPT_TIMEOUT, 1); 
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_HTTPHEADER,$headerArray);
                    log("HEREA...");
        // log("curl error:".curl_errno($ch).','.curl_error($ch).','.curl_strerror($ch));
                    $output = FALSE;
                    log("HEREB...");
                    try{
        $output = curl_exec($ch);
        }        catch (\Exception $e)
        {
                    echo $e->getMessage();
                    log($e->getMessage());
                    log("EXCEP...");
        }
                    log("HEREC...");
        // log("curl error:".curl_errno($ch).','.curl_error($ch).','.curl_strerror($ch));
                    log("HERED...");

        curl_close($ch);
                    log("HEREE...");
        if($output !== FALSE)
        $output = json_decode($output,true);
                    log("HEREF...");
        return $output;
}

    public function server()
    {
        $this->init();
        header(200);
        $uniqConnectionMap = array();
        $last_online_count = 0;
        $last_online_page_count = 0;
        $sender_io = new SocketIO(2120);
        $that = &$this;
        $sender_io->on('connection', function ($socket) use ($sender_io, $that) {

            $socket->on('login', function ($uniq) use ($socket, $sender_io, $that) {
                global $uniqConnectionMap, $last_online_count, $last_online_page_count;
                if (isset($socket->uniq)) {
                    $uniq = (string)$socket->uniq;
                    log('客户端恢复连接uniq=' . $uniq);
                    // return;
                }
                else
                {
                    $uniq = (string)$uniq;
                    $socket->uniq = $uniq;
                    log('客户端登录uniq=' . $uniq);
                    $socket->join($uniq);
                }

                if (!isset($uniqConnectionMap[$uniq])) {
                    $uniqConnectionMap[$uniq] = 0;
                }
                ++$uniqConnectionMap[$uniq];
                // $sender_io->emit('new_msg', json_encode(array('msgType'=>'tellDevListUpdate')));
                exec("curl --connect-timeout 2 --max-time 2 'http://localhost/callControl/inapi_fetchConnStates' >/dev/null 2>&1 -o /dev/null  & ", $out, $state);
// $out = $this->geturl('http://localhost/callControl/inapi_fetchConnStates');
                    log("(login) Notify deviceConnections update result:".json_encode(compact('out','uniqConnectionMap')));
                if($state != 0)
                    log("(login) Notify deviceConnections update FAILED:".json_encode(compact('out', 'state')));
                else
                    log("(login) Notify deviceConnections update OK.");

            });

            $socket->on('disconnect', function ($id) use ($socket, $sender_io) {
                log('客户端断开, id='.$id.", uniq=".($socket->uniq??null));
                // log('客户端断开 ' . json_encode($socket)); // this would trigger infinite loop
                if (!isset($socket->uniq)) {
                    return;
                }
                global $uniqConnectionMap;
                if (--$uniqConnectionMap[$socket->uniq] <= 0) {
                    unset($uniqConnectionMap[$socket->uniq]);
                }

                // exec("curl --connect-timeout 1 --max-time 1 'http://localhost/video/server.php?action=inapi_fetchConnStates' -o /dev/null ");
                exec("curl --connect-timeout 2 --max-time 2 'http://localhost/callControl/inapi_fetchConnStates' >/dev/null 2>&1 -o /dev/null  & ", $out, $state);
                if($state != 0)
                    log("(disconnect) Notify deviceConnections update FAILED:".json_encode(compact('out', 'state')));
                else
                    log("(disconnect) Notify deviceConnections update OK.");

                // $sender_io->emit('new_msg', json_encode(array('msgType'=>'tellDevListUpdate')));

                // $sender_io->emit('new_msg', json_encode(array('action'=>'connected')));
            });
        });



        $sender_io->on('workerStart', function () use ($sender_io, $that) {
            $inner_http_worker = new Worker('http://0.0.0.0:2121');
            $inner_http_worker->onMessage = function ($http_connection, $data) use ($sender_io, $that) {

                print_r('header='.json_encode($data->header())."\npost=".json_encode($data->post())."\nget=".json_encode($data->get())."\n");

                $urlArray = parse_url('//localhost'.$data->uri());
                if(!$urlArray || !array_key_exists('query', $urlArray))
                {
                    $uri=$data->uri();
                    echo "No query found in uri=$uri\n";
                    return $this->sendRslt($http_connection, 1, 'fail:unknown query');
                }

                global $uniqConnectionMap;
                
                //
                    //$request->get();
    //$request->post();
    //$request->header();

                // print_r($data->rawHead());

                // print_r($data->request());
                // print_r($data->uri());
                // print_r($urlArray);

                parse_str($urlArray['query'], $params);
                log(json_encode($params));
                $postData = $params;
                $to = $postData['uniq'] ?? '';

                $action = $postData['action'] ?? NULL;

                // $content = htmlspecialchars(json_encode($postData));

                print_r('-> postData:'.json_encode($postData)."\n");

                if(!$action)
                {
                    log('WssSendMsgError: no action');
                    return $this->sendRslt($http_connection, 1, 'fail:no_action');
                }

                if($action == 'getDevicesStatus') {
                    return $this->sendRslt($http_connection, 0, $uniqConnectionMap);
                }

                // print_r('$s2cMsgs');
                // print_r($s2cMsgs);
                // log(json_encode($that->s2cMsgs));
                if(!property_exists($that->s2cMsgs, $action))
                {
                    log('WssSendMsgError: unkown action='.$action);
                    return $this->sendRslt($http_connection, 1, 'fail:unkown_action');
                }

                // check parameers
                $paramCheckOk = true;
                if(count($that->s2cMsgs->$action))
                {      
                    $params = $that->s2cMsgs->$action;              
                    foreach($params as $p)
                    {
                        if(!isset($postData[$p]) || $postData[$p]===NULL)
                        {
                            log("WssSendMsgError: WssSendMsgError: action=$action lack of param:$p");
                            $paramCheckOk = false;
                        }
                    }
                }
                if(!$paramCheckOk)
                {

                    log("WssSendMsgError: param check failed for action=$action");
                    return $this->sendRslt($http_connection, 1, 'fail:param_failure');
                }

                $broadCastMsgs = array('tellAudit','tellDevListUpdate');


                // switch($action){
                //     case 'tellDevListUpdate':
                //     $postData['msgType'] = 'msgDeviceListUpdate';
                //     break;

                //     case ''

                //     default:
                //     break;
                // }
                // print_r($this->serverMsgsTranslations);
                $msgType = $this->serverMsgsTranslations->$action;

                $postData['msgType'] = $msgType;
                $content = (json_encode($postData));

                log('发送到用户to ' . json_encode($to).', msgType='.$msgType);

                if ($to) {
                    if(!isset($uniqConnectionMap[$to]))
                    {                        
                        print_r("Result==offline. :: OnlineDevices:: ");
                        print_r(json_encode($uniqConnectionMap));

                        return $this->sendRslt($http_connection, 1, 'fail:device_offline');
                    }
                    else            
                    {
                        $sender_io->to($to)->emit('new_msg', $content);
                    }
                } else {
                    if(!in_array($action,$broadCastMsgs))
                    {
                        log("WssSendMsgError: msg action=$action, but no uniq provided.");
                        print_r('Result==NotBroadCasting');
                        return $this->sendRslt($http_connection, 1, 'fail:no_uniq_provided');
                    }
                    if($uniqConnectionMap && count($uniqConnectionMap))
                        $sender_io->emit('new_msg', $content);
                }
                if($action=='disconnect')
                {
                    // $sender_io->to($to)->disconnect(); // no such function, let the user do (above sent).
                    if($uniqConnectionMap)
                    unset($uniqConnectionMap[$to]);
    // $curl = "curl 'localhost:2121?uniq=$uniq&action=$msgType".($msgObj?'&'. http_build_query($msgObj):'')."' -o /dev/null";
                }
                $r = $this->sendRslt($http_connection, 0);
            };
            $inner_http_worker->listen();
        });
Worker::$stdoutFile = "/usr/share/nginx/html/logs/socketlogs/log_of_POOL.log";
Worker::runAll();
}
}
$s = new Server();
$s->server();
