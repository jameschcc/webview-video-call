<?php
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximun-scale=1">
	<title></title>
    <script src='/common/js/jquery-3.7.1.min.js'></script>
    <script src='/common/js/socket.io.js'></script>
    <script src='/common/js/vue.js'></script>
</head>
<body>
    <div id="appSection">
        <div id="left">
            <div id="message">{{warnOrErr}}</div>
            <div id="vOtherSection">
                远端视频
                <video autoplay playsinline id="videoMain"></video>
            </div>
        </div>
        <div id="right">
            <div id='myInfo'>
                本端: {{myUuid}}     
                <div id="vSelfSection">
                    <video autoplay playsinline muted id="videoSelf"></video>
                </div>           
            </div>

            <div id="devListSection">
                <ul id="devList"  v-if='devList.length'><li v-for='i,idx in devList' :class='(i.selected?"selected":"") + " " + i.ustate' @click='selectUser(i.uuid)'>{{i.uname}}-{{i.id}} ({{i.uuid}}) {{i.uuid==myUuid?'(me)':''}} {{i.ustate}} </li></ul>
                <!--  ({{i.sessionStr}})  -->
            </div>
            <div id='btnArea'>
                <button id="theBtn" :class="btn.disabled?'disabled':''" @click='btnClicked'>{{btn.txt}}</button>
                <!-- <button :class="btnAnswer.disabled?'disabled':''" :click='btnClicked'>{{btn.txt}}</button>  -->
                <div>{{information}}</div>
                <div id="conInfoDiv">{{connectInformation}}</div>
                <audio id="audio" playsinline><source src id="audioSrc" type="audio/mpeg"/></audio>
                <audio id="audioDudu" src='/common/mp3/dudu.mp3' playsinline></audio>
                <audio id="audioRing" src='/common/mp3/ring.mp3' playsinline></audio>
            </div>

        </div>
    </div>

    <style type="text/css">
        /* background: repeating-linear-gradient( 45deg, #ffffff, #ffffff 10px, #fff 10px, #eee 20px ); */
        html {
            font-size: .625em;
        }
        body {font-size: 1.4rem;}
        html, body {margin: 0; display: flex;font-family: PingFangJetBrains, 'PingFang SC',Consolas; font-size: 14px;}
        body #left  {flex: 2; display: flex; flex-direction: column-reverse;    align-items: center; justify-content: center;}
        body #right {flex: 1; overflow: hidden; background: #eee;display: flex; flex-direction: column; padding: 1.5vw;}
        body #left #vOtherSection {}
        body #left #vOtherSection {
            width: 100%;overflow: hidden;
        }
        button.disabled {opacity: 0.5}
        div#btnArea {
            display: flex;
            flex-direction: column;
        }

        button#theBtn {padding: .4em .6em; cursor: pointer;    display: block; width: 100%; -webkit-apperance:none; border:1px solid; }
        button#theBtn.disabled {opacity: 0.5; cursor: not-allowed;}
        #right ul#devList {padding: 0; margin: 0}
        #right li {border-bottom: 1px solid silver; padding: 1vw; list-style: none;}
        li.selected {background: #ddd;}
        video {background: gray; width: 100%;}
        #appSection {display: flex; width: 100vw; height: 100vh;}
        #conInfoDiv {align-self: flex-end; margin-top: auto;}
        li.OFFLINE {color:#ddd;}
        video#videoMain:before {
            content: '远端视频';
        }video#videoSelf:before {
            content: '本端视频';
        }
        ul#devList:before {
            content: '用户列表';
        }
        #devListSection {overflow-y: auto;}
#videoMain {
    max-width: 100%;
    max-height: 100%;}

        @media screen and (orientation: portrait) {
            body #appSection {flex-direction: column;}
            body #left  {flex: 5}
            body #right {flex-direction: row; }
            body #right div, body #right ul {overflow-y: scroll;}
            #myInfo {flex:1;}
            #devListSection {flex:3;}
        }
        @media (min-aspect-ratio: 8/5) {
            body #left  {flex: 3;}
        }

    </style>
    <!-- <script src="https://cdn.bootcss.com/notify.js/3.0.0/notify.js"></script> -->
    <script>
        let socket;
        const vSelf = document.getElementById('videoSelf');
        let vOther= document.getElementById('videoMain');
        let callState;
        let uuid = parseInt(Math.random()*1000000).toString(16);
        let regState = false;
        let pc = null
        let localStream

        let answerSdp = null;
        let offerSdp  = null;
        let candidates = []

        let audio = document.getElementById('audio')
        let audioRing = document.getElementById('audioRing')
        let audioDudu = document.getElementById('audioDudu')
        let audioSrc = document.getElementById('audioSrc')
        let callId
        let serverBase = '/video/'
        let serverUrl = serverBase+'server.php'
        let candidateTimer = 0
        let candidatesFromRemote = []
        let processingRmCandidates = false
        let rmCandidates = null
        let jobs = []
        let callConnected = false
        // rtc related
        const offerOptions = {
            offerToReceiveAudio: 1,
            offerToReceiveVideo: 1
        };
        console.log( vSelf == document.getElementById('videoSelf'))
        function onCreateSessionDescriptionError(error) {
            console.log(`Failed to create session description: ${error.toString()}`);
        }

        function setPc() {
            console.log( vSelf == document.getElementById('videoSelf'))

            pc.onicecandidate = async e => {
                const message = {
                    type: 'candidate',
                    candidate: null,
                };
                await console.log(`new candidate: ${e.candidate}. my processingRmCandidates=${processingRmCandidates}`)
                if(processingRmCandidates)
                    return

                if (e.candidate) {
                    message.candidate = e.candidate.candidate;
                    message.sdpMid = e.candidate.sdpMid;
                    message.sdpMLineIndex = e.candidate.sdpMLineIndex;
                    console.log(`new candidate: ${e.candidate}`)
                            // console.log(e.candidate)
                }
                candidates==null ? candidates=[message] : candidates.push(message)
                if(candidateTimer)
                    clearTimeout(candidateTimer);
                candidateTimer = setTimeout(postCadidates,1000)
                        // signaling.postMessage(message);
            };
            let remoteVideo = document.getElementById('videoMain');
            pc.ontrack = e => remoteVideo.srcObject = e.streams[0];
            pc.onsignalingstatechange = e=>{
                console.log("onsignalingstatechange = "+pc.signalingState);
                switch (pc.signalingState) {
                case "stable":
                    doJobs()
                    break;
                }
            }
                    // localStream.getTracks().forEach(track => pc.addTrack(track, localStream))
        }

        // app related

        let app = new Vue({
            el:'#appSection',
            data:{devList:[], btn:{disabled:true,txt:'Wait',class:''}, selection:null, myUuid:uuid, information:null, connectInformation:null, warnOrErr:null},
            methods:{
                selectUser: function(uuid) {
                    if(callId)
                        return
                    app.devList.forEach(i=>{ if(i.uuid!=uuid) i.selected = false; })
                    let hasSelect = false;
                    app.devList.forEach(i=>{
                        if(i.uuid==uuid && !hasSelect && i.ustate != 'OFFLINE') {
                            i.selected = (i.hasOwnProperty('selected')) ? !i.selected : true;
                            if(i.selected) {
                                app.selection=i
                                hasSelect = true;
                            }
                        }
                    })
                    if(!hasSelect)
                        app.selection = null
                    console.log(app.selection)
                            // app.btn.disabled = hasSelect?false:true;
                    setBtn('Call')
                },
                btnClicked: async ()=>{
                    console.log( vSelf == document.getElementById('videoSelf'))
                    if(app.btn.disabled)
                        return
                    switch(app.btn.txt)
                    {
                    case 'Call':
                        {
                            pc  = new RTCPeerConnection(null);
                            setPc()
                            navigator.mediaDevices.getUserMedia({video: true})
                            // navigator.mediaDevices.getUserMedia({audio: {echoCancellation:true}, video: true})
                            .then((media)=>{
                                console.log(media)
                                localStream = media
                                        // console.log(localStream)
                                localStream.getTracks().forEach(track => pc.addTrack(track, localStream))
                                    // vSelf.srcObject = localStream;
                                pc.createOffer (offerOptions)
                                .then(
                                    (description)=>{
                                        console.log(`got offer=${description}`)
                                        pc.setLocalDescription(description);
                                        startCall(description)
                                    }, onCreateSessionDescriptionError
                                    )
                                .catch(e=>{
                                    console.log(e)
                                    console.error(`fail to createOffer ${e}`)
                                    warnErr('fail to createOffer')
                                    pc.close()
                                    pc = null;
                                })

                            })
                            .catch(e=>{
                                console.error(`fail to get media`)
                                console.log(e)
                                warnErr('fail to get media')
                                pc.close()
                                pc = null;

                            })
                        }
                        break;
                    case 'Answer':
                        {
                            pc  = new RTCPeerConnection(null);
                            setPc()
                            app.needAnswer = false

                            navigator.mediaDevices.getUserMedia({audio: true, video: true})
                            .then((media)=>{
                                console.log(media)
                                localStream = media
                                console.log( vSelf == document.getElementById('videoSelf'))

                                document.getElementById('videoSelf').srcObject = localStream
                                console.log( vSelf == document.getElementById('videoSelf'))

                                localStream.getTracks().forEach(track => pc.addTrack(track, localStream))
                                ;
                                let theOtherPc = offerSdp
                                pc.setRemoteDescription(theOtherPc)
                                .then(()=>{return pc.createAnswer(offerOptions)})
                                .then((description)=>{
                                    answerSdp = description
                                    console.log(answerSdp)
                                    return pc.setLocalDescription(description)
                                }, onCreateSessionDescriptionError)
                                .then(()=>{sendAnswer(answerSdp)})
                            }).catch()


                        }
                        break;
                    case 'EndCall': 
                        {
                            clearCall(callId)
                        }
                        break;

                    case 'Waiting...':
                        break;

                    default:
                        console.error('Unkown btn event: ' + app.btn.txt)
                        break;
                    }

                }
            },
            created:()=>{}
        })

const clearPc = ()=>{
    if(pc)
    {
        pc.close();
        pc = null;
    }
}
const clearLocalStream = ()=>{
    if(localStream)
    {
        localStream.getTracks().forEach(t=>{localStream.removeTrack(t) ;  t.stop()})
        localStream=null;
        let vSelf = document.getElementById('videoSelf')
        console.log( vSelf == document.getElementById('videoSelf'))

        vSelf.srcObject = null;
        vSelf.pause() ; vSelf.currentTime = 0;
    }
}
const clearCall = (callIdToClear, notifyOther)=>{
    return new Promise((resolve,reject)=>{
        clearPc();
        if(!callIdToClear)
        {
            console.error('clearCall triggered without callId')
            resolve()
        }
        else
            jQuery.post(serverUrl+'?action=api_callEnd', {callId:callIdToClear}, function(res){
                if(res.code==0)
                {
                    resetAppFlags()
                    clearLocalStream()
                    resolve(res)
                    clearMainVideo()
                }
                else
                {
                    console.log(res.msg)
                    reject(res)
                }
            },'JSON')
    })
}

const connectWss = async ()=>{
            // $uid = "1";
    return new Promise((rs,rj)=>{
        socket = io("", { path: '/socket.io/' });
        socket.on('new_msg', async msg => {await handleMsg(msg)})    
        socket.on('connect', function () {
            console.log('连接成功');
            app.connectInformation = '连接成功'
            app.btn.txt = 'Call'
            socket.emit('login', uuid);
            rs()
        });
        socket.on('disconnect', function () {
            if(!uuid)
                return
            console.log('正在连接..');``
            app.connectInformation = '正在连接..'
            // socket.emit('login', uuid);
            // rs()
        });
                // socket.on('connection', function () {
                //     console.log('连接成功');
                //     socket.emit('login', uuid);
                // });
    })
}

const handleMsg = async msg =>  {
    console.log(msg)
    let msgObj = JSON.parse(msg)
    console.log(msgObj)

    switch(msgObj.msgType)
    {
    case 'msgCallRing':
        if(callState == 'busy')
        {
            jQuery.get(serverUrl+'?action=api_reject')
            uploadState();
            console.error('Got callRing but im busy.')
            return
        }
        if(!msgObj.hasOwnProperty('callId') || !msgObj.callId)
        {
            console.error('Got callRing but no callId provided.')
            break;
        }
        callId = msgObj.callId;
        jQuery.post(serverUrl+'?action=api_getOffer',{callId:callId},
            function(res){
                console.log('got call offer response:')
                console.log(res)
                if(res.code)
                {
                    abortCall(callId)
                    result()
                }
                else
                {
                    offerSdp = JSON.parse(res.obj.offer)
                    setBtn('Answer')
                    app.needAnswer = true
                    audioPlay('ring')
                }
            }
            )
        break;

    case 'msgCallAnswer':
        if(!msgObj.hasOwnProperty('callId') || !msgObj.callId)
        {
            console.error('Got callAnswer but no callId provided.')
            break;
        }
        callId = msgObj.callId;
        audioPlay('stopDudu')
        jQuery.post(serverUrl+'?action=api_getAnswer',{callId:callId},
            function(res){
                console.log('got call answer response:')
                console.log(res)
                if(res.code)
                {
                    abortCall(callId)
                    result()
                }
                else
                {
                    answerSdp = JSON.parse(res.obj.answer)
                    answerGot(answerSdp)
                    // callConnected = true
                }
            }
            )
        break;

    case 'msgDeviceListUpdate':
        refreshDeviceList()
        break;

    case 'msgCallClear':
        clearPc()
        clearLocalStream()
        clearMainVideo()
        // vOther.currentTime = 0;
        setBtn('Call')
        audioPlay('stop')
        callId = 0
        break;

    case 'msgCallPcUpdate':
        callId = msgObj.callId;
        break;

    case 'msgAddCandidates':
        processingRmCandidates = true
        console.log('processingRmCandidates::')
        console.log(`pc:=${pc}`)
        if(pc && pc.signalingState=='stable')
            await loadRemoteCandidates(msgObj)
        else{
            jobs.push('loadRemoteCandidates')
            console.log(msgObj)
            rmCandidates = msgObj
        }
        break;

    case 'msgAudit':
        break;
    case 'disconnect':
        if(pc)
        {
            pc.close();
            pc = null;
        }
        clearLocalStream()
        app.myUuid = null;
        uuid = null;
        app.information = 'This session has been closed.'
        socket.close()
        break;
    }
};

const resetAppFlags = ()=>{
                    app.needAnswer = false
                    setBtn('Call')
                    audioPlay('stop')
                    callId = null
}

const clearMainVideo = ()=>
{
    let v =  document.getElementById('videoMain')
    v.pause()
    v.srcObject = null
}
const clearSelvVideo = ()=>
{
    let v =  document.getElementById('videoSelf')
    v.pause()
    v.srcObject = null
}

const warnErr = msg=>{
    app.warnOrErr = msg
    setTimeout(()=>{app.warnOrErr=null}, 3000)
}


function doJobs()
{
    jobs.forEach(i=>{
        switch(i){
        case 'loadRemoteCandidates':
            loadRemoteCandidates(rmCandidates)
            break;
        default:
            console.error('Unkown job to do:'+i)
        }
    })
}

function abortCall(callId) {
    if(callId) {
                // tobedone
        if(pc)
            pc.close()
        clearLocalStream()
    }
}
async function handleCandidate(candidate) {
    if (!pc) {
        console.error('no peerconnection');
        warnErr('no peerconnection')

        return;
    }
    if (!candidate.candidate) {
        await pc.addIceCandidate(null);
    } else {
        await pc.addIceCandidate(candidate);
    }
}

async function enterStable()
{
    doJobs()
}
// calling party gor answer from remote side
async function answerGot(answerSdp) {
    pc.setRemoteDescription(answerSdp)
}

const notifyCandidateUpdate = (candidate)=>
{
    jQuery.post(serverUrl+'?action=api_updateCandidate',{callId:callId, candidate:candidate},function(res){
        if(res.code>0)
        {
            // fail to notify, restart timer and try another notify
            console.error(res.msg)
            if(candidateTimer)
                clearTimeout(candidateTimer)
            candidateTimer = setTimeout(notifyCandidateUpdate,5000)
        }
        else
        {
            if(candidateTimer)
                clearTimeout(candidateTimer)
        }
    },'JSON')
}

function refreshDeviceList(){
    jQuery.get(serverUrl+'?action=api_fetchdevices',function(res){
        console.log(res)
        if(res.code==0)
        {
            console.log(window)
            let devList = res.obj
            devList.forEach(i=>{i.selected = false;})
            console.log(devList)
            app.devList = devList
                    // Vue.set(app,'devList', devList)
        }
    },'JSON')
}

const uploadState = ()=>{
    jQuery.post(serverUrl+'?action=api_auditack',{state:callState},function(res){
        if(!res.code==0)
            console.error(res.msg)
    },'JSON')
}

const sendHeartBeat = ()=>{
    jQuery.post(serverUrl+'?action=api_heartbeat',{state:callState},function(res){
        if(!res.code==0)
            console.error(res.msg)
    },'JSON')
}

const startCall = (offer)=>{
    console.log(`selection: ${app.selection}`)
    console.log(`selection uuid=${app.selection.uuid}`)
    console.log(offer)
    if(!offer || !offer.sdp || !offer.type=='ofer')
        return abortCalling()
    jQuery.post(
        serverUrl+'?action=api_startCall',
        {offer:JSON.stringify({'type':offer.type, 'sdp':offer.sdp}), calledUuid:app.selection.uuid},
        function(res){
            if(!res.code==0)
            {
                abortCalling()
                console.error(res.msg)
                return
            }
            else
            {
                if(!res.obj.hasOwnProperty('callId') || !res.obj.callId)
                {
                    console.error('no callId got')
                    abortCalling()
                    return
                }
                else
                {
                    callId = res.obj.callId
                    document.getElementById('videoSelf').srcObject = localStream
                setBtn('EndCall')                                // vSelf.srcObject = localStream
                audioPlay('dudu')
            }
        }
    },
    'JSON')
    .fail(e=>{console.log(`fail to post startCall: ${e}`); abortCalling()})
}

const sendAnswer = (answer)=>{
    console.log(answer)
    if(!answer || !answer.sdp || !answer.type=='answer')
        return abortCalling()
    jQuery.post(
        serverUrl+'?action=api_answerCall',
        {answer:JSON.stringify({'type':answer.type, 'sdp':answer.sdp}), callId:callId},
        function(res){
            if(!res.code==0)
            {
                abortCalling()
                console.error(res.msg)
                return
            }
            else
            {
                if(!res.obj.hasOwnProperty('callId') || !res.obj.callId)
                {
                    console.error('no callId got')
                    abortCalling()
                    return
                }
                else
                {
                    setBtn('EndCall')
                    loadRemoteCandidates(rmCandidates)
                }
            }
        },
        'JSON')
    .fail(e=>{console.log(`fail to post anserCall: ${e}`); abortCalling()})
}

const setBtn = newState => {
    switch (newState) {
    case 'EndCall':
        app.btn.txt = newState
        app.btn.disabled = false
        break;
    case 'Call':
        app.btn.txt = newState
        app.btn.disabled = app.selection && app.selection.uuid != app.myUuid ? false : true
        break;
    case 'Answer':
        app.btn.txt = newState
        app.btn.disabled = false
        break;
    case 'Waiting...':
        app.btn.txt = newState
        app.btn.disabled = true
        break;
    default:
        console.error('Unkown btn state='+state);
        warnErr('Unkown btn state='+state)

        break
    }
}

const abortCalling = ()=>{
    audioPlay('stop')
    if(pc)
    {
        pc.close()
        pc = null
    }
    if(localStream)
    {
                        // localStream.getTracks().forEach(i=>{localStream.remot})
                        // to be done. if no calls, stop localstream.
    }
    audioPlay('stopDudu')
}

                // audio.onload = ()=>{audio.play();}
const audioPlay = type => {
    switch (type)
    {
    case 'stop':
        audioDudu.pause();
        audioRing.pause();
        break;
    case 'stopDudu':
        audioDudu.pause();
        break;
    case 'stopRing':
        audioRing.pause();
        break;

    case 'dudu':
                        // audio.pause();
                        // audioSrc.src = '/common/mp3/dudu.mp3'
        audioDudu.currentTime = 0
        audioDudu.play().catch(e=>{console.log('failed to play audio dudu');console.log(e)})
        audioRing.pause()
        break;

    case 'ring':
                        // audio.pause();
                        // audioSrc.src = '/common/mp3/ring.mp3'
        audioRing.currentTime = 0
        audioRing.play().catch(e=>{console.log('failed to play audio ring');console.log(e)})
        audioDudu.pause()
        break;
    }
}
const MULTILOGIN_ERROR = 99
const register = ()=>{
    return new Promise((resolve, reject)=>{
     jQuery.post(serverUrl+'?action=api_registerDevice',{uuid:uuid},function(res){
        if(res.code==0)
        {
            regState = true;
            app.btn.txt = 'Call'
            app.myUuid = uuid
            resolve()
        }
        else
        {
            if(res.code==MULTILOGIN_ERROR)
            {
                if(true || confirm('Kick out other devices?'))
                {
                 jQuery.post(serverUrl+'?action=api_registerDevice&force',{uuid:uuid},function(res){
                    if(res.code==0)
                    {
                        console.warn(res.msg)
                        regState = true;
                        app.btn.txt = 'Call'
                        app.myUuid = uuid
                        resolve()
                    }
                    else
                    {
                        alert(res.msg)
                        reject()
                    }
                })
             }
         }
         reject()
     }
 },'JSON').fail(function(){reject()})
 })
}

const postCadidates = () => {
    if(!candidates.length)
    {
        console.log('no candidates to post')
        return
    }
    console.log('postCadidates: '+candidates.length+' candidates to post')

    jQuery.post(serverUrl+'?action=api_updateCandidate', {candidatesJson:JSON.stringify(candidates), callId:callId},function (res) {
        if(res.code)
        {
            console.error('postCadidates error: '+res.msg)
        }
        else
        {
            console.log('postCadidates ok.')
            candidates = null
        }
    },'JSON')
}

const loadRemoteCandidates = async (msgObj)=>{
    if(msgObj && msgObj.candidates)
    {
        jQuery.get(serverBase+'tmp/'+msgObj.candidates,function(res){
            res.forEach(async i=>{
                if(i.candidate)
                    await pc.addIceCandidate(i)
            })
            processingRmCandidates = false
            rmCandidates = null
        },'JSON')
        .fail(()=>{processingRmCandidates = false})
    }
}

$(document).ready(function () {
    connectWss()
    .then(register).catch(e=>{console.log(e)})
    .then(refreshDeviceList)
});
</script>
</body>
</html>