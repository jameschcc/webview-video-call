<?php
// curl -d uid=1 -d to=1 -d type=publish -d content=aaa http://localhost:2121/data=x?data&msg=yyy
function send_web_msg($to_uid = 1, $content)
{
    if (empty($content)) {
        return ["error_code" => 404, "reason" => '缺少参数'];
    }
    $push_api_url = "http://127.0.0.1:2121/?to=$to_uid&content=$content&type=publish";
    $post_data = [
        "type" => "publish",
        "content" => $content,
        "to" => $to_uid
    ];
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $push_api_url);
    curl_setopt($ch, CURLOPT_POST, 1);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_POSTFIELDS, http_build_query($post_data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, array("Expect:"));
    $return = curl_exec($ch);
    curl_close($ch);
    return $return;
}

send_web_msg(1, "test message");