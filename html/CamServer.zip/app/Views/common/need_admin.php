<div class="container">
    <div class="card border-danger mb-3" style="max-width: 80%; margin: auto;" v-if="formErrors.length" id="formErrors">
      <div class="card-header">没有权限</div>
      <div class="card-body text-danger">
        <div class="card-text">
            仅管理员可以访问此界面。请登录后重新访问。
        </div>
    </div>
</div>