<!-- Modal -->
<div id="modalAppDiv" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="modalCenterTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="modalCenterTitle">{{title}}</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
      </button>
  </div>
  <div class="modal-body">
    <p v-if="typeof content=='string'">
        {{content}}        
    </p>
    <div class="container" v-if="(typeof content=='object')">
        <ul>
            <li v-for="i,key in content">{{i}}</li>
        </ul>
    </div>
</div>
<div class="modal-footer">
    <template v-if="shallConfirm">
        <button type="button" class="btn btn-secondary" @click="yesClicked" data-dismiss="modal">确定</button>
        <button type="button" class="btn btn-secondary" @click="noClicked" v-if="rejectToDo" data-dismiss="modal">取消</button>
    </template>

    <template v-else>
        <button type="button" class="btn btn-secondary" data-dismiss="modal">关闭</button>
    </template>
    <!-- <button type="button" class="btn btn-primary">Save changes</button> -->
</div>
</div>
</div>
</div>


<script>
    var modalApp = new Vue({
        el:'#modalAppDiv',
        data:{
            content:null ,  //string or object
            title:null,

            shallConfirm:false,
            confirmToDo:null,
            rejectToDo:null,
        },
        methods:{
            notice:function(text)
            {
                this.title = '提示';
                this.content = text;
                jQuery('#modalAppDiv').modal('show')
            },
            error:function(text)
            {
                this.title = '出错了';
                this.content = text;
                jQuery('#modalAppDiv').modal('show')
            },
            confirm:function(text, yes, no)
            {
                console.log(yes)
                this.title = '出错了';
                this.content = text;
                this.shallConfirm = true;
                this.confirmToDo = yes
                this.rejectToDo = no
                jQuery('#modalAppDiv').modal('show')
            },
            reset:function(){
                this.title = '';
                this.content = '';
                this.shallConfirm = false;
                this.confirmToDo=null
                this.rejectToDo=null
                jQuery('#modalAppDiv').modal('hide')
            },
            yesClicked:function(){
                if(typeof this.confirmToDo == 'function')
                    this.confirmToDo()
                this.reset()
            },
            noClicked:function(){
                if(typeof this.rejectToDo == 'function')
                    this.rejectToDo()
                this.reset()
            }
        }
    })
    const error = txt=>{modalApp.error(txt)}


</script>