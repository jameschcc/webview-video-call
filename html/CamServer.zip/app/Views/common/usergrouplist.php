        <div>
            <p>当前共配置了<strong>{{usergroups.length}}个</strong>用户组</p>
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>编号</th>
                        <th>分组名称</th>
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="i,idx in usergroups">
                        <td>{{i.ugroupId}}</td>
                        <td>{{i.ugroupName}}</td>
                    </tr>
                </tbody>
            </table>
        </div>
