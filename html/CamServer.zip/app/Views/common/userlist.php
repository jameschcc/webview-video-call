        <div>
            <table class="table table-striped">
                <thead>
                    <tr class="table-info">
                        <th>编号</th>
                        <th>呼叫号码</th>
                        <th>名称</th>
                        <th>分组</th>
                        <th>状态</th>
                        <!-- <th>hash</th> -->
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="i,idx in users">
                        <td>{{i.uid}}</td>
                        <td>{{i.callnumber}}</td>
                        <td>{{i.uname}}
                            <button class="userEditBtn btn btn-sm btn-primary" v-on:click="startEdit(idx)">编辑</button>
                        </td>
                        <td>{{i.ugroupName}}</td>
                        <td>{{i.ustate}}</td>
                    </tr>
                </tbody>
            </table>
            <p>数量: {{users.length}}</p>
        </div>
