<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <script type="text/javascript" src="https://cam.smallar.com:9943/common_assets/js/vue.js"></script>
    <!-- <script type="text/javascript" src="file:///android_asset/files/vue.min.js"></script> -->
    <script src='https://cam.smallar.com:9943/common_assets/js/jquery-3.7.1.min.js'></script>
    <link  href='https://cam.smallar.com:9943/common_assets/bootstrap-4.0.0-dist/css/bootstrap.min.css' rel="stylesheet">
    <link  href='https://cam.smallar.com:9943/common_assets/bootstrap-icons-1.11.2/font/bootstrap-icons.min.css' rel="stylesheet">
    <script src='https://cam.smallar.com:9943/common_assets/bootstrap-4.0.0-dist/js/bootstrap.min.js'></script>

    <style type="text/css">
/*        :root {--unit:1vw;}*/
@media (orientation: landscape) {
    :root {--unit:1vh;}
    body {
        flex-direction: row;
    }
}

@media (orientation: portrait) {
    :root {--unit:1vw;}
}
body {display: flex; flex-direction: column; margin: 0; padding: 0;}
#app {display: flex; flex-direction: column; width: 100vw; height: 100vh; margin: 0; padding: 0;}
#header, #footer {display: flex;}
#main {display: flex; flex: auto; overflow-y: auto;}
#left  {width: 80vw; margin-bottom: auto; height: 100%;}
#right {width: 20vw; margin-bottom: auto; height: 100%;}

#header, #footer, #right{ background: darkblue; color: white; }
.theme-blue #header, .theme-blue #footer { background: linear-gradient(45deg, #004d8b, darkblue); }
.theme-blue #right { background: rgb(41 57 137); }

.flex_space { flex:auto; }

#header {
    display:  flex;
    align-items: center;
}
#clock_section {
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    padding: .5em 0;
}
#clock_section .timeStr {font-size: 150%;font-weight: bold;}
#clock_section .timeStr {font-weight: bold;}

#left { overflow-y:auto; 
    display: flex;
    flex-wrap: wrap;
    justify-content: center;
    align-content: space-around;
}
#left .vcard {
    padding: 2em 3em;
    border: 1px solid rgba(0, 0, 0, .0);
    margin: var(--unit);
    background: #eee;
    border-radius: var(--unit);
    background: linear-gradient(45deg, #b3fff4, #e7f3ff);
    transition: all .15s;
    cursor: pointer;
}

#left .vcard:hover {
    transform: scale(1.1);
}


.vcard .uname {font-weight: bold; font-size: 110%;}

#right {display: flex; flex-direction: column;}
#right > section, #right > .block {display: block; padding: 1em;}
#right .board {background: rgba(255,255,255,.2); margin-top: .5em}
#right .infoBlock {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: calc(var(--unit)*3) 0;
}
.infoBlock>div {max-width: 100%; padding: 0 var(--unit);}
.infoBlock * {max-width: 100%;}
.infoBlock img {max-width: 10vw;}

#header .block, #footer > .block {padding: .75em 1.5em;}
i.icon {margin-right: .5em; translate: scale(1.1);}

#footer {font-size: 125%;}

.flexRow {
    display: flex;
    flex-direction: row;
}

.block:hover {background: rgba(0, 0, 0, 0.2);}

#themeSelector .btn {margin-right: .5em}
</style>
</head>
<body>
    <div id="app" class="theme-blue">
        <div id="header">
            <div class="cols"><div class="block">音视频<br/>对讲系统</div></div>
            <div class="flex_space"></div>

            <div class="cols flexRow">
                <div class="block" v-for="block in headerBtns"  data-toggle="modal" :data-target="'#'+block.modal">
                    <i v-if="block.icon" :class="'icon bi bi-'+block.icon"></i>{{block.text}}
                </div>
            </div>
        </div>

        <div id="main">
            <div id="left">
                <div class="vcard" v-for="i in list" v-on:click="tapUser(i)">
                    <div class="uname">{{i.uname}}</div>
                    <div class="callnumber">{{i.callnumber}}</div>
                </div>
            </div>
            <div id="right">
                <div v-if="info" class="infoBlock">
                    <div class="info_src">
                        <img v-if="info.avatarSrc" :src="info.avatarSrc"/>
                        <img v-else :src="defaultAvatarSrc"/>
                    </div>
                    <div class="info_uname"  v-if="info.uname">{{info.uname}}</div>
                    <div class="info_department"  v-if="info.department">{{info.department}}</div>
                    <div class="info_callnumber"  v-if="info.callnumber">{{info.callnumber}}</div>
                    <div class="btn-group" v-if="me.callnumber != info.callnumber">
                        <div class="btn btn-success" @click="callUser(info,'video')"><i class="icon bi bi-camera-video"></i>视频呼叫</div>
                        <div class="btn btn-primary" @click="callUser(info,'audio')"><i class="icon bi bi-telephone"></i>语音</div>                        
                    </div>
                </div>
                <div class="block" v-for="block in rightBtns">
                    {{block.text}}
                </div>
                <div class="flex_space"></div>
                <div class="cols" id="clock_section">
                    <div class="timeStr">{{clock.timeStr}}</div>
                    <div class="dateStr">{{clock.dateStr}}</div>
                </div>

                <section class="board" id="sect_notifications">
                    <div class="section_title"><i class="icon bi bi-chat-dots-fill"></i>通知</div>
                    <div v-for="n in notifications">● {{n.text}}<div class="time">{{n.time}}</div></div>
                    <div v-if="!notifications || !notifications.length">暂无通知。</div>
                </section>
                <section class="board" id="sect_messages">
                    <div class="section_title"><i class="icon bi bi-exclamation-diamond-fill"></i>广播</div>
                    <div v-for="m in broadcasts">● {{m.text}}<div class="time">{{m.time}}</div></div>
                    <div v-if="!broadcasts || !broadcasts.length">暂无广播消息。</div>
                </section>
            </div>
        </div>

        <div id="footer">
            <div class="block" v-for="block in footerBtns"  data-toggle="modal" :data-target="'#'+block.modal">
                <i v-if="block.icon" :class="'icon bi bi-'+block.icon"></i>{{block.text}}
            </div>
        </div>
    </div>
</body>


<!-- ====================== modals ====================== -->
<!-- [[settings]] -->
<div class="modal fade" id="modal_settings" tabindex="-1" role="dialog" aria-labelledby="modal_settings" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">设置</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <div class="modal-body">
                <div role="group" aria-label="Basic example" id="themeSelector">
                    <h6>显示的用户组</h6>
                    <p>取消勾选的用户组将在主页和通讯录里隐藏。</p>
                    <div class="custom-control custom-switch" v-for="(g,idx) in groups">
                        <input type="checkbox" checked='false' class="custom-control-input" :id="'customSwitch'+idx">
                        <label class="custom-control-label" :for="'customSwitch'+idx">{{g.groupName}} (账户数量: {{g.users.length}})</label>
                    </div>
                </div>
            </div>

            <div class="modal-body">
                <div role="group" aria-label="Basic example" id="themeSelector">
                    <h6>主题色</h6>
                    <template v-for="(i,j) in themes">
                        <button type="button" :class="'btn btn-'+i.btnClass">{{i.desc}}</button>
                    </template>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">取消</button>
                <div class="flex_space"></div>
                <button type="button" class="btn btn-primary">保存</button>
            </div>
        </div>
    </div>
</div>

<!-- [[modal_helpers]] -->
<div class="modal fade" id="modal_helpers" tabindex="-1" role="dialog" aria-labelledby="modal_helpers" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">帮助</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div>
                    <h4>发起呼叫</h4>
                    <p>选择用户，点击视频或语音通话开始拨打用户</p>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary">关闭</button>
            </div>
        </div>
    </div>
</div>


<!-- [[modal_contacts]] -->
<div class="modal fade" id="modal_contacts" tabindex="-1" role="dialog" aria-labelledby="modal_contacts" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">通讯录</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="vcard" v-for="i in list">
                    <div class="uname">{{i.uname}}</div>
                    <div class="callnumber">{{i.callnumber}}</div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary">关闭</button>
            </div>
        </div>
    </div>
</div>

<!-- [[modal_callhistory]] -->
<div class="modal fade" id="modal_callhistory" tabindex="-1" role="dialog" aria-labelledby="modal_callhistory" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">通话记录</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="vcard" v-for="i in list">
                    <div class="uname">{{i.uname}}</div>
                    <div class="callnumber">{{i.callnumber}}</div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary">关闭</button>
            </div>
        </div>
    </div>
</div>

<!-- [[modal_messagebox]] -->
<div class="modal fade" id="modal_messagebox" tabindex="-1" role="dialog" aria-labelledby="modal_messagebox" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLongTitle">广播通知</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">

                <section class="board">
                    <div class="section_title"><i class="icon bi bi-chat-dots-fill"></i>通知</div>
                    <template v-if="notifications && notifications.length">
                        <div v-for="n in notifications">
                            <div class="time">● {{parseTs(n.ts)}}</div>
                            <p>{{n.text}}</p>
                        </div>
                    </template>
                    <div v-else>暂无通知。</div>
                </section>
                <section class="board">
                    <div class="section_title"><i class="icon bi bi-exclamation-diamond-fill"></i>广播</div>
                    <template v-if="broadcasts && broadcasts.length">
                        <div v-for="n in broadcasts">
                            <div class="time">● {{parseTs(n.ts)}}</div>
                            <p>{{n.text}}</p>
                        </div>
                    </template>
                    <div v-else>暂无通知。</div>
                </section>

            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-primary">关闭</button>
            </div>
        </div>
    </div>
</div>

<script>
    function getGroups(users){
        let groupsByGroupId = {}
        users.forEach(u=>{
            let ugroupId = u.ugroupId
            if(groupsByGroupId.hasOwnProperty(ugroupId))
                groupsByGroupId[ugroupId].users.push(u)
            else
                groupsByGroupId[ugroupId] = {users:[u], groupName:u.ugroupName}
        })
        return groupsByGroupId
    }
    function fetchUsers(){
        return new Promise((rs,rj) =>{ jQuery.get('https://cam.smallar.com:9943/callControl/api_fetchusers',res=>{
            if(res.code)
                return;
            let users = res.obj
            app.list = users
            contactsApp.setList(users)
            app.setUsers(users)
            let groups = getGroups(users)
            app.setGroups(groups)
            contactsApp.setGroups(groups)
            settingsApp.setGroups(groups)
            rs()
        },'JSON')
    })
    }
    function setNotifications(n){
        app.setNotifications(n)
        messageBoxApp.setNotifications(n)
    }
    function setBroadcasts(b){
        app.setBroadcasts(b)
        messageBoxApp.setBroadcasts(b)
    }
    const parseTs = ts => {
        let jsTs = ts*1000
        return (new Date(jsTs)).toLocaleTimeString() + ', ' + (new Date(jsTs)).toLocaleDateString()
    }

    let me = {avatarSrc:'https://cam.smallar.com:9943/common_assets/images/Avatar_blue.png', department:'手术组', uname:'手术室', callnumber:'13000000001'}
    const defaultAvatarSrc = 'https://cam.smallar.com:9943/common_assets/images/Avatar_blue.png'

    let app = new Vue({
        el:'#app',
        data:{
            list:[{uname:'1',callnumber:'1'},{uname:'2',callnumber:'2'}],
            groups:[],
            headerBtns:[
                // {name:'guide',text:'帮助',icon:'cursor-fill', modal:'modal_helpers'},
                {name:'settings',text:'设置',icon:'gear-fill', modal:'modal_settings'},
                ],
            rightBtns:[
                // {name:'broadcasts',text:'广播',icon:'broadcasts'},
                ],
            footerBtns:[
                {name:'home',text:'首页',icon:'house-fill'},
                {name:'bookmarks',text:'通讯录',icon:'person-vcard',modal:'modal_contacts'},
                {name:'history',text:'通话记录',icon:'clock',modal:'modal_callhistory'},
                {name:'broadcasts',text:'广播通知',icon:'info-square',modal:'modal_messagebox'},
                ],
            notifications:[],
            broadcasts:[],
            response:null,
            clock:{timeStr:null,dateStr:null},
            info:me,
            me:me,
            defaultAvatarSrc: defaultAvatarSrc
        },
        methods:{
            setButtons:()=>{
            },
            loadUsers:()=>{
                return fetchUsers()
            },
            setUsers:function(users){this.list = users},
            setGroups:function(groups){this.groups = groups},
            updateClock:()=>{
                let d = new Date();
                app.clock.timeStr = d.toLocaleTimeString()
                app.clock.dateStr = d.toLocaleDateString()
            },
            setNotifications:function(n){this.notifications = n},
            setBroadcasts:function(b){this.broadcasts = b},
            tapUser:u=>{
                app.info = u
            },
            parseTs:parseTs,
            callUser:(u,type)=>{
                let href = "https://cam.smallar.com:9943/client?callNumber="+me.callnumber+"&action=call&called="+u.callnumber
                if(typeof bridge == 'undefined')
                    window.location.href = href
                else
                    bridge.openCallActivity(href)
            }
        },
        created:function(){
           //  this.$http.get('https://cam.smallar.com:9943/client')
           //  .then(function(response) {
           //     console.log(response)
           //     this.response = response.data
           // })
            let that  =this
            this.loadUsers().then(()=>{
                setNotifications([{text:'手术室通知 完成后请到大厅',ts:1715527703},{text:'这是另一条手术室通知',ts:1715527303}])
                setBroadcasts([{text:'这是一条通告系统里的消息',ts:1715527705},{text:'这是另一条通告系统里的消息',ts:1715523703}])
            })
            setInterval(this.updateClock,1000)
           //  jQuery.get('https://cam.smallar.com:9943/client')
           //  .then(function(response) {
           //     console.log(response)
           //     that.response = response
           // })
        }
    })

    const contactsApp = new Vue({
        el:'#modal_contacts',
        data:{list:[], groups:{}},
        methods:{
            setList:function(list){this.list = list},
            setGroups:function(groups){this.groups = groups},
        },
        created:function(){
        }
    })
    const messageBoxApp = new Vue({
        el:'#modal_messagebox',
        data:{
            notifications:[],
            broadcasts:[],
        },
        methods:{
            setNotifications:function(notifications){this.notifications = notifications},
            setBroadcasts:function(broadcasts){this.broadcasts = broadcasts},
            parseTs:parseTs
        },
        created:function(){
        }
    })
    const callHistoryApp = new Vue({
        el:'#modal_callhistory',
        data:{list:[]},
        methods:{},
        created:function(){
        }
    })
    const settingsApp = new Vue({
        el:'#modal_settings',
        data:{groups:{}, themes:{
            blue:{btnClass:'primary',desc:'蓝色'},
            green:{btnClass:'success',desc:'绿色'},
            light:{btnClass:'info',desc:'浅色'},
            dark:{btnClass:'dark',desc:'深色'},
        }, selectedTheme:'primary'},
        methods:{
            setGroups:function(groups){this.groups = groups},
        }
    })


</script>

</html>
