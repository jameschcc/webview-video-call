<?php
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximun-scale=1">
	<title></title>
    <script src='/common_assets/js/jquery-3.7.1.min.js'></script>
    <script src='/common_assets/js/adapter.js'></script>
    <script src='/common_assets/bootstrap-4.0.0-dist/js/bootstrap.min.js'></script>
    <script src='/common_assets/js/socket.io.js'></script>
    <script src='/common_assets/js/vue.js'></script>
    <script src="/common_assets/js/crypto-js.min.js"></script>
    <link  href='/common_assets/bootstrap-4.0.0-dist/css/bootstrap.min.css' rel="stylesheet">
    <link  href='/common_assets/css/client-mobile.css?v=2' rel="stylesheet">
    <link  href='/common_assets/bootstrap-icons-1.11.2/font/bootstrap-icons.min.css' rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <style type="text/css">body.not_ready * {color: transparent !important;}</style>
</head>
<body class="not_ready">
    <div id="appSection">
        <div id="left" class="callingLayer layer3" :class="inCall?'in_call':'not_in_call'">
            <div id="message">{{warnOrErr}}</div>
            <div id="vOtherSection">
                <video poster="/common_assets/images/video_poster_smallicon.png" autoplay playsinline id="videoMain"></video>
                <!-- <div id="blinker" class="hide"></div> -->
            </div>
            <div id="vSelfSection" v-if="calltype!=constCfg.AUDIO_ONLY" draggable="true" ondragstart="videoDragStart(event,event)" ondragend="videoDrag(event,event)"  ontouchstart="videoDragStart(event,event.changedTouches[0])" ontouchmove="videoTouchMove(event,event.changedTouches[0])" ontouchend="videoDrag(event,event.changedTouches[0])">

                <video poster="/common_assets/images/video_poster.png" autoplay playsinline muted id="videoSelf"  ></video>
            </div>

            <div id="v_info_section" v-if="otherSideUserObj" :class="isStable?'stabled':''">
                <div class="otherSideUname">{{otherSideUserObj.uname}}</div>
                <div class="otherSideUCallnumber">{{otherSideUserObj.callnumber}}</div>
                <div class="calltype_info">{{getCallTypeStr()}}</div>
                <div class="calltype_timer" v-if="callTimer">{{fmtTimer(callTimer)}}</div>
            </div>

            <div id="v_control_section">
                <div class="vctl_button answer" v-if="needAnswer" @click="clickAnswer">Answer</div>
                <div class="vctl_button hangup" @click="clickEndCall">EndCall</div>
            </div>
            <div id="switch_cam_button" v-if="calltype!=constCfg.AUDIO_ONLY && vDevices.length>1" class="vctl_button switchCam" @click="switchVideoDevice">Switch</div>

        </div>

        <div id="right" class="layer1">
            <div id='myInfo'>
                <div class="meta">
                    <div class="row1">
                        <span v-if="u && u.userObj">{{u.userObj.uname}}</span>
                        <span v-else>点击登录</span>
                        <i class="connectInformationIndicator" :class="connectStatus"></i>
                    </div>
                    <div class="row2">
                        <span v-if="u"> 用户编号:#{{u.uid}} 识别码:{{u.uniq}}</span>
                    </div>
                </div>
                <div class="avatar">
                    <img v-if="!u" src="/common_assets/images/Avatar_gray.png">
                    <img v-else src="/common_assets/images/Avatar_blue.png">
                </div>

                <!-- <div v-if="vDevices.length">videoSrc={{vInputSelectIdx}}/{{vDevices.length}} <span v-on:click="switchVideoDevice">switch</span></div>         -->
            </div>


            <div id="userListSection">
                <ul id="userList"  v-if='userList.length'>
                    <li v-for='i,idx in userList' :class='(i.selected?"selected":"") + " " + i.ustate' @click='selectUser(i.uid)' :data-matched="i.matched">
                        <div class="avatar">
                            <img :src="(i.avatarSrc && i.avatarSrc.length)?i.avatarSrc:'/common_assets/images/avatar.png'">
                        </div>
                        <div class="meta">
                            <span class="uname">{{i.uname}}{{u && i.uid==u.uid?'(本机)':''}}</span>
                            <span class="callnumber">{{i.callnumber}}</span>
                            <!--  (UID:{{i.uid}}) - {{u && i.uid==u.uid?'(me)':''}} {{i.ustate}} -->
                        </div>
                    </li>
                </ul>
            </div>
            <div id='btnArea'>
                <div id="openPanelBtn" v-if="!dialPanelOpen" v-on:click="dialPanelOpen=!dialPanelOpen"><i class="bi bi-grid-3x3-gap-fill"></i></div>
                <div id="dialPanel" :class="dialPanelOpen?'panelOpened':'panelClosed'">
                    <div id="theDigits"> {{theDigits}} </div>
                    <div v-for="i in [1,2,3,4,5,6,7,8,9,'X',0,'B']" :data="'digit_'+i" @click="digitClick(i)" class="dialDigitBtn" v-html="btnHtml.hasOwnProperty(i)?btnHtml[i]:i"></div>
                    <!-- <button class ="dialDigitBtn" :class="btn.disabled?'disabled':''" @click='btnClicked'>{{btnZhCn[btn.txt]}}</button> -->
                    <!-- <div @click="backspaceClick()" class="dialDigitBtn">←</div> -->
                </div>
                <div class="btnRow">
                    <button class="callBtn" id="theCallBtn" :class="btn.disabled?'disabled':''" @click='btnClicked'>{{btnZhCn[btn.txt]}}</button>
                    <button class="callBtn" id="theVoiceCallBtn" :class="btn.disabled?'disabled':''" @click='voiceCallClicked'>语音</button>
                </div>
                <!-- <button :class="btnAnswer.disabled?'disabled':''" :click='btnClicked'>{{btn.txt}}</button>  -->
                <!-- <div>{{information}}</div> -->
                <!-- <div id="conInfoDiv">{{connectStatus}}</div> -->
                <audio id="audio" playsinline><source src id="audioSrc" type="audio/mpeg"/></audio>
                <audio id="audioDudu" loop="loop" src='/common_assets/mp3/dudu.mp3' playsinline></audio>
                <audio id="audioRing" loop="loop" src='/common_assets/mp3/ring.mp3' playsinline></audio>
            </div>
        </div>



    </div>

    <!-- end of appSection -->

    <div id="loginApp" class="layer4" :class="needLogin?'fullpageLayer show':'fullpageLayer'">
        <form v-on:submit.prevent="logIn" class="container" id="loginForm">
            <div class="row">
                <div class="form-group col-sm-6">
                    <label class="form-label">
                        呼叫号码
                    </label>
                    <input class="form-control" type="tel"     v-model="callnumber"     placeholder="1xxxxxxxxxx">
                </div>
                <div class="form-group col-sm-6">
                    <label class="form-label">
                        密码
                    </label>
                    <input class="form-control" type="password" v-model="password"   placeholder="******">
                </div>
            </div>

            <div class="row">
                <div class="form-group  col-sm-6 offset-sm-3">
                    <button class="btn btn-block btn-primary" type="submit">登录</button>
                </div>
            </div>
        </form>
    </div>

    <div id="emergApp" class="layer5">
        <?php
        include __DIR__ . '/../common/common_modal.php';
        ?>
    </div>
    <!-- <script src="https://cdn.bootcss.com/notify.js/3.0.0/notify.js"></script> -->
    <script>
        // global configs:
        const AUDIO_ENABLED     = <?=AUDIO_ENABLED?'true':'false'?> ;
        const STUN_SERVER       = "<?=STUN_SERVER?>" ;
        const RING_CB_PREFIX    = "<?=RING_CB_PREFIX?>" ;

        // starts here
        let socket;
        let callState;
            // let uniq = localStorage.getItem('uniq') || genericUniq();
        let uid = 0;
        let uniq = 0;
        const genericUniq = ()=>{
            return new Promise((resolve)=>{
                uniq = CryptoJS.MD5('A'+(new Date()).getTime()).toString().substring(0,5)
                // uniq = parseInt(Math.random()*1000000).toString(16);
                console.log('genericUniq: uniq='+uniq)
                resolve()
            })
        }

        let u=null

        let regState = false;
        let pc = null
        let localStream

        let callId
        let peer
        let answerSdp = null;
        let offerSdp  = null;
        let candidates = []

        const audio = document.getElementById('audio')
        const audioRing = document.getElementById('audioRing')
        const audioDudu = document.getElementById('audioDudu')
        const serverBase = '/'
        const serverUrl = '/'
        let candidateTimer = 0
        let jobIntervalT = 0
        let candidatesFromRemote = []
        let processingRmCandidates = false
        let rmCandidates = null
        let jobs = []
        let callConnected = false
        let vInputSelectIdx = 0
        let waitAnswerTimer = 0
        let sesId = localStorage.getItem('sesId')
        sesId = sesId == 'undefined' ? null : sesId;
        // rtc related
        const offerOptions = {
            offerToReceiveAudio: 1,
            offerToReceiveVideo: 1
        };


        function onCreateSessionDescriptionError(error) {
            console.log(`Failed to create session description: ${error.toString()}`);
        }

        function setPc() {
            pc.onicecandidate =  e => {
                const message = {
                    type: 'candidate',
                    candidate: null,
                };
                console.log(`new candidate: ${e.candidate}. my processingRmCandidates=${processingRmCandidates}`)
                // if(processingRmCandidates)
                    // return

                if (e.candidate) {
                    message.candidate = e.candidate.candidate;
                    message.sdpMid = e.candidate.sdpMid;
                    message.sdpMLineIndex = e.candidate.sdpMLineIndex;
                }
                candidates==null ? candidates=[message] : candidates.push(message)

                addJob('job_postCadidates')
                if(e.candidate == null)
                {
                    console.log("candidates gather end. callId="+callId)
                }
            };

            // ontrack[chrome >= v64]
            pc.ontrack = e => {
                let remoteVideo = document.getElementById('videoMain');
                {
                    console.log('got remote streams. len='+e.streams.length)
                    remoteVideo.srcObject = e.streams[0];
                    remoteVideo.onloadeddata = ()=>{
                        if(!isPlaying(remoteVideo))
                            remoteVideo.play();
                    }
                }
            }

            // onaddstream [chrome >= v24]
            pc.onaddstream = e => {
                let remoteVideo = document.getElementById('videoMain');
                {
                    console.log('got remote stream (onaddstream).')
                    remoteVideo.srcObject = e.stream;
                    remoteVideo.onloadeddata = ()=>{
                        if(!isPlaying(remoteVideo))
                            remoteVideo.play();
                    }
                }
            }

            pc.onsignalingstatechange = e=>{
                let st = pc?pc.signalingState:'no_pc'
                console.log("onsignalingstatechange = " + st);
                switch (st) {
                case "stable":
                    app.isStable = true
                    startDoJob()
                    console.log('started job interval, t='+jobIntervalT)
                    break;
                }
            }

        }


        const CALL_TYPE_VIDEO_AUDIO = 0;
        const CALL_TYPE_VIDEO_ONLY  = 1;
        const CALL_TYPE_AUDIO_ONLY  = 2;
        const CallTypeStr=[];
        CallTypeStr[CALL_TYPE_VIDEO_AUDIO]='CALL_TYPE_VIDEO_AUDIO'
        CallTypeStr[CALL_TYPE_VIDEO_ONLY] ='CALL_TYPE_VIDEO_ONLY'
        CallTypeStr[CALL_TYPE_AUDIO_ONLY] ='CALL_TYPE_AUDIO_ONLY'

        // app related
        const btnDict = {'Idle':'呼叫','Call':'视频呼叫','Answer':'接听来电','EndCall':'结束呼叫'};
        // const rtcCfg = {icertcCfgServers:[{urls:STUN_SERVER}]}
        const rtcCfg = {iceServers:[{urls:['turn:wildfirechat.cn:3478'],username:'wfchat',credential:'wfchat1'}]}
        const offlineSelecEnabled = <?=isset($GLOBALS['camsrvConfigs'])?(getCfg('enableOfflineCalled')?'true':'false'):'false'?>

        let app = new Vue({
            el:'#appSection',
            data:{userList:[], btn:{disabled:true,txt:'Call',class:''}, selection:null, myUniq:uniq, information:null, connectStatus:null, warnOrErr:null, u:u, userObj:null, btnZhCn:btnDict,
            inCall:false, needAnswer:false, theDigits:'', dialPanelOpen:false,
            vDevices:[],vInputSelectIdx:0, isStable : false,
            otherSideUserObj:null,
            calltype:CALL_TYPE_VIDEO_AUDIO,
            constCfg:{AUDIO_ONLY:CALL_TYPE_AUDIO_ONLY},
            btnHtml:{'B':'<i class="bi bi-backspace-fill"></i>', 'X':'<i class="bi bi-arrow-down-right-circle"></i>'},
            callTimer:0
        },
        methods:{
            setUsers:function(us) {this.userList = us},
            selectUser: function(uid) {
                console.log(`selecting user uid=${uid}`)
                if(callId)
                    return false
                let userList = app.userList
                app.userList.forEach(i=>{ if(i.uid!=uid) i.selected = false; })
                let hasSelect = false;
                userList.forEach(i=>{
                    if(i.uid==uid
                        && !hasSelect
                        && (offlineSelecEnabled || i.ustate != 'OFFLINE')
                        )
                    {
                        i.selected = ((i.hasOwnProperty('selected')) ? (!i.selected) : true);
                        if(i.selected) {
                            app.selection=i
                            hasSelect = true;
                        }
                    }
                })
                globalSetUsers(userList)
                if(!hasSelect)
                {
                    app.selection = null
                    setBtn('Idle')
                    return false
                }

                console.log(app.selection)
                            // app.btn.disabled = hasSelect?false:true;
                setBtn('Call')
                return true
            },
            selectUserWithMobile:function(callnumber) {
                console.log(`selectUserWithMobile callnumber=${callnumber}`)
                for(var i in app.userList)
                {
                console.log(`i callnumber=${app.userList[i].callnumber}`)
                    if(app.userList[i].callnumber == callnumber)
                        return this.selectUser(app.userList[i].uid)
                }
                return false
            },

            voiceCallClicked:()=>{
                app.calltype = CALL_TYPE_AUDIO_ONLY
                return app.btnClicked()
            },
            getCallTypeStr:()=>{
                switch(app.calltype)
                {
                case CALL_TYPE_AUDIO_ONLY:
                    return "语音电话";
                default:
                    return "视频电话"
                }
            },
            // return Promise
            btnClicked: ()=>{
                if(app.btn.disabled)
                {
                    console.log("btnClicked but is disabled")
                    return Promise.resolve()
                }

                let calltype = app.calltype
                console.log('btnClicked with calltype='+CallTypeStr[calltype])
                switch(app.btn.txt)
                {
                case 'Call':
                    {
                        // pc  = new RTCPeerConnection(null);
                        try{
                            pc  = new RTCPeerConnection(rtcCfg);
                        }
                        catch(e)
                        {
                            console.error("This view may not support RTCPeerConnection?");
                            warnErr("当前设备不支持直连音视频呼叫，请确认系统版本大于Android7.1或WebView>56");
                            throw(e);
                        }
                        app.needAnswer = false
                        setPc()
                        // navigator.mediaDevices.getUserMedia({audio: AUDIO_ENABLED, video: getVideoConstraints(camDirection)})
                        openMedias()
                        .then((media)=>{
                            console.log(media)
                            localStream = media
                            camDirection = camDirection==1?1:0
                                console.log("ADDING STREAM")

                            // if(typeof pc.addTrack == 'undefined')
                            // //  addTrack addStream[chrome >= v24]
                                pc.addStream(localStream)
                            // else
                                // localStream.getTracks().forEach(track => pc.addTrack(track, localStream))

                            pc.createOffer (offerOptions)
                            .then(
                                (description)=>{
                                    console.log(`got offer=${description}`)
                                    pc.setLocalDescription(description);
                                    startCall(description)
                                }, onCreateSessionDescriptionError
                                )
                            .catch(e=>{
                                console.log(e)
                                console.error(`Exception when btnClicked:Call, fail to createOffer ${e}`)
                                // warnErr('fail to createOffer')
                                warnErr('未能成功发起呼叫，请稍后重试')
                                pc.close()
                                pc = null;
                            })

                        })
                        .catch(e=>{
                            console.error(`Exception when btnClicked:Call, fail to get media`)
                            console.log(e)
                                    // AbortError
                                    // NotAllowedError
                                    // NotFoundError
                                    // NotReadableError
                                    // OverconstrainedError
                                    // SecurityError
                                    // TypeError
                            // warnErr('fail to get media')

                    console.error(e.message)
                    console.error(JSON.stringify(e))
                            warnErr('未能获取到音视频设备的使用权限，请检查权限后重试')
                            pc.close()
                            pc = null;
                        })
                    }
                    break;
                case 'Answer':
                    {
                        app.clickAnswer();
                    }
                    break;
                case 'EndCall':
                    {
                        processEndCall(callId,true)
                    }
                    break;

                case 'Idle':
                    break;

                default:
                    console.error('Unkown btn event: ' + app.btn.txt)
                    break;
                }
            },
            switchVideoDevice:()=>{switchVideo()},
            clickEndCall:()=>{processEndCall(callId,true)},
            clickAnswer:function()
            {
                if(pc)
                    pc.close()

                try{
                    pc  = new RTCPeerConnection(rtcCfg);
                }
                catch(e)
                {
                    console.error("This view may not support RTCPeerConnection?");
                    warnErr("当前设备不支持音视频呼叫，请确认系统版本大于Android7.1或WebView>56");
                    jQuery.post(serverUrl+'callControl/api_reject',{callId:callId, sesId:sesId}).then(()=>{
                    forceClearCallLocally()
                    })
                    throw(e);
                }

                setPc()
                app.needAnswer = false
                // if(waitAnswerTimer)
                // {
                //     clearTimeout(waitAnswerTimer)
                //     waitAnswerTimer = 0
                // }
                clearTimerTimeout('waitMyAnswerAction')
                audioPlay('stop')
// // var front = false;
// document.getElementById("flip-button").onclick = function () {
//   front = !front;
// };

// var constraints = { video: { facingMode: front ? "user" : "environment" } };

                // navigator.mediaDevices.getUserMedia({audio: AUDIO_ENABLED, video: getVideoConstraints(camDirection)})
                openMedias()
                .then((media)=>{
                    console.log(media)
                    localStream = media
                    camDirection = camDirection==1?1:0;

                    if(videoEnabled())
                    {
                        document.getElementById('videoSelf').srcObject = localStream
                        document.getElementById('videoSelf').onload =()=>{document.getElementById('videoSelf').play()}
                    }

                    if(typeof pc.addTrack == 'undefined')
                        pc.addStream(localStream)
                    else
                        localStream.getTracks().forEach(track => pc.addTrack(track, localStream))

                    let theOtherPc = offerSdp
                    pc.setRemoteDescription(processSdp(theOtherPc))
                    .then(()=>{return pc.createAnswer(offerOptions)})
                    .then((description)=>{
                        answerSdp = description
                        console.log(answerSdp)
                        return pc.setLocalDescription(description)
                    }, onCreateSessionDescriptionError)
                    .then(()=>{
                        sendAnswer(answerSdp)
                        getMoreVideoDevices().then((vlist)=>{
                            app.vDevices = vlist
                        })
                    })
                }).catch(e=>{
                    console.error(e.message)
                    console.error(JSON.stringify(e))
                    console.error(`Exception when clickAnswer, fail to get media`)
                    warnErr('未能获取到音视频设备的使用权限，请检查权限后重试')
                    processEndCall(callId,true)
                    pc.close()
                    pc = null;
                })

            },
            digitClick: (i)=>{
                if(i=='B')
                    return app.backspaceClick();
                else if(i=='X')
                    return app.closeDialClick()
                app.theDigits += (''+i)
                app.filterWithDigits()
            },
            backspaceClick:()=>{
                if(app.theDigits.length){
                    app.theDigits = app.theDigits.substring (0, app.theDigits.length - 1);
                }
                app.filterWithDigits()
            },
            closeDialClick:()=>{
                app.dialPanelOpen = false
                app.theDigits=''
                app.filterWithDigits()
            },
            openDialClick:()=>{
                app.dialPanelOpen = true
                app.theDigits=''
                app.filterWithDigits()
            },

            filterWithDigits:function()
            {
                app.userList.forEach(i=>{
                    // console.log(i)
                    if(app.theDigits && app.theDigits.length && !i.callnumber.includes(app.theDigits))
                    {
                        i.matched = 'unmatch'
                    }
                    else
                    {
                        i.matched = 'match'
                    }
                })
            },

            fmtTimer :(cnt)=>{
                let minutes = Math.floor(cnt/60)
                let seconds = cnt%60

                return `${pad(minutes)}:${pad(seconds)}`
            }

        },
        created:()=>{}
    })

const clearPc = ()=>{
    if(pc)
    {
        pc.close();
        pc = null;
    }
}

const openMedias = ()=>{
    return new Promise((rs,rj)=>{
        var needVideo = (app.calltype == CALL_TYPE_AUDIO_ONLY ? false : true)
        navigator.mediaDevices.getUserMedia({audio: AUDIO_ENABLED, video: getVideoConstraints(camDirection)})
        .then(medias => {
            rs(medias)
        })
        .catch(e=>{
            if(needVideo)
            {
                console.error('need video but unable to get video src. try audio only')
            }
            navigator.mediaDevices.getUserMedia({audio: true, video: false}).then(medias=>{rs(medias)}).catch(e=>{
                console.error('try audio only but also failed')
                throw(e)
            })
        })
    })
}

const videoEnabled = ()=>{return app.calltype != CALL_TYPE_AUDIO_ONLY}

const clearLocalStream = ()=>{
    if(localStream)
    {
        localStream.getTracks().forEach(t=>{localStream.removeTrack(t) ;  t.stop()})
        localStream=null;
        let vSelf = document.getElementById('videoSelf')
        if(vSelf)
        {
            vSelf.srcObject = null;
            vSelf.pause() ; vSelf.currentTime = 0;
        }
    }
}
const processEndCall = (callIdToClear, notifyPeer)=>{
    return new Promise((resolve,reject)=>{
        clearPc();
        if(!callIdToClear)
        {
            console.error('processEndCall triggered without callId')
            typeof bridge == 'undefined' || bridge.finish()
            resolve()
        }
        else
            jQuery.post(serverUrl+'callControl/api_callEnd', {callId:callIdToClear,notifyPeer:notifyPeer,sesId:sesId}, function(res){
                if(res.code==0)
                {
                    clearLocalStream()
                    clearMainVideo()
                    resetAppFlags();
                    typeof bridge == 'undefined' || bridge.finish()
                    resolve(res)
                }
                else
                {
                    console.log(res.msg)
                    forceClearCallLocally();
                    typeof bridge == 'undefined' || bridge.finish()
                    reject(res)
                }
            },'JSON')
    })
}

const connectWss = ()=>{
            // $uid = "1";
    return new Promise((rs,rj)=>{
        console.log('try to connect wss:'+uniq)
        socket = io("", { path: '/socket.io/' });
        socket.on('new_msg', msg => {handleMsg(msg)})
        socket.on('connect', function () {
            console.log('连接成功');
            // app.connectStatus = '连接成功'
            app.connectStatus = 'connected'
            // app.btn.txt = 'Call'
            socket.emit('login', uniq);
            needRefreshList()
            rs()
        });
        socket.on('disconnect', function () {
            if(!uniq)
                return
            console.log('正在连接..');``
            // app.connectStatus = '正在连接..'
            app.connectStatus = 'connecting'
            // socket.emit('login', uniq);
            // rs()
        });
                // socket.on('connection', function () {
                //     console.log('连接成功');
                //     socket.emit('login', uniq);
                // });
    })
}

const handleMsg = msg =>  {
    let msgObj = JSON.parse(msg)

    console.log('rcvd msg:'+msg)
    // console.log(msgObj)

    let prevCallId = callId

    switch(msgObj.msgType)
    {
    case 'msgCallRing':
        // if(callId || callState == 'busy')
        if(app.inCall && prevCallId != msgObj.callId)
        {
            console.error('Got callRing but im busy. in callId='+prevCallId+ ', msgCallId='+msgObj.callId)
            jQuery.post(serverUrl+'callControl/api_reject',{callId:msgObj.callId, sesId:sesId})
            uploadState();
            return
        }
        else
        {
            if(callId==msgObj.callId)
            {
                console.log('received again? callId='+prevCallId)
                return;
            }
            if(!msgObj.hasOwnProperty('callId') || !msgObj.callId)
            {
                console.error('Got callRing but no callId provided.')
                break;
            }
            callId = msgObj.callId;
            app.inCall = true
            jQuery.post(serverUrl+'callControl/api_getOffer',{callId:callId,sesId:sesId},
                function(res){
                    console.log(`got call offer response. callId=${callId}, calltype=${res.obj.calltype}`)
                    console.log(res)
                    callId = msgObj.callId;
                    app.inCall = true
                    if(res.code > 0)
                    {
                        abortCall(callId)
                        resetAppFlags()
                    // result()
                    }
                    else
                    {
                        offerSdp = JSON.parse(res.obj.offer)
                        setBtn('Answer')
                        audioPlay('ring')
                        app.otherSideUserObj = res.obj.callingUserObj
                        // if(waitAnswerTimer)
                        //     clearTimeout(waitAnswerTimer)
                        // waitAnswerTimer = setTimeout(function(){forceClearCallLocally(callId)}, 50*1000)
                        startTimer('waitMyAnswerAction')
                        app.needAnswer = true
                        app.calltype = res.obj.calltype
                    // app.clickAnswer()   // to be done:remove this. [auto answer]
                    }
                },'JSON'
                )
        }
        break;

    case 'msgCallAnswer':
        if(msgObj.callId != prevCallId)
        {
            console.log('rcvd msgCallAnswer but callId mismatch, myCallId='+prevCallId+',msgObj.callId='+msgObj.callId)
            return
        }

        if(!msgObj.hasOwnProperty('callId') || !msgObj.callId)
        {
            console.error('Got callAnswer but no callId provided.')
            break;
        }

        callId = msgObj.callId;
        app.inCall = true

        clearTimerTimeout('activatePeer')
        audioPlay('stop')
        jQuery.post(serverUrl+'callControl/api_getAnswer',{callId:callId, sesId:sesId},
            function(res){
                console.log('got call answer response:')
                console.log(res)
                if(res.code)
                {
                    abortCall(callId)
                    // result()
                }
                else
                {
                    answerSdp = JSON.parse(res.obj.answer)
                    answerGot(answerSdp)
                    startCallTimerCounter()
                    clearTimerTimeout('waitPeerAnswer')
                    // callConnected = true
                }
            },'JSON'
            )
        break;

    case 'msgDeviceListUpdate':
        needRefreshList()
        break;

    case 'msgCallClear':
        if(msgObj.callId != callId)
        {
            console.log('rcvd msgCallClear but callId mismatch, myCallId='+prevCallId+',msgObj.callId='+msgObj.callId)
            if(prevCallId != 0)
                return
        }
        clearPc()
        clearLocalStream()
        clearMainVideo()

        setBtn('Call')
        audioPlay('stop')
        resetAppFlags()

        if(!offlineSelecEnabled)
            jQuery.post(serverUrl+'callControl/api_releaseComplete',{callId:callId, sesId:sesId},
                function(res){},
                'JSON')

        callId = 0
        app.inCall = false
        typeof bridge == 'undefined' || bridge.finish()
        break;

    case 'msgReject':
        if(callId)
        {
            abortCalling()
            processEndCall(callId,false)

            warnErr('对方正忙，请稍后再试')
        }
        break;

    case 'msgAddCandidates':
        if(msgObj.callId != callId)
        {
            console.log('rcvd msgCallClear but callId mismatch, myCallId='+callId+',msgObj.callId='+msgObj.callId)
            return
        }
        processingRmCandidates = true
        console.log('processingRmCandidates::')
        console.log(`pc:=${pc}`)
        if(pc && pc.signalingState=='stable' && pc.remoteDescription!=null)
            loadRemoteCandidates(msgObj)
        else{
            addJob('job_loadRemoteCandidates')
            console.log(msgObj)
            rmCandidates = msgObj
        }
        break;

    case 'msgAudit':
        break;
    case 'disconnect':
        if(pc)
        {
            pc.close();
            pc = null;
        }
        clearLocalStream()
        app.myUniq = null;
        app.u = null;
        uid = null;
        uniq = null;
        u = null;
        uid = null;
        loginApp.needLogin = true;
        // app.information = 'This session has been closed.'
        app.connectStatus = 'disconnectted'
        socket.close()
        warnErr('连接已断开，请重新登录')
        break;
    }
};

const clearMainVideo = ()=>
{
    let v =  document.getElementById('videoMain')
    if(!v)
    {
        console.error('clearMainVideo: no dom to clear')
        return
    }
    v.pause()
    v.srcObject = null
}
const clearSelfVideo = ()=>
{
    let v =  document.getElementById('videoSelf')
    v.pause()
    v.srcObject = null
}

const warnErr = msg=>{
    // app.warnOrErr = msg
    console.error('warnErr'+msg)
    modalApp.error(msg)
    // setTimeout(()=>{app.warnOrErr=null}, 3000)
}

let timeoutsDef = {
    'postCandidatesToPeer':{duration:1*1000, repeat:false, needlog:true},
    'refreshDeviceList':{duration:200, repeat:false, needlog:true},
    'waitPeerAnswer':{duration:50*1000, repeat:false, needlog:true},
    'waitMyAnswerAction':{duration:50*1000, repeat:false, needlog:true},
    'counter':{duration:1000, repeat:true, needlog:false},
    'activatePeer':{duration:5000, repeat:true, needlog:true},
}
let timeoutsKeys = Object.keys(timeoutsDef)
let timeouts = new Array(Object.keys(timeoutsDef).length).fill(0)
const startTimer = (timertyp) =>
{
    let idx = timeoutsKeys.indexOf(timertyp)
    if(idx == -1)
    {
        console.log('unrecognized timer type:'+ timertyp)
        return
    }
    if(timeouts[idx])
        clearTimeout(timeouts[idx])
    timeouts[idx] = setTimeout(function(){timerTimeout(timertyp)}, timeoutsDef[timertyp].duration)
}
const timerTimeout = (timertyp) =>{
    let idx = timeoutsKeys.indexOf(timertyp)
    if(timeoutsDef[timertyp].needlog)
        console.log('timeout='+timertyp)
    if(idx == -1)
    {
        console.log('unrecognized timerTimeout type:'+ timertyp)
        return
    }
    if(timeouts[idx])
        eval(timertyp+'()')
    timeouts[idx] = 0
    if(timeoutsDef[timertyp].repeat)
        startTimer(timertyp)
}
const clearTimerTimeout = (timertyp) =>{
    let idx = timeoutsKeys.indexOf(timertyp)
    if(idx == -1)
    {
        console.log('unrecognized timerTimeout type:'+ timertyp)
        return
    }
    if(!timeouts[idx])
    {
        console.log('trying to stop an unstarted timer: '+ timertyp+', tid='+timeouts[idx])
    }
    else
        clearTimeout(timeouts[idx])
    timeouts[idx] = 0
}

function addJob(j) {
    if(!jobs)
        jobs = [j]
    else if(jobs.includes(j)){
    }
    else
    {
        jobs.push(j)
        console.log('added job:'+j)
    }
    if(!jobIntervalT)
    {
        jobIntervalT = setInterval(doCallJobs,100)
    }
}

function startDoJob()
{
    doCallJobs()
    if(jobIntervalT)
        clearInterval(jobIntervalT)
    jobIntervalT = setInterval(doCallJobs,100)
}

function isPlaying(video)
{
    return !(video.paused || video.ended || video.seeking || video.readyState < video.HAVE_FUTURE_DATA)
}


function doCallJobs()
{
    if(!app.isStable)
    {
        return;
    }
    if(!jobs || !jobs.length)
    {
        clearInterval(jobIntervalT)
        jobIntervalT = setInterval(doCallJobs,1000)
        return
    }

    for(let i=0;i<jobs.length;i++){
        let j = jobs[i]
        switch(j){
        case 'job_loadRemoteCandidates':
            {
                console.log('doing job:'+j)
                loadRemoteCandidates(rmCandidates)
                jobs[i]=null
                console.log('done job:'+j)
            }
            break;

        case 'job_postCadidates':
            console.log('doing job:'+j)
            if(pc && callId){
                postCadidates()
                jobs[i]=null
                console.log('doing job:'+j)
            }
            break;

        default:
            console.error('Unkown job to do:'+i)
        }
    }
    jobs = jobs.filter(i=>i!=null)
}

let refreshTimeout = 0;
function needRefreshList() {
    // if(refreshTimeout)
    //     clearTimeout(refreshTimeout)
    // refreshTimeout = setTimeout(refreshDeviceList, 200)
    startTimer('refreshDeviceList')
}

function forceClearCallLocally()
{
    clearPc();
    resetAppFlags();
    clearLocalStream()
    clearMainVideo()
}

const waitMyAnswerAction = forceClearCallLocally;
const counter = ()=>{app.callTimer++}

function abortCall(callId) {
    if(callId) {
                // tobedone
        if(pc)
            pc.close()
        clearLocalStream()
    }
}


const activatePeer = ()=>{
    if(peer){
        var url = RING_CB_PREFIX + peer.callnumber
        jQuery.post('/server/api_notifyPeer', {url:url}, function(res){
            console.log('visited url ' + url + ' and rcvd with code=' + (res.code==0?'success':'fail'))
            if(res.code==0)
                clearTimerTimeout('activatePeer')
        },'JSON')
    }
}

// returns Promise
function handleCandidate(candidate) {
    if (!pc) {
        console.error('no peerconnection');
        return;
    }
    return new Promise((rs,rj) => {
        if (!candidate.candidate) {
            console.log("candidate null break")
            rs()
        } else {
            pc.addIceCandidate(candidate).then(rs);
        }
    })
}

function enterStable()
{
    doCallJobs()
}

const processSdp =  desc => {
    if(desc && desc.hasOwnProperty('sdp') && desc.sdp.indexOf('\na=extmap-allow-mixed') !== -1){
        const sdp = desc.sdp.split('\n').filter((line) => {
            return line.trim() !== 'a=extmap-allow-mixed';
        }).join('\n');
        desc.sdp = sdp;
        return desc;
    }
    return desc
}
// calling party gor answer from remote side
function answerGot(answerSdp) {
    pc.setRemoteDescription(processSdp(answerSdp)).catch(e=>{
        console.error('error setting answerSDP')
    })
}

const postCandidatesToPeer = (candidate)=>
{
    jQuery.post(serverUrl+'callControl/api_updateCandidate',{callId:callId, candidate:candidate,sesId:sesId},function(res){
        if(res.code>0)
        {
            // fail to notify, restart timer and try another notify
            console.error(res.msg)
            startTimer('postCandidatesToPeer')
            // if(candidateTimer)
            //     clearTimeout(candidateTimer)
            // candidateTimer = setTimeout(postCandidatesToPeer,5000)
        }
        else
        {
            clearTimerTimeout('postCandidatesToPeer')
            // if(candidateTimer)
            //     clearTimeout(candidateTimer)
        }
    },'JSON')
}

function refreshDeviceList(){
    console.log("refreshDeviceList...")
    return new Promise((rs,rj)=>{
    jQuery.get(serverUrl+'callControl/api_fetchusers',function(res){
        if(res.code==0)
        {
            let userList = res.obj
            userList.forEach(i=>{i.selected = false;})
            console.log('userList length='+userList.length+', lists below:')
            console.log(userList)
            app.userList = userList
            if(app.theDigits.length)
            {
                app.filterWithDigits()
                    // Vue.set(app,'userList', userList)
            }
            rs()
        }
    },'JSON')
    })
}

const uploadState = ()=>{
    jQuery.post(serverUrl+'callControl/api_auditack',{state:callState,sesId:sesId},function(res){
        if(!res.code==0)
            console.error(res.msg)
    },'JSON')
}

const sendHeartBeat = ()=>{
    jQuery.post(serverUrl+'callControl/api_heartbeat',{state:callState,sesId:sesId},function(res){
        if(!res.code==0)
            console.error(res.msg)
    },'JSON')
}


const startCall = (offer)=>{
    console.log(`selection: ${app.selection}`)
    console.log(`selection uid=${app.selection.uid}`)
    console.log(offer)
    if(!offer || !offer.sdp || !offer.type=='ofer')
        return abortCalling()

    let videoEnabledPar = videoEnabled()
    if(videoEnabledPar) {
        document.getElementById('videoSelf').srcObject = localStream
    }

    let selection = app.selection
    jQuery.post(
        serverUrl+'callControl/api_startCall',
        {offer:JSON.stringify({'type':offer.type, 'sdp':offer.sdp}), calledUid:app.selection.uid, sesId:sesId, calltype:app.calltype},
        function(res){
            if(res.code!=0)
            {
                abortCalling()
                resetAppFlags()
                console.error(res.msg)
                handleErrorCode(res)
                if(res.msg && res.msg.length)
                {
                    warnErr(res.msg)
                }
                return
            }
            else
            {
                if(!res.obj.hasOwnProperty('callId') || !res.obj.callId)
                {
                    console.error('no callId got')
                    abortCalling()
                    return
                }
                else
                {
                    callId = res.obj.callId
                    peer = selection
                    app.inCall = true
                    app.otherSideUserObj = res.obj.calledUserObj
                    setBtn('EndCall')
                    audioPlay('dudu')
                    startTimer('activatePeer')
                    activatePeer()
                    startTimer('waitPeerAnswer')
                    // if(waitAnswerTimer)
                        // clearTimeout(waitAnswerTimer)
                    // waitAnswerTimer = setTimeout(function(){}, 50*1000)
                }
            }
        },
        'JSON')
    .fail(e=>{console.log(`fail to post startCall: ${e}`); abortCalling()})
}

const waitPeerAnswer = ()=>{
    jQuery.post(serverUrl+'callControl/api_callEnd',{callId:callId, sesId:sesId},function(res){},'JSON')
    abortCalling('对方无应答')
}

const sendAnswer = (answer)=>{
    console.log(answer)
    if(!answer || !answer.sdp || !answer.type=='answer')
        return abortCalling()
    jQuery.post(
        serverUrl+'callControl/api_answerCall',
        {answer:JSON.stringify({'type':answer.type, 'sdp':answer.sdp}), callId:callId, sesId:sesId},
        function(res){
            if(!res.code==0)
            {
                abortCalling()
                console.error(res.msg)
                return
            }
            else
            {
                if(!res.obj.hasOwnProperty('callId') || !res.obj.callId)
                {
                    console.error('no callId got')
                    abortCalling()
                    return
                }
                else
                {
                    setBtn('EndCall')
                    loadRemoteCandidates(rmCandidates)
                    startCallTimerCounter()
                }
            }
        },
        'JSON')
    .fail(e=>{console.log(`fail to post anserCall: ${e}`); abortCalling()})
}

const startCallTimerCounter = ()=>{
    startTimer('counter')
}

const setBtn = newState => {
    switch (newState) {
    case 'EndCall':
        app.btn.txt = newState
        app.btn.disabled = false
        break;
    case 'Call':
        app.btn.txt = newState
        app.btn.disabled = app.selection && app.selection.uid != app.u.uid ? false : true
        break;
    case 'Answer':
        app.btn.txt = newState
        app.btn.disabled = false
        break;
    case 'Idle':
        app.btn.txt = newState
        app.btn.disabled = true
        break;
    default:
        app.btn.disabled = true
        console.error('Unkown btn state='+state);
        // warnErr('Unkown btn state='+state)

        break
    }
}

const abortCalling = (msg)=>{
    audioPlay('stop')
    if(pc)
    {
        pc.close()
        pc = null
    }
    if(localStream)
    {
        let tracks = localStream.getTracks();
        tracks.forEach(i=>{console.log(i); i.stop(); localStream.removeTrack(i)})
        if(videoEnabled())
            document.getElementById('videoSelf').srcObject = null
        localStream = null
                        // localStream.getTracks().forEach(i=>{localStream.remot})
                        // to be done. if no calls, stop localstream.
    }
    if(candidateTimer)
    {
        clearTimeout(candidateTimer);
        candidateTimer = 0;
    }
    if(msg)
    {
        modalApp.notice(msg)
    }
    audioPlay('stopDudu')
    resetAppFlags()
}

const audioPlay = type => {
    switch (type)
    {
    case 'stop':
        audioDudu.pause();
        audioRing.pause();
        break;
    case 'stopDudu':
        audioDudu.pause();
        break;
    case 'stopRing':
        audioRing.pause();
        break;

    case 'dudu':
        audioDudu.currentTime = 0
        audioRing.pause()
        audioDudu.play().catch(e=>{console.log('Exception when audioPlay, failed to play audio dudu');console.log(e)})
        break;

    case 'ring':
        audioRing.currentTime = 0
        audioDudu.pause()
        audioRing.play().catch(e=>{console.log('Exception when audioPlay, failed to play audio ring');console.log(e)})
        break;
    }
}
const MULTILOGIN_ERROR = 99

/**
 * @brief   to bind uniq and sesId
 * */
const register = ()=>{
    return new Promise((resolve, reject)=>{
        jQuery.post(serverUrl+'callControl/api_registerUniq',
            {uniq:uniq, sesId:sesId},
            function(res) {
                if(res.code==0) {
                    regState = true;
                    app.btn.txt = 'Call'
                    app.myUniq = uniq
                    app.u = res.obj
                    u = res.obj
                    loginApp.needLogin = false
                    sesId = res.obj.sesId
                    console.log('register: sesId=' + sesId + ' registerObj as below:'+JSON.stringify({uid:res.obj.uid, uniq:res.obj.uniq, uniq_idx:res.obj.uniq_idx}))
                    // console.log(res.obj)
                    localStorage.setItem('sesId',sesId)
                    resolve()
                }
                else {
                    if(res.code==MULTILOGIN_ERROR) {
                        if (true || confirm('Kick out other devices?')) {
                            jQuery.post(
                                serverUrl+'callControl/api_registerUniq&force',
                                {uniq:uniq, sesId:sesId},
                                function(res) {
                                    if(res.code==0)
                                    {
                                        console.log('api_registerUniq:'+res.msg)
                                        regState = true;
                                        app.btn.txt = 'Call'
                                        app.myUniq = uniq
                                        app.u = res.obj
                                        app.userObj = res.obj.userObj
                                        u = res.obj
                                        sesId = res.obj.sesId
                                        localStorage.setItem('registerForce: sesId',sesId)
                                        resolve()
                                    }
                                    else
                                    {
                                        warnErr(res.msg)
                                        reject({message:'需要登录'})
                                    }
                                },
                                'JSON')
                        }
                    }
                    else {
                        handleErrorCode(res)
                    }
                    reject({message:'需要登录'})
                }
            }, 'JSON')
        .fail(function(){reject({message:'需要登录'})})
    })
}

const postCadidates = () => {
    if(!candidates || !candidates.length)
    {
        console.log('no candidates to post')
        return
    }
    console.log('postCadidates: '+candidates.length+' candidates to post')

    jQuery.post(serverUrl+'callControl/api_updateCandidate',
        {callId:callId?callId:0, candidatesJson:JSON.stringify(candidates), sesId:sesId
        , candidateCnt:candidates.length
    },
    function (res) {
        if(res.code)
        {
            console.error('postCadidates error: '+res.msg)
        }
        else
        {
            console.log('postCadidates ok.')
            candidates = null
        }
    },'JSON')
}

const loadRemoteCandidates = (msgObj)=>{
    if(msgObj && msgObj.candidates)
    {
        jQuery.get(serverBase+'candidates/'+msgObj.candidates,function(res){
            console.log('got '+ res.length + ' remote candidates')
            for(var i=0; i<res.length; i++)
            {
                if(res[i].candidate)
                    pc.addIceCandidate(res[i])
            }
            processingRmCandidates = false
            rmCandidates = null
        },'JSON')
        .fail(()=>{processingRmCandidates = false})
    }
}

const loginWithParameter = ()=>{
    let paramCallNumber = <?=isset($_GET['callNumber'])?"'{$_GET['callNumber']}'":'null'?>;
    return new Promise((rs,rj)=>{
        if(!paramCallNumber)
            rs()
        else {
            loginApp.callnumber = paramCallNumber
            jQuery.post('/userApi/api_loginWithParameter', {callnumber:paramCallNumber, uniq:uniq, sesId:sesId}, function(res){
                if(res.code){
                    warnErr(res.msg)
                    rj()
                }
                else
                {
                    loginApp.needLogin = false
                    uid = res.obj.uid
                    u = res.obj
                    app.u = res.obj
                    sesId = res.obj.sesId
                    console.log('sesId???=')
                    localStorage.setItem('sesId',sesId)
                    rs()
                }
            },'JSON')
        }
    })
}

const con = ()=>{
    return new Promise((rs, rj)=>{
        connectWss()
        .then(loginWithParameter)
        .then(register, e=>{
            console.log('Exception when con(), exception below:');
            console.oldlog(e);
            console.log(e.message);
            modalApp.confirm('未能与服务器建立连接，请重新接入此页面',()=>{window.location.href=window.location.href})
            throw Error('未能与服务器建立连接，请重新接入此页面')
        }
        )
        .then(
            function() {
                needRefreshList()
                rs()
            },
            e=>{console.log(e); throw e}
            )
    }
    )
}

// const registerDomActions = ()=>{
//     document.getElementById('videoSelf').ondrag = function(e)
//     {
//         console.log(e)
//     }
// }

/**
 * @brief   these are the key query parameters
 */
const pageKeys = ['callNumber','action','called','type']
queries = {}
for(i in pageKeys)
    queries[pageKeys[i]] = null
const extractQuery = ()=>{
    let locationSearch = document.location.search
    if(!locationSearch)
        return
    let params = locationSearch.split(/\?|&/)
    let q = {}
    console.log(params)
    for(var i in params)
    {
        let arr = params[i].split('=')
        if(!arr || !arr.length)
            continue
        q[arr[0]] = arr.length>1 ? arr[1] : null
    }
    for(i in pageKeys)
    {
        let k = pageKeys[i]
        if(q.hasOwnProperty(k) && q[k])
            queries[k] = q[k]
    }
    if(queries.callNumber)
        document.body.className += ' invoked'
    if(queries.action)
        document.body.className += ' actionDefined'
}
/**
 * @brief   to do the jobs after app is fully loaded when page invoked with params
 * */
const checkUserList = ()=>{
    return new Promise((rs,rj)=>
    {
        if(!app.userList.length)
            refreshDeviceList().then(rs)
        else rs()
    })
}
const executeActions = ()=>{
    return new Promise((rs,rj) =>
    {
        if(!queries.action)
        {
            rs();
            return;
        }

        checkUserList().then(()=>{
            if(queries.action == 'call')
            {
                if(queries.called)
                {
                    if(app.selectUserWithMobile(queries.called))
                    {
                        app.btn.txt = 'Call'
                        app.btn.disabled = false
                        if(queries.type=='audio')
                            app.voiceCallClicked()
                        else
                            app.btnClicked()
                    }
                    else
                        warnErr('未能发起呼叫（原因：被叫方无效），点击返回');
                }
                else
                {
                    warnErr('未能发起呼叫（原因：参数错误），点击返回');
                }
            }
            else if(queries.action == 'answer')
            {
                // jobs: to click answer
                autoAnswer = true
            }
        })
    })

}


const startService = ()=>{
    console.log(`browser=${navigator.userAgent}`)
    typeof bridge == 'undefined' || bridge.log("opened through client")
    extractQuery()
    document.body.classList.contains('not_ready') && (document.body.className = document.body.className.replace(/not_ready/g,'ready'))

    var notMatched = guaranteeCapability()
    if(notMatched.length) {
        warnErr(notMatched.join('; '))
        return
    }

    genericUniq()
    .then(con)
    .then(getMoreVideoDevices)
    .then((vlist)=>{
        app.vDevices = vlist
    })
    .then(executeActions)
}

window.onload = startService
/*
$(document).ready(function () {
    startService()
});*/

let loginApp = new Vue({
    el:'#loginApp',
    data:{ needLogin:false, callnumber:'80', password:'abcde', uniq:uniq },
    methods:{
        logIn:function()
        {
            if(!uniq)
                genericUniq()
            jQuery.post('/userApi/login', {callnumber:loginApp.callnumber, passhash:CryptoJS.MD5(loginApp.password).toString(), uniq:uniq, sesId:sesId}, function(res){
                if(res.code){
                    // alert(res.msg)
                    warnErr(res.msg)

                }
                else
                {
                    loginApp.needLogin = false
                    uid = res.obj.uid
                    u = res.obj
                    app.u = res.obj
                    sesId = res.obj.sesId
                    console.log('sesId???=')
                    // localStorage['sesId'] = sesId
                    localStorage.setItem('sesId',sesId)

                    con();
                }
            },'JSON')
        },
        logOut:function () {
            jQuery.post('/userApi/logout', {uniq:uniq}, function(res){
                if(res.code){
                    // alert(res.msg)
                    warnErr(res.msg)

                }
                else
                {
                    localStorage.setItem('sesId','')
                    // loginApp.needLogin = false
                    // uid = res.obj.uid
                    // u = res.obj
                    // app.u = res.obj
                    // con();

                }
            },'JSON')
        }
    }
})

const handleErrorCode = codeObj=>
{
    console.log("handleErrorCode")
    console.log(codeObj)
    switch(codeObj.code)
    {
    case 8:
        loginApp.needLogin = true;
        break;
    default:
        break;
    }
}

videoDevices = []
let camDirection=0
const getMoreVideoDevices = ()=>
{
    return new Promise((res,rej)=>{
        navigator.mediaDevices.enumerateDevices().then(devices=>{
            videoDevices = []
            console.log(devices)
            if(!devices)
                return;
            devices.forEach(i=>{
                if(i.kind == 'videoinput')
                {
                    videoDevices.push(i)
                }
            })
            console.log('videoDevices length=' + videoDevices.length + '. lists below:')
            console.log(videoDevices)
            if(videoDevices.length >= 1)
            {
                res(videoDevices)
            }
            else
            {
            }
        }).catch(e=>{
            warnErr("未能获取到音视频设备，请检查权限")
        })
    })
}

const guaranteeCapability = ()=>
{
    var notMatched = [] ;
    (typeof navigator == 'undefined') && notMatched.push('no `navigator`')
    (typeof navigator.mediaDevices == 'undefined') && notMatched.push('no `navigator.mediaDevices`')
    (typeof navigator.mediaDevices.getUserMedia == 'undefined') && notMatched.push('no `navigator.mediaDevices.getUserMedia`')
    (typeof navigator.mediaDevices.enumerateDevices == 'undefined') && notMatched.push('no `navigator.mediaDevices.enumerateDevices`')
    (typeof RTCPeerConnection == 'undefined') && notMatched.push('no `RTCPeerConnection`')
    return notMatched
}

const resetAppFlags = ()=>{
    console.log('in resetAppFlags')
    setBtn('Idle')
    audioPlay('stop')
    callId = null
    peer = null
    callState = 'FREE'
    setBtn('Call')
    audioPlay('stop')
    app.inCall = false
    app.calltype = CALL_TYPE_VIDEO_AUDIO
    app.theDigits=''
    // if(waitAnswerTimer){
    //     clearTimeout(waitAnswerTimer)
    //     waitAnswerTimer = 0
    // }
    clearTimerTimeout('activatePeer')
    clearTimerTimeout('waitPeerAnswer')
    clearTimerTimeout('waitMyAnswerAction')
    clearTimerTimeout('postCandidatesToPeer')
    clearTimerTimeout('counter')

    // if(jobIntervalT)
    //     clearInterval(jobIntervalT)
    jobs = []
    app.isStable = false
    app.otherSideUserObj = null
    app.callTimer = 0
}



let vDomSelfLeft, vDomSelfTop, vDomBottomMax;
const getVideoDomParams = ()=>{
    // call this when window resize
    vDomSelfLeft = document.getElementById('vSelfSection').offsetLeft
    vDomSelfTop  = document.getElementById('vSelfSection').offsetTop
    vDomBottomMax = document.getElementById('v_control_section').offsetTop
}

let dragX=0, dragY=0;
const videoDragStart = (e, whereToReadXY) => {
    // console.log("drag start")
    // console.log(e)
    getVideoDomParams()
    e.stopPropagation()
    dragX=whereToReadXY.clientX
    dragY=whereToReadXY.clientY
}

let lastMoveTs = 0
const videoTouchMove = (e, whereToReadXY) => {
    // console.log(e)
    let ts = new Date().getTime();
    if(ts - lastMoveTs < 1000/60)
    {
        // avoid useless frames
        // console.log('touch event dropped')
        return
    }
    lastMoveTs = ts

    e.stopPropagation()
    let dom = document.getElementById('vSelfSection')
    let left  = vDomSelfLeft    + (whereToReadXY.clientX-dragX)
    let top   = vDomSelfTop     + (whereToReadXY.clientY-dragY)
    // console.log(`newLeft=${left}, newTop=${top}. diff:{x:${whereToReadXY.offsetX}, y:${whereToReadXY.offsetY}}. orig:{x:${vDomSelfLeft},y:${vDomSelfTop}}`)
    left  = (left<0) ? 0 : (left + dom.offsetWidth  > window.innerWidth   ? window.innerWidth  -dom.offsetWidth  : left)
    top   = (top <0) ? 0 : (top  + dom.offsetHeight > vDomBottomMax ? vDomBottomMax-dom.offsetHeight : top)
    document.getElementById('vSelfSection').style.left = left + 'px'
    document.getElementById('vSelfSection').style.top  = top  + 'px'
}


const videoDrag = (e, whereToReadXY) => {
    videoTouchMove(e, whereToReadXY);
    getVideoDomParams();
}

const getVideoConstraints = idx=>{
    if(app.calltype == CALL_TYPE_AUDIO_ONLY)
        return false;
    if(app && app.vDevices && app.vDevices.length>1)
    {
        return ( idx==0 ? {facingMode: "environment"} : {facingMode: "user"} )
    }
    return true;
}

const switchVideo = ()=>
{
    if(!videoEnabled())
    {
        console.error('Clicked switch video btn but call type='+app.calltype)
        return;
    }
    let total = app.vDevices.length
    // if(newIdx>=total)
    //     newIdx = 0
    // if(idx == newIdx)
        // return
    document.getElementById('videoSelf').srcObject = null

    let senders = pc.getSenders();
    console.log(senders)

    let theSenderTrack = null

    let idx = 0;
    let theSerderIdx = -1;
    senders.forEach(i=>{
        console.log(`the kind of senders[${i}] is ${i.track.kind}`)
        if(i.track && i.track.kind == "video")
        {
            i.track.stop()
            theSenderTrack = i
            theSerderIdx = idx;
            console.log(`stopped senders[${i}]`)
            console.log(i)
            // pc.removeTrack(i)
        }
        else
        {
        }
        idx++;
    })
        // senders[1].replaceTrack(null)
    if(theSerderIdx == -1)
    {
        console.error(`in switchVideo: unable to locate the sender idx`)
        return
    }

    let otherCamDirection = camDirection==1?0:1;
    navigator.mediaDevices.getUserMedia({video:getVideoConstraints(otherCamDirection)})
    .then(media=>{
        theMedia = media
        console.log('media')
        console.log(media)
        let tracks = media.getTracks()
        console.log('tracks')
        console.log(tracks)

        localStream = media
        camDirection = otherCamDirection;

        let vSelf = document.getElementById('videoSelf')

        if(vSelf)
        {
            vSelf.onloadeddata = ()=>{
                if(!isPlaying(vSelf))
                    vSelf.play()
            }
        }

        senders[theSerderIdx].replaceTrack(tracks[0])
        .catch(e=>{
            console.log('Exception when replaceTrack:');
            console.log(e)
            console.log(senders[1])
        })
/*        senders.forEach(s=>{
            console.log(s)
            if(tracks && tracks.length && tracks[0].type == 'videoinput') {
            // if(s.track?.type == tracks[0]?.type) {
                s.replaceTrack(tracks[0])
                .catch(e=>{
                    console.log('exception when replaceTrack:');
                    console.log(e)
                    console.log(senders[1])
                })
            }
        })*/

        // tracks.forEach(t=>pc.addTrack(t, localStream))
        let newOffer = pc.createOffer().catch(e=>{
            console.log('Exception when switchVideo')
            console.log(e)
        })
        console.log(newOffer)
        // pc.setLocalDescription(newOffer)

        vSelf.srcObject = localStream

            // localStream.getTracks().forEach(i=>{
            //     pc.removeTrack
            // })
        // then(tracks=>{
        //     console.log(tracks)
        // })
    }, error=>{console.log('getUserMedia fail');        console.log(error); pc.removeTrack(theSenderTrack)})
    .catch(e=>{console.log('getUserMedia exception');   console.log(e);     pc.removeTrack(theSenderTrack)})
}

function refresh() {
    window.location.href=window.location.href;
}


const getDateStr = ()=>{
    return formaData(new Date());
}
function formaData(timer) {
    const year = timer.getFullYear()
    const month = timer.getMonth() + 1
    const day = timer.getDate()
    const hour = timer.getHours()
    const minute = timer.getMinutes()
    const second = timer.getSeconds()
    const milisecond = timer.getMilliseconds()
    return `${pad(hour)}:${pad(minute)}:${pad(second)}.${pad(milisecond,4)}`
}

function pad(timeEl, total = 2, str = '0') {
    var tstr = timeEl.toString()
    var lack = (total - tstr)
    return  (lack>0?str*lack:'') + tstr
    // return timeEl.toString().padStart(total, str) // not supported in old js
}

console.oldlog = console.log
console.olderror = console.error
msgBuf = []

const objToStr = m=>{
    if(typeof m !== 'object')
        return '[Unkown type]';
    var retArr = [];
    for( var i in m)
    {
        if(typeof m[i] == 'number' && m[i]<100000)
            retArr.push(''+i+':'+m[i])
        else if(typeof m[i] == 'string'){
            if(m[i].length <= 11)
                retArr.push(''+i+':'+m[i])
            else
                retArr.push(''+i+':'+m[i].substring(0,11)+'...')
        }
        else
            retArr.push(''+i);
    }
    return retArr.join(',')
}

console.log=m=>{
    if(typeof m == 'string' || typeof m == 'number' || typeof m == 'boolean')
    {
        msgBuf.push('[info]  '+ getDateStr() + ' :: ' + m)
    }
    else
    {
        let s = Object.prototype.toString.call(m)
        if( s == '[object Array]' )
            s += ' (' + m.length + ')'
        else if ( s=='[object Object]')
            // s += ' keys:{'+Object.keys(m).join(',')+'}'
            s += ' '+objToStr(m)
        msgBuf.push('[info]  '+getDateStr() + ' :: ' + (s))
    }
    console.oldlog(m)
}


console.error=m=>{
    if(typeof m == 'string' || typeof m == 'number' || typeof m == 'boolean')
    {
        msgBuf.push('[error] '+getDateStr() + ' :: ' + m)
    }
    else
    {
        let s = Object.prototype.toString.call(m)
        if( s == '[object Array]' )
            s += ' (' + m.length + ')'
        else if ( s=='[object Object]')
            // s += ' keys:{'+Object.keys(m).join(',')+'}'
            s += ' '+objToStr(m)

        msgBuf.push('[error] '+getDateStr() + ' :: ' + (s))
    }
    console.olderror(m)
}

let pushItv = 0;
let uploading = false
function uploadLog()
{
    if(uploading)
        return

    if(msgBuf.length)
    {
        // todo :
        let theLen = msgBuf.length
        jQuery.post(serverUrl+'LogTool/postLog',{msgBuf:msgBuf, uniq:uniq},function(res) {
            if(res.code == 0)
            {
                msgBuf.splice(0,theLen)
            }
        },'JSON').always(function() { uploading = false; });
    }
}
pushItv = setInterval(uploadLog, 500)


    function globalSetUsers(userList)
    {
        app.setUsers(userList)
    }


</script>
</body>
</html>
