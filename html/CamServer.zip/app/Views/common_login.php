<style type="text/css">
    /* layer login */
    #commonLoginApp {
        visibility: hidden;
        text-align: center;
        display: flex;
        align-items: center;
        justify-content: center;
        background: rgba(255,255,255,.9);
    }
    #commonLoginApp.show {
        visibility: visible;
    }
    #loginForm {
        margin: auto;
    }
    #commonLoginApp input {text-align: center;}

</style>

<div id="commonLoginApp" class="container mt-5 layer4" :class="needLogin?'fullpageLayer show':'fullpageLayer'">
    <form v-on:submit.prevent="logIn" id="loginForm">
        <label class="form-label">
            呼叫号码
            <input class="form-control" type="tel"     v-model="callnumber"     placeholder="1xxxxxxxxxx">
        </label>
        <label class="form-label">
            密码
            <input class="form-control" type="password" v-model="password"   placeholder="******">
        </label>

        <button class="btn btn-block btn-primary" type="submit">登录</button>
    </form>
</div>
<script src="/common_assets/js/crypto-js.min.js"></script>
<script>
    let uid = <?php echo \Config\Services::session()->get('uid')??0?>;
    let commonSesId = localStorage.getItem('commonSesId')
    let commonLoginApp = new Vue({
        el:'#commonLoginApp',
        data:{ needLogin:uid?false:true, callnumber:'', password:'abcde'},
        methods:{
            logIn:function()
            {
                jQuery.post('/userApi/commonLogin', {callnumber:commonLoginApp.callnumber, passhash:CryptoJS.MD5(commonLoginApp.password).toString(),commonSesId:commonSesId}, function(res){
                    if(res.code){
                        // alert(res.msg)
                        modalApp.error({content:res.msg})
                    }
                    else
                    {
                        commonLoginApp.needLogin = false
                        uid = res.obj.uid
                        u = res.obj
                        app.u = res.obj
                        commonSesId = res.obj.commonSesId
                        // con();
                        window.location.href = window.location.href
                    }
                },'JSON')
            },
            logOut:function () {
                jQuery.post('/userApi/commonLogout', {uniq:uniq}, function(res){
                    if(res.code){
                        // alert(res.msg)
                        modalApp.error({content:res.msg})
                    }
                    else
                    {
                    // commonLoginApp.needLogin = false
                    // uid = res.obj.uid
                    // u = res.obj
                    // app.u = res.obj
                    // con();
                    }
                },'JSON')
            }
        }
    })
</script>

