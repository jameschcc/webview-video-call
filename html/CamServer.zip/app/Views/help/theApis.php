<div class="container" id="apiApp">
    <h2>API列表</h2>
    <p class="globalReturnDesc" v-html="globalReturnDesc"></p>
    <div v-for="m in APIs">
        <h3>{{m.methodName}}</h3>
        <p class="methodUrl">请求地址： <a target="_blank" :href="m.url">{{m.url}}</a> <i class="bi bi-link-45deg"></i></p>
        <div class="params">
            <h4>参数</h4>
            <ul v-if="m.params && m.params.length">
                <li v-for="p in m.params">
                   <span class="paramName">{{p.paramName}}</span>
                   <span class="paramDesc">{{p.paramDesc}}</span>
                   <span class="paramMethod">{{p.paramMethod}}</span>
               </li>
           </ul>
           <p v-else>{{noParamDesc}}</p>
       </div>
       <div class="methodReturns">
        <h4>返回值</h4>
        <p class="thisRetDesc">{{m.thisRetDesc}}</p>
        <table class="table" v-if="m.returnCodes && m.returnCodes.length">
            <thead>
                <tr><th>返回值code</th><th>错误信息msg</th></tr>
            </thead>
            <tbody>
                <tr v-for="r in m.returnCodes">
                    <td>{{r.retCode}}</td>
                    <td>{{r.retDesc}}</td>
                </tr>
            </tbody>
        </table>
    </div>
</div>
</div>

<script>
    let apiApp = new Vue(
    {
        el:'#apiApp',
        data:{
            noParamDesc:'此api无需提供参数',
            globalReturnDesc:'获取方式为http request<br>请求会返回一个JSON对象： {code:Integer, msg:String/null, obj:Object/null} 。 <br>code=0表示成功，obj中会携带返回的对象。 <br>code>0表示失败，msg为相应的失败信息。',
            APIs:[
            {
                methodName:"呼叫号码查找单条用户信息",
                url:"/userApi/getUserByCallnumber",
                thisRetDesc:"code=0时，用户对象存放于obj中",
                params:[{paramName:'callnumber',paramDesc:'待查找的呼叫号码',paramMethod:'GET/POST'}],
                returnCodes:
                <?php
                $retCodes=[];
                $rets = [PARAM_ERROR,USER_NOT_FOUND];
                global $failures;
                foreach ($rets as $r) {
                    $k = parseFailCode($r);
                    array_push($retCodes,[
                        'retCode'=>$k,
                        'retDesc'=>$failures[$k][1]
                    ]);
                }
                echo json_encode($retCodes);
                ?>
            },


            {
                methodName:"获取随机呼叫号码",
                url:"/userApi/getRandomCallnumber",
                thisRetDesc:"code=0时，号码存放于obj中",
                params:[],
                returnCodes:<?php
                $retCodes=[];
                $rets = [];
                global $failures;
                foreach ($rets as $r) {
                    $k = parseFailCode($r);
                    array_push($retCodes,[
                        'retCode'=>$k,
                        'retDesc'=>$failures[$k][1]
                    ]);
                }
                echo json_encode($retCodes);
                ?>
            },


            {
                methodName:"注册呼叫号码",
                url:"/userApi/registerCallnumber",
                thisRetDesc:"code=0时，用户信息存放于obj中；否则，错误信息存放于msg中",
                params:[
                    {paramName:'callnumber',paramDesc:'待绑定的呼叫号码',paramMethod:'POST'},
                    {paramName:'uname',paramDesc:'呼叫界面显示的用户名',paramMethod:'POST'},
                    {paramName:'avatarSrc',paramDesc:'用户头像地址(非必须)',paramMethod:'POST'}
                    ],
                returnCodes:<?php
                $retCodes=[];
                $rets = [PARAM_ERROR,CALLNUMBER_INVALID,REGISTER_FAILED];
                global $failures;
                foreach ($rets as $r) {
                    $k = parseFailCode($r);
                    array_push($retCodes,[
                        'retCode'=>$k,
                        'retDesc'=>$failures[$k][1]
                    ]);
                }
                echo json_encode($retCodes);
                ?>
            },

            {
                methodName:"注销呼叫号码",
                url:"/userApi/deregisterCallnumber",
                thisRetDesc:"code=0时，注销成功。如果此用户号码不存在，也返回code=0",
                params:[
                    {paramName:'callnumber',paramDesc:'待注销的呼叫号码',paramMethod:'POST'},
                    ],
                returnCodes:<?php
                $retCodes=[];
                $rets = [PARAM_ERROR,USER_NOT_FOUND,DEREGISTER_FAILED];
                global $failures;
                foreach ($rets as $r) {
                    $k = parseFailCode($r);
                    array_push($retCodes,[
                        'retCode'=>$k,
                        'retDesc'=>$failures[$k][1]
                    ]);
                }
                echo json_encode($retCodes);
                ?>
            },

            {
                methodName:"修改某个呼叫号码用户的信息",
                url:"/userApi/modifyCallnumberInfo",
                thisRetDesc:"code=0时，用户信息存放于obj中；否则，错误信息存放于msg中",
                params:[
                    {paramName:'callnumber',paramDesc:'待绑定的呼叫号码',paramMethod:'POST'},
                    {paramName:'uname',paramDesc:'呼叫界面显示的用户名',paramMethod:'POST'},
                    {paramName:'avatarSrc',paramDesc:'用户头像地址(非必须)',paramMethod:'POST'}
                    ],
                returnCodes:<?php
                $retCodes=[];
                $rets = [PARAM_ERROR,CALLNUMBER_INVALID,REGISTER_FAILED];
                global $failures;
                foreach ($rets as $r) {
                    $k = parseFailCode($r);
                    array_push($retCodes,[
                        'retCode'=>$k,
                        'retDesc'=>$failures[$k][1]
                    ]);
                }
                echo json_encode($retCodes);
                ?>
            },

            {
                methodName:"全部用户信息",
                url:"/userApi/getAllUsers",
                thisRetDesc:"code=0时，用户列表（数组）存放于obj中",
                params:[],
                returnCodes:<?php
                $retCodes=[];
                $rets = [USER_NOT_FOUND];
                global $failures;
                foreach ($rets as $r) {
                    $k = parseFailCode($r);
                    array_push($retCodes,[
                        'retCode'=>$k,
                        'retDesc'=>$failures[$k][1]
                    ]);
                }
                echo json_encode($retCodes);
                ?>
            },

            ]
        },
        methods:{}
    })
</script>

<style type="text/css">

    
    #apiApp {font-family: hack, consolas, monospace;}
    #apiApp h4 {color: brown;}
    #apiApp .params span {display: inline-block; padding: .2em .3em;}
    #apiApp .paramName {background: #e0e0e0; border-radius: .2em; font-weight: bold;}
    #apiApp .paramMethod {background: #e0e0e0; border-radius: .2em; scale: 0.8;}

</style>
