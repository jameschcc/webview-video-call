<div class="container">
    <h3>欢迎使用</h3>
    <ul>
        <li><a class="btn btn-small btn-success" href="/admin/user_manage"><i class="bi bi-person-fill"> </i>用户信息维护</a></li>
        <li><a class="btn btn-small btn-success" href="/admin/user_manage"><i class="bi bi-people"> </i>用户分组管理</a></li>
    </ul>
</div>
