<div class="container">
    <h2><i class="bi bi-database"> </i>数据库维护</h2>
    <div class="card border-danger mb-3">
      <div class="card-body text-danger">
      本页面提供呼叫系统数据库的管理维护功能，请谨慎操作。在重置数据库和数据表之前务必做好备份。</div>
  </div>
</div>

<div class="container">
    <div id="app">
        <h3>数据库操作</h3>
        <ul id="actions" class="listUl">
            <li v-for="i,idx in links" class="">
                <p>
                    <button class="btn" :class="i.color?'btn-'+i.color:'btn-primary'" v-on:click="btnclick(idx)" :data-href="i.link"><i v-if="i.icon" :class="'bi bi-'+i.icon"> </i> {{i.cn}}</button>
                </p>
            </li>
        </ul>

        <div>
            <h3>用户</h3>
            <?php
            include __DIR__.'/../common/userlist.php';
            ?>

        </div>
        <div>
            <h3>用户分组</h3>
            <?php
            include __DIR__.'/../common/usergrouplist.php';
            ?>

        </div>

        <div>
            <h3>登录状态</h3>
            <div>这是当前的登录状态信息。</div>
            <ul>
                <li v-for="i,idx in uniqs" class="">
                    <div>序号:{{i.uniq_idx}}  用户UID:{{i.uid}} 识别码:{{i.uniq}} 系统特征值:{{i.sessionStr}}</div>
                </li>
            </ul>
            <p>数量: {{uniqs.length}}</p>
        </div>
        <div>
            <h3>呼叫列表</h3>
            <div>这是当前的呼叫信息。</div>
            <ul>
                <li v-for="i,idx in calls" class="">
                    <div>编号:{{i.callId}} 主叫方识别码:{{i.cguniq}} 被叫方识别码:{{i.cduniq}}</div>
                </li>
            </ul>
            <p>数量: {{calls.length}}</p>
        </div>
    </div>
</div>
<style>
    .userEditBtn { visibility:hidden; }
</style>
<script>
    let theApp = new Vue({
        el:"#app",
        data:{
            links:[
                {title:'reset db',      cn:'建立数据库', link:'/databaseApi/createDatabase',    notice:'是否建立数据库', color:'warning', action:'refresh', icon:'database-add'},
                {title:'reset tables',  cn:'重置数据表', link:'/databaseApi/api_resetTables',   notice:'是否重置数据表', color:'danger', action:'refresh', icon:'recycle'},
                {title:'reset calls',  cn:'重置呼叫表', link:'/databaseApi/api_resetCallsTable',   notice:'是否重置呼叫表', color:'danger', action:'refresh', icon:'telephone-x'},
                {title:'reset logins',  cn:'重置登录表', link:'/databaseApi/api_resetUniqsTable',   notice:'是否重置登录表', color:'danger', action:'refresh', icon:'people'},
                {title:'add test data',cn:'插入默认测试数据', link:'/databaseApi/addTestData',   notice:"插入测试数据将会先清除所有数据表，确定这样操作吗？", color:'danger', action:'refresh', icon:'gear-wide-connected'},
                {title:'export database',cn:'备份数据库', link:'/databaseApi/api_exportDatabase',   notice:null, color:'success', action:'notice', icon:'database-fill-down'},


                ],
            users:[],
            usergroups:[],
            uniqs:[],
            calls:[],
        },
        methods:{
            btnclick:function(idx) {
                let url = this.links[idx].link
                if(this.links[idx].notice)
                {
                    if(!confirm(this.links[idx].notice))
                        return;
                }
                let lnk = this.links[idx]
                jQuery.get(url,function(res){
                    if(res.code)
                    {
                        alert(res.msg)
                    }
                    else
                    {
                        if(lnk.action=='refresh')
                            window.location.href = window.location.href
                        else if(lnk.action=='notice')
                            modalApp.notice({content:'操作成功'+(res.msg?': '+res.msg:'')});
                    }
                },'JSON')
            },
            loadUsers:function()
            {
                jQuery.get('/userApi/getAllUsers',function(res){
                    if(res.code == 0)
                    {
                        Vue.set(theApp, 'users', res.obj)
                    }
                },'JSON')
            },
            loadUserGroups:function()
            {
                jQuery.get('/userApi/getAllUserGroups',function(res){
                    if(res.code == 0)
                    {
                        Vue.set(theApp, 'usergroups', res.obj)
                    }
                },'JSON')
            },
            loadUniqs:function()
            {
                jQuery.get('/userApi/getAllUniqs',function(res){
                    if(res.code == 0)
                    {
                        Vue.set(theApp, 'uniqs', res.obj)
                    }
                },'JSON')
            },
            loadCalls:function()
            {
                jQuery.get('/callControl/getAllCalls',function(res){
                    if(res.code == 0)
                    {
                        Vue.set(theApp, 'calls', res.obj)
                    }
                },'JSON')
            },
        },
        created:function(){
            this.loadUsers();
            this.loadUniqs();
            this.loadCalls();
            this.loadUserGroups();
        }
    })
</script>