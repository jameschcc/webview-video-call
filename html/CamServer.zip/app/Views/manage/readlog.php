<?php
function echoline($ln){
return $ln;
}
function echohtml()
{
}

$fp = fopen('/usr/share/nginx/html/logs/clientlogs/2024-03-18.log', "r");
if($fp)
{
    while (($buffer = fgets($fp, 200)) !== false) {
        echo echoline($buffer);
    }
    if (!feof($fp)) {
        echo "Error: unexpected fgets() fail\n";
    }
    fclose($fp);
}
