<div class="container">
    <div id="app">
        <ul id="actions" class="listUl">
            <li v-for="i,idx in links" class="linkLi">
                <div class="btn" v-on:click="btnclick(idx)" :data-href="i.link">{{i.cn}}</div>
            </li>
        </ul>

        <div>
            用户
            <table class="table">
                <thead>
                    <tr>
                        <th>编号</th>
                        <th>呼叫号码</th>
                        <th>名称</th>
                        <!-- <th>hash</th> -->
                    </tr>
                </thead>
                <tbody>
                    <tr v-for="i,idx in users">
                        <td>{{i.uid}}</td>
                        <td>{{i.callnumber}}</td>
                        <td>{{i.uname}}
                            <btn class="userEditBtn btn btn-sm btn-primary" v-on:click="startEdit(idx)">编辑</btn>
                        </td>
                        <!-- <td>{{i.passhash}}</td> -->
                    </tr>
                </tbody>
            </table>
            <p>数量: {{users.length}}</p>
        </div>

        <form v-on:submit.prevent="submitForm" class="form">
            <label class="">用户名称
                <input class="form-control input" type="uname" v-on:change="checkForm" v-model="uname" name="">
            </label>
            <label class="">呼叫号码
                <input class="form-control input" type="callnumber" v-on:change="checkForm" v-model="callnumber" name="">
            </label>
            <label class="">密码
                <input class="form-control input" type="password" v-on:change="checkForm" v-model="password" name="">
            </label>
            <label class="">分组
                <!-- <input class="form-control input" type="select" v-on:change="checkForm" v-model="ugroup" name=""> -->
                <select class="form-control form-select-sm" aria-label=".form-select-sm example" v-model="ugroup">
                    <option value="1" selected>无分组</option>
                    <option value="2">科室</option>
                    <option value="3">员工</option>
                    <option value="4">作业人员</option>
                </select>
            </label>
            <br>
            <button class="btn btn-success" type="submit" :disabled="addBtnDisabled">添加</button>
<!--             <ul v-if="formErrors.length">
                <li v-for="i in formErrors">{{i}}</li>
            </ul> -->
        </form>
    </div>
</div>

<style type="text/css">
    .userEditBtn { visibility:hidden; }
    tr:hover .userEditBtn { visibility:visible; }
</style>

<script>
    let theApp = new Vue({
        el:"#app",
        data:{
            links:[
                // {title:'reset db',   cn:'建立数据库', link:'/databaseApi/createDatabase',    notice:'是否建立数据库'},
                // {title:'reset db',   cn:'重置数据库', link:'/databaseApi/api_resetTables',       notice:'是否重置数据库'}
                ],
            users:[],
            uniqs:[],
            calls:[],

            formErrors:[],
            // uname:null,
            // password:null,
            // callnumber:null,
            uname:'abcde',
            password:'abcde',
            callnumber:'13088888888',
            addBtnDisabled:true
        },
        methods:{
            btnclick:function(idx) {
                let url = this.links[idx].link
                if(this.links[idx].notice)
                    if(!confirm(this.links[idx].notice))
                        return;
                    jQuery.get(url,function(res){
                        if(res.code)
                        {
                            alert(res.msg)
                        }
                    },'JSON')
                },
                loadUsers:function()
                {
                    jQuery.get('/userApi/getAllUsers',function(res){
                        if(res.code == 0)
                        {
                            Vue.set(theApp, 'users', res.obj)
                        }
                    },'JSON')
                },
                checkForm:function()
                {
                    this.formErrors = []
                    if (!this.uname) {
                        this.formErrors.push("未填写用户名称");
                    }
                    else if (!this.validUname(this.uname)) {
                        this.formErrors.push('用户名称应设置为1-20个字符');
                    }

                    if (!this.callnumber) {
                        this.formErrors.push('未填写呼叫号码');
                    } else if (!this.validCallnumber(this.callnumber)) {
                        this.formErrors.push('呼叫号码为1开头的11位数字');
                    }

                    if (!this.password) {
                        this.formErrors.push('未填写密码');
                    } else if (!this.validPass(this.password)) {
                        this.formErrors.push('密码为5-20位字符');
                    }

                    if (!this.formErrors.length) {
                        this.addBtnDisabled = false;
                        console.log(this.addBtnDisabled)
                        return true;
                    }
                    this.addBtnDisabled = true;
                    console.log(this.addBtnDisabled)
                    return false;
                },
                validUname: function (uname) {
                    var re = /^\S{1,20}$/;
                    return re.test(uname);
                },
                validPass: function (password) {
                    var re = /^[\w\d]{5,20}$/;
                    return re.test(password);
                },
                validCallnumber: function (callnumber) {
                    var re = /^1\d{10}$/;
                    return re.test(callnumber);
                },
                created:function(){
                    this.loadUsers();
                },
                submitForm:function()
                {
                    if(!this.checkForm()){
                        error(this.formErrors);
                        return false;
                    }
                    jQuery.post('/userApi/addUser',
                        {uname:this.uname, passhash: btoa(this.password), callnumber:this.callnumber},
                        function(res)
                        {
                            console.log(res)
                            if(res.code)
                                error(res.msg);
                            else
                            {
                                window.location.href = window.location.href
                            }
                        },
                        'json'
                        )
                },
                startEdit:function(idx){
                    // [uname, password, callnumber] = {users[idx].uname, users[]}
                }
            },
            created:function(){
                this.loadUsers();
            }
        })
    </script>