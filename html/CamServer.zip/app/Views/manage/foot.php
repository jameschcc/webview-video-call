<!-- Button trigger modal -->
<!-- <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#modalCenter">

</button> -->


<?php
if(!isset($not_need_admin))
    include __DIR__ . '/../common_login.php';
include __DIR__ . '/../common/common_modal.php';
?>


<style type="text/css">
    #site-nav { margin-bottom:2em; }
    .container h3 { border-bottom: 1px solid; margin-top: 1em; margin-bottom: .5em; padding-bottom: 1em; padding-top: 1em; }
    .container li {margin-bottom: .5em;}
    .logoutBtn {margin-left: 1em;}
</style>
</body>
</html>