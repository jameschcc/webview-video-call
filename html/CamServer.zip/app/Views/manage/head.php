<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, minimum-scale=1, maximum-scale=1">
    <title></title>
    <script src='/common_assets/js/jquery-3.7.1.min.js'></script>
    <script src='/common_assets/js/socket.io.js'></script>
    <script src='/common_assets/js/vue.js'></script>
    <script src='/common_assets/bootstrap-4.0.0-dist/js/bootstrap.min.js'></script>
    <link  href='/common_assets/bootstrap-4.0.0-dist/css/bootstrap.min.css' rel="stylesheet">
    <link  href='/common_assets/bootstrap-icons-1.11.2/font/bootstrap-icons.min.css' rel="stylesheet">
</head>
<body>

    <nav class="navbar navbar-expand-lg navbar-dark bg-dark" id="site-nav">
        <a class="navbar-brand" href="/"><i class="bi bi-camera-video"></i> 视频呼叫子系统</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarColor01" aria-controls="navbarColor01" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarColor01">
            <ul class="navbar-nav mr-auto" id="navUl">
                <li class="nav-item" :class="i.active?'active':''" v-for="i in urls">
                    <a class="nav-link" :href="i.link">
                        <i :class="'bi bi-'+i.icon"> </i>{{i.title}}
                        <span v-if="i.active" class="sr-only">(当前)</span>
                    </a>
                </li>
            </ul>
            <form class="form-inline" action="/search">
                <input class="form-control mr-sm-2" type="search" placeholder="用户名或分组" aria-label="Search">
                <button class="btn btn-outline-info my-2 my-sm-0" type="submit">搜索用户 <i class="bi bi-search"></i></button>
            </form>
            <?php
            if(\Config\Services::session()->get('uid'))
            print_r( "<div class='logoutBtn'><button class='btn btn-sm btn-default' onclick='logout()'>退出登录</button></div>" );
            ?>
        </div>
    </nav>

    <script defer="defer">
        let navUlApp=new Vue({
            el:'#navUl',
            data:{
                urls:[],
                theurls:[
                    {title:'主页',icon:'house',link:'/'},
                    {title:'用户管理',icon:'person-plus',link:'/admin/user_manage'},
                    {title:'分组管理',icon:'people',link:'/admin/group_manage'},
                    {title:'数据库维护',icon:'bi-database-check',link:'/admin/db_manage'},
                    ]
            },
            methods:{
                loadUrls:function(){
                    this.urls=this.theurls
                    for(i=0;i<this.urls.length;i++)
                    {
                        if(this.urls[i].link.startsWith(window.location.pathname))
                        {
                            this.urls[i].active = true
                            break
                        }
                        else
                            this.urls[i].active = false
                    }
                }
            },
            created:function(){this.loadUrls()}
        });
    </script>
    <script type="text/javascript">
        const logout = ()=>{
            jQuery.get('/userApi/commonLogout',function(res){
                if(res.code == 0)
                {
                    window.location.href =
                    window.location.href
                }
            },'JSON')
        }
    </script>