<div class="container">
    <div id="app">
        <div>
            <h3><i class="bi bi-people-fill"></i> 用户组</h3>
            <?php
            include __DIR__.'/../common/usergrouplist.php';
            ?>

        </div>

        <form v-on:submit.prevent="addUserGroup" class="form">
            <label class="">用户组名称
                <input class="form-control input" type="ugroupName" v-model="ugroupName" name="">
            </label>

            <div class="card border-danger mb-3" style="max-width: 50vw;" v-if="formErrors.length" id="formErrors">
              <div class="card-header">请修改以下表项</div>
              <div class="card-body text-danger">
                <ul class="card-text">
                    <li v-for="i in formErrors">{{i}}</li>
                </ul>
            </div>
        </div>


        <button class="btn btn-success" type="submit" :disabled="ugroupName.length==0">添加</button>

    </form>
</div>
</div>

<style type="text/css">
    .userEditBtn { visibility:hidden; }
    tr:hover .userEditBtn { visibility:visible; }
    #formErrors ul {margin: 0;}
    #formErrors {margin-bottom: 1em;}
</style>

<script>
    let theApp = new Vue({
        el:"#app",
        data:{
            formErrors:[],
            usergroups:[],
            ugroupName:'',
        },
        methods:{
                loadUserGroups:function()
                {
                    jQuery.get('/userApi/getAllUserGroups',function(res){
                        if(res.code == 0)
                        {
                            Vue.set(theApp, 'usergroups', res.obj)
                        }
                    },'JSON')
                },
                addUserGroup:function()
                {
                    jQuery.post('/userApi/addUserGroup',{ugroupName:theApp.ugroupName},function(res){
                        if(res.code == 0)
                        {
                            // Vue.set(theApp, 'usergroups', res.obj)
                            window.location.href = window.location.href
                        }
                    },'JSON')
                }
            },
            created:function(){
                this.loadUserGroups();
            }
        })
    </script>