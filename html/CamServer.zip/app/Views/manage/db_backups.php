        <div class="container">
            备份文件列表
            <ul id="dbBackups">
                <li v-for="i,idx in dbBackupFiles">
                    {{i}}
                </li>
            </ul>
            <p>数量: {{uniqs.length}}</p>
        </div>


<script>
    dbBackupsApp = new Vue({
        el:'#dbBackups',
        data:{dbBackupFiles:[]}
        methods:{
            loadDbBackups:()=>{
                $.get('/manage/api_listbackups',function(res){
                    console.log(backups)
                    if(res.code)
                    {
                        
                    }
                    res.obj
                },'JSON')
            }
        }
    })
</script>