<div class="container">
    <div id="app">
        <ul id="actions" class="listUl">
            <li v-for="i,idx in links" class="linkLi">
                <div class="btn" v-on:click="btnclick(idx)" :data-href="i.link">{{i.cn}}</div>
            </li>
        </ul>

        <div>
            <h4><i class="bi bi-person-fill"></i> 用户列表</h4>
            <?php
            include __DIR__.'/../common/userlist.php';
            ?>
        </div>

        <div id="editingForm">
            <h3>{{editMode=='new' ? '新增用户' : '修改用户:Id=#'+uid}}</h3>
            <div class="card" v-if="editMode=='modify' && uid && uname">
              <div class="card-header">正在修改 用户 "{{uname}}"</div>
              <div class="card-body text-danger">
                <button @click="cancelEdit" class="btn btn-primary btn-sm">取消编辑</button>
            </div>
        </div>
        <form v-on:submit.prevent="submitForm" class="form">
            <label class="">用户名称
                <input class="form-control input" name="uname" type="text" v-on:change="checkForm" v-model="uname" name="">
            </label>
            <label class="">呼叫号码
                <input class="form-control input" name="callnumber" type="tel" v-on:change="checkForm" v-model="callnumber" placeholder="1xxxxxxxx" name="">
            </label>
            <label class="">密码
                <input class="form-control input" type="password" v-on:change="checkForm" v-model="password" placeholder="******" name="">
            </label>
            <label class="">分组
                <!-- <input class="form-control input" type="select" v-on:change="checkForm" v-model="ugroup" name=""> -->
                <select class="form-control form-select-sm" v-model="ugroupId">
                    <option :value="i.ugroupId" v-for="i in usergroups" :selected="ugroupId==i.ugroupId">{{i.ugroupName}}</option>
                </select>
            </label>
            <br>

            <div class="card border-danger mb-3" style="max-width: 50vw;" v-if="formErrors.length" id="formErrors">
              <div class="card-header">请修改以下表项</div>
              <div class="card-body text-danger">
                <ul class="card-text">
                    <li v-for="i in formErrors">{{i}}</li>
                </ul>
            </div>
        </div>


        <button class="btn btn-success" type="submit" :disabled="addBtnDisabled">{{editMode=='new' ? '添加' : '确定'}}</button>

    </form>
</div>
</div>
</div>

<style type="text/css">
    .userEditBtn { visibility:hidden; }
    tr:hover .userEditBtn { visibility:visible; }
    #formErrors ul {margin: 0;}
    #formErrors {margin-bottom: 1em;}
</style>

<script>
    let theApp = new Vue({
        el:"#app",
        data:{
            links:[
                // {title:'reset db',   cn:'建立数据库', link:'/databaseApi/createDatabase',    notice:'是否建立数据库'},
                // {title:'reset db',   cn:'重置数据库', link:'/databaseApi/api_resetTables',       notice:'是否重置数据库'}
                ],
            users:[],
            uniqs:[],
            calls:[],

            formErrors:[],
            // uname:null,
            // password:null,
            // callnumber:null,
            uname:'abcde',
            password:'abcde',
            callnumber:'13088888888',
            addBtnDisabled:true,
            usergroups:[],
            ugroupId:2,
            uid:0,
            editMode:'new',
            defaultU:{
                uname:'abcde',
                password:'abcde',
                callnumber:'13088888888',
                ugroupId:2,
                uid:0,

            }
        },
        methods:{
            btnclick:function(idx) {
                let url = this.links[idx].link
                if(this.links[idx].notice)
                    if(!confirm(this.links[idx].notice))
                        return;
                    jQuery.get(url,function(res){
                        if(res.code)
                        {
                            alert(res.msg)
                        }
                    },'JSON')
                },
                loadUsers:function()
                {
                    jQuery.get('/userApi/getAllUsers',function(res){
                        if(res.code == 0)
                        {
                            Vue.set(theApp, 'users', res.obj)
                        }
                    },'JSON')
                },
                checkForm:function()
                {
                    this.formErrors = []
                    if (!this.uname) {
                        this.formErrors.push("需填写用户名称");
                    }
                    else if (!this.validUname(this.uname)) {
                        this.formErrors.push('用户名称应设置为1-20个字符');
                    }

                    if (!this.callnumber) {
                        this.formErrors.push('需填写呼叫号码');
                    } else if (!this.validCallnumberStart(this.callnumber)) {
                        this.formErrors.push('呼叫号码为1开头');
                    }
                    else if (!this.validCallnumber(this.callnumber)) {
                        this.formErrors.push('呼叫号码为11位数字');
                    }

                    if (!this.password) {
                        this.formErrors.push('需填写密码');
                    } else if (!this.validPass(this.password)) {
                        this.formErrors.push('密码为4-10位字符');
                    }

                    if (!this.formErrors.length) {
                        this.addBtnDisabled = false;
                        console.log(this.addBtnDisabled)
                        return true;
                    }
                    this.addBtnDisabled = true;
                    console.log(this.addBtnDisabled)
                    return false;
                },
                validUname: function (uname) {
                    var re = /^\S{1,20}$/;
                    return re.test(uname);
                },
                validPass: function (password) {
                    var re = /^[\w\d]{4,10}$/;
                    return re.test(password);
                },
                validCallnumber: function (callnumber) {
                    var re = /\d{11}$/;
                    return re.test(callnumber);
                },
                validCallnumberStart: function (callnumber) {
                    var re = /^1/;
                    return re.test(callnumber);
                },
                created:function(){
                    this.loadUsers();
                },
                submitForm:function()
                {
                    if(!this.checkForm()){
                        error(this.formErrors);
                        return false;
                    }
                    if(!this.uid)
                    {

                        jQuery.post('/userApi/addUser',
                            {uname:this.uname, passhash: CryptoJS.MD5(this.password).toString(), callnumber:this.callnumber},
                            function(res)
                            {
                                console.log(res)
                                if(res.code)
                                    error(res.msg);
                                else
                                {
                                    window.location.href = window.location.href
                                }
                            },
                            'json'
                            )
                    }
                    else
                    {
                        alert('此功能尚未添加。');
                        return;
                        jQuery.post('/userApi/modifyUser',
                            {uname:this.uname, passhash: CryptoJS.MD5(this.password).toString(), callnumber:this.callnumber},
                            function(res)
                            {
                                console.log(res)
                                if(res.code)
                                    error(res.msg);
                                else
                                {
                                    window.location.href = window.location.href
                                }
                            },
                            'json'
                            )
                    }
                },
                startEdit:function(idx){
                    console.log('Editing '+idx)
                    // [this.uid, this.uname, this.password, this.callnumber, this.ugroupId]
                    // = [
                    //     this.users[idx].uid,
                    //     this.users[idx].uname,
                    //     null,
                    //     this.users[idx].callnumber,
                    //     this.users[idx].ugroupId,
                    // ]
                    this.uid= this.users[idx].uid
                    this.uname= this.users[idx].uname
                    this.password = null
                    this.callnumber= this.users[idx].callnumber
                    this.ugroupId= this.users[idx].ugroupId
                    this.editMode='modify'
                },
                loadUserGroups:function()
                {
                    jQuery.get('/userApi/getAllUserGroups',function(res){
                        if(res.code == 0)
                        {
                            Vue.set(theApp, 'usergroups', res.obj)
                        }
                    },'JSON')
                },
                cancelEdit:function(){
                    // [this.uid, this.uname, this.password, this.callnumber, this.ugroupId]
                    // = [
                    //     this.defaultU.uid,
                    //     this.defaultU.uname,
                    //     this.defaultU.password,
                    //     this.defaultU.callnumber,
                    //     this.defaultU.ugroupId,
                    // ];
                    this.uid= this.defaultU.uid
                    this.uname= this.defaultU.uname
                    this.password= this.defaultU.password
                    this.callnumber= this.defaultU.callnumber
                    this.ugroupId= this.defaultU.ugroupId
                    this.editMode='new'
                },
            },
            
            created:function(){
                this.loadUsers();
                this.loadUserGroups();
            }
        })
    </script>