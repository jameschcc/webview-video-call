<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>广播系统</title>
    <!-- <script src='/common_assets/bootstrap-4.0.0-dist/js/bootstrap.min.js'></script> -->
    <!-- <script src='/common_assets/js/socket.io.js'></script> -->
    <script src='https://cam.smallar.com:9943/common_assets/js/vue.js'></script>
    <style>
        [v-cloak] { display: none;}
    </style> 
</head>
<body>
    <h1>通知系统管理</h1>

    <div id="largeScreenDiv">
        <div id="billboardDiv" v-cloak>
            <h2>{{appTitle}}</h2>
            <div v-for="i in list">{{i}}</div>
            <form id="frm" v-html="GenForm(this.params)"></form>
            <button v-on:click="submitForm">提交</button>
        </div>
        <div id="announcementDiv" v-cloak>
            <h2>{{appTitle}}</h2>
            <div v-for="i in list">{{i.ann_content}}</div>
        </div>
        <div id="scheduleDiv" v-cloak>
            <h2>{{appTitle}}</h2>
            <div v-for="i in list">{{i}}</div>
        </div>
    </div>

    <script>
        const DATA_SERVER   = 'https://cam.smallar.com:9943'
        // const SOCKET_SERVER = 'wss://192.168.31.254:8801'
        const SOCKET_SERVER = 'wss://cam.smallar.com:8801'
        let   MODE = localStorage.getItem('display_mode') ?? null
        const setMode = m => {MODE = m; localStorage.setItem('display_mode', m)}


// FancyButton renders slot content in its own template
        const GenForm = (params) => {
            console.log(params)
            let ret = ''
            params.forEach(i=>{
                let line = `<div class="form-control"><p>${i.cn}</p>`
                switch(i.typ){
                case 'text':
                    line += `<textarea name="${i.name}" type="text"></textarea>`
                    break;
                case 'enum':
                    let options = ''
                    for(var e in i.enum) {let cn=i.enum[e]; options+=`<label><input type="radio" name="${i.name}" value="${e}" ${cn=='图片'?"checked":''}/>${cn}</label> `}
                    line += options
                    break;
                case 'datetime':
                    line += `<input name="${i.name}" type="datetime-local"
                    value="2018-06-12T19:30"
                    min="2018-06-07T00:00"
                    max="2018-06-14T00:00" />`
                    break;
                default: break;
                }
                line += '</div>'
                ret += line
            })
            return ret;
        }

        let billboardDiv = new Vue({
            el:'#billboardDiv',
            data:{
                appTitle:'宣传区',
                pictures:[],
                videos:[],
                texts:[],
                ts:0,
                list:[],
                params:[
                    {name:'pst_type', typ:'enum',enum:{image:'图片',video:'视频',text:'文字',audio:'音频'}, cn:'类型'},
                    {name:'pst_content', typ:'text', cn:'值'},
                    {name:'pst_expires_on', typ:'datetime', cn:'过期时间'},
                    ],
                GenForm:GenForm
            },
            methods:{
                loadBillBoardData:function(){
                    fetch(DATA_SERVER+'/callControl/api_fetchusers').then(data=>{
                        data.json().then(j=>{
                            console.log(j)
                        })
                    })
                },
                reload:function(){this.ts = 0; this.loadBillBoardData();},
                submitForm:function()
                {
                    console.log(this.$el)
                 dom = this.$el

                }
            },
            created:function(){
                console.log('billboardDiv created')
                // console.log(GenForm(this.params))
                this.loadBillBoardData()
            }
        })

        let announcementDiv = new Vue({
            el:'#announcementDiv',
            data:{
                appTitle:'公告',
                ts:0,
                list:[],
                params:[
                    {name:'ann_content', typ:'text', cn:'值'},
                    {name:'ann_starts_from', typ:'datetime', cn:'公告开始时间'},
                    {name:'ann_expires_on', typ:'datetime', cn:'公告过期时间'},
                    ],
                GenForm:GenForm
            },
            methods:{
                loadannouncement:function() {
                    fetch(DATA_SERVER+'/pad/fetchAnnouncementContent').then(rs=>{
                        console.log(rs)
                        rs.json().then(j=>{
                            console.log(j)
                            if(j.code)
                                console.error(j.msg)
                            else
                                announcementDiv.setList(j.obj)
                        })
                    })
                },
                setList:function(l){this.list = l},
                reload:function(){this.ts = 0; this.loadannouncement();}
            },
            created:function(){
                console.log('announcementDiv created')
                this.reload()
            }
        })

        let scheduleDiv = new Vue({
            el:'#scheduleDiv',
            data:{
                appTitle:'安排表',
                ts:0,
                list:[],
                params:[
                    {name:'schd_dr', typ:'enum',enum:['image','video','text','audio'], cn:'类型'},
                    {name:'pst_content', typ:'text', cn:'值'},
                    {name:'pst_expires_on', typ:'datetime', cn:'过期时间'},
                    ],
                GenForm:GenForm
            },
            methods:{
                loadschedule:function() {
                    fetch(DATA_SERVER+'/pad/fetchScheduleContent').then(rs=>{
                        rs.json().then(j=>{
                            console.log(j)
                        })
                    })
                },
                reload:function(){this.ts = 0; this.loadschedule();}
            },
            created:function(){
                console.log('scheduleDiv created')
            }
        })

        const reloadAll = ()=>
        {
            scheduleDiv.reload();
            announcementDiv.reload();
            billboardDiv.reload();
        }

        const fetchMode = ()=>{
            fetch(`${DATA_SERVER}/pad/getSettings`).then(rsp=>{
                rsp.json().then(j=>{
                    console.log(j)
                    if(j.mode) {
                        setMode(j.mode)                          
                    }
                })
            })
        }
    </script>
</body>