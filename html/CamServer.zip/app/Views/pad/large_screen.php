<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>广播系统</title>
    <!-- <script src='/common_assets/bootstrap-4.0.0-dist/js/bootstrap.min.js'></script> -->
    <script src='/common_assets/js/socket.io.js'></script>
    <script src='/common_assets/js/vue.js'></script>
</head>
<body>
    <div id="largeScreenDiv">
        <div id="billboardDiv"></div>
        <div id="announcementDiv"></div>
        <div id="scheduleDiv"></div>
    </div>

    <script>
        let billboardDiv = new Vue({
            el:'#billboardDiv',
            data:{
                pictures:[],
                videos:[],
                texts:[]
            },
            methods:{
                loadBillBoardData:function(){
                    fetch('/callControl/api_fetchusers').then(data=>{
                            data.json().then(j=>{
                                    console.log(j)
                            })
                        })
                }
            },
            created:function(){
                console.log('billboardDiv created')
                this.loadBillBoardData()
            }
        })

        let announcementDiv = new Vue({
            el:'#announcementDiv',
            data:{
            },
            methods:{
                loadannouncement:function() {
                    fetch('/pad/fetchAnnouncementContent').then(rs=>{
                        rs.json().then(j=>{
                            console.log(j)
                        })
                    })
                }
            },
            created:function(){
                console.log('announcementDiv created')
            }
        })

        let scheduleDiv = new Vue({
            el:'#scheduleDiv',
            data:{
            },
            methods:{
                loadschedule:function() {
                    fetch('/pad/fetchScheduleContent').then(rs=>{
                        rs.json().then(j=>{
                            console.log(j)
                        })
                    })
                }
            },
            created:function(){
                console.log('scheduleDiv created')
            }
        })

        let webSocket = new WebSocket('wss://192.168.31.254:8801');
        webSocket.onerror = e=>console.log(e)
        console.log(webSocket)
    </script>
</body>