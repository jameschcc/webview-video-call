<!DOCTYPE html>
<html lang="en">
<head>
    <style type="text/css">
        body {display: flex; flex-direction: column; text-align: center; font-family: 'PingFang SC';}
    </style>
</head>
<body>
    <h1>未能成功加载</h1>
    <p>未找到对应的资源</p>
</body>
</html>