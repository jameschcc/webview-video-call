<div id="list" ></div>
<script>
    let list = new Vue({
        el:"#list",
        data:{},
        methods:{

        },
        created:function(){
            this.loadData();
        }
    })
</script>