<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>广播系统</title>
  <script src='/common_assets/js/socket.io.js'></script>
  <script src='/common_assets/js/vue.js'></script>
  <style>
    [v-cloak] {
      display: none;
    }
  </style> 
</head>
<body>
