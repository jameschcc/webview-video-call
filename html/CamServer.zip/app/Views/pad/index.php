<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>广播系统</title>
    <!-- <script src='/common_assets/bootstrap-4.0.0-dist/js/bootstrap.min.js'></script> -->
    <!-- <script src='/common_assets/js/socket.io.js'></script> -->
    <script src='https://cam.smallar.com:9943/common_assets/js/vue.js'></script>
    <style>
        [v-cloak] { display: none;}
    </style> 
</head>
<body>
    <div id="largeScreenDiv">
        <div id="billboardDiv" v-cloak>
            <h2>{{appTitle}}</h2>
            <div v-for="i in list">{{i}}</div>
        </div>
        <div id="announcementDiv" v-cloak>
            <h2>{{appTitle}}</h2>
            <div v-for="i in list">{{i.ann_content}}</div>
        </div>
        <div id="scheduleDiv" v-cloak>
            <h2>{{appTitle}}</h2>
            <div v-for="i in list">{{i}}</div>
        </div>
    </div>

    <script>
        const DATA_SERVER   = 'https://cam.smallar.com:9943'
        // const SOCKET_SERVER = 'wss://192.168.31.254:8801'
        const SOCKET_SERVER = 'wss://cam.smallar.com:8801'
        let   MODE = localStorage.getItem('display_mode') ?? null
        const setMode = m => {MODE = m; localStorage.setItem('display_mode', m)}
        let   my_id = localStorage.getItem('my_id') ?? null
        if(!my_id) {let i = new Date().getTime(); my_id=`d_${i}`; localStorage.setItem('my_id', my_id)}

        let billboardDiv = new Vue({
            el:'#billboardDiv',
            data:{
                appTitle:'宣传区',
                pictures:[],
                videos:[],
                texts:[],
                ts:0,
                list:[]
            },
            methods:{
                loadBillBoardData:function(){
                    fetch(DATA_SERVER+'/callControl/api_fetchusers').then(data=>{
                        data.json().then(j=>{
                            console.log(j)
                        })
                    })
                },
                reload:function(){this.ts = 0; this.loadBillBoardData();}
            },
            created:function(){
                console.log('billboardDiv created')
                this.loadBillBoardData()
            }
        })

        let announcementDiv = new Vue({
            el:'#announcementDiv',
            data:{
                appTitle:'公告',
                ts:0,
                list:[]
            },
            methods:{
                loadannouncement:function() {
                    fetch(DATA_SERVER+'/pad/fetchAnnouncementContent').then(rs=>{
                        console.log(rs)
                        rs.json().then(j=>{
                            console.log(j)
                            if(j.code)
                                console.error(j.msg)
                            else
                                announcementDiv.setList(j.obj)
                        })
                    })
                },
                setList:function(l){this.list = l},
                reload:function(){this.ts = 0; this.loadannouncement();}
            },
            created:function(){
                console.log('announcementDiv created')
                this.reload()
            }
        })

        let scheduleDiv = new Vue({
            el:'#scheduleDiv',
            data:{
                appTitle:'安排表',
                ts:0,
                list:[]
            },
            methods:{
                loadschedule:function() {
                    fetch(DATA_SERVER+'/pad/fetchScheduleContent').then(rs=>{
                        rs.json().then(j=>{
                            console.log(j)
                        })
                    })
                },
                reload:function(){this.ts = 0; this.loadschedule();}
            },
            created:function(){
                console.log('scheduleDiv created')
            }
        })

        let webSocket = new WebSocket(SOCKET_SERVER);
        webSocket.onerror = e=>console.log(e)
        webSocket.onmessage = m=>{
            // let j = JSON.parse(m)
            console.log(m)
            console.log(`rcvd wss msg: ${m ? m.data: 'NON'}`);
            if(m)
            {
                switch (m.data) {
                case 'new_schedule':
                    scheduleDiv.loadschedule(); break;
                case 'new_announcement':
                    announcementDiv.loadannouncement(); break;
                case 'new_billboard':
                    billboardDiv.loadBillBoardData(); break;
                case 'reload':
                    reloadAll()
                case 'set_mode':
                    fetchMode()
                default: break;
                }
            }
        }

        webSocket.onopen = (e=>{
            console.log(e)
            webSocket.send(`HELLO from ${my_id}`)
        })

        const reloadAll = ()=>
        {
            scheduleDiv.reload();
            announcementDiv.reload();
            billboardDiv.reload();
        }

        const fetchMode = ()=>{
            fetch(`${DATA_SERVER}/pad/getSettings`, {method:'POST',body:JSON.stringify({device_id:my_id})}).then(rsp=>{
                rsp.json().then(j=>{
                    console.log(j)
                    if(j.mode) {
                        setMode(j.mode)                          
                    }
                })
            })
        }
    </script>
</body>