<?php

namespace App\Models;
use CodeIgniter\Database\ConnectionInterface; 
use CodeIgniter\Model;

class UsersModel extends Model
{
    // protected  $db = null;
    protected $table      = 'users';
    protected $primaryKey = 'uid';
    protected $allowedFields = [
        "uid",
        "callnumber",
        "uname",
        "passhash",
        "ustate",
        "lastAckTime",
        "sessionStr",
        "ugroupId",
        "avatarSrc"
    ];
    public $validStates = array('ONLINE','OFFLINE');

    public function __construct()
    {
        parent::__construct();
        $this->uniqmodel = new \App\Models\UniqsModel();
        $this->ugroupmodel = new \App\Models\UsergroupModel();
    }

    public function dropUsersTable($errorsArr = null)
    {
        $ret1 = $this->db->query('drop table if exists users;');
        $ret2 = $this->db->query('drop table if exists userGroups;');
        if(false == $ret1 && is_array($errorsArr))
            $errorsArr = array_merge($errorsArr, $this->doErrors());
        if(false == $ret2 && is_array($errorsArr))
            $errorsArr = array_merge($errorsArr, $this->doErrors());
        return $ret1 && $ret2;
    }

    public function createUsersTable($errorsArr = null)
    {
        // users (uid, callnumber, uname, ustate, passhash)
        $ret1 = $this->db->query('create table if not exists users (uid INTEGER primary key auto_increment , callnumber varchar(16) default null, uname varchar(16) default null, ustate varchar(8) default "OFFLINE",  passhash varchar(128) default null, ugroupId int unsigned default 2, avatarSrc varchar(256) default null);');
        $ret2 = $this->db->query('create table if not exists userGroups (ugroupId INTEGER primary key auto_increment, ugroupName varchar(16) UNIQUE not null);');
        if(false == $ret1 && is_array($errorsArr))
            $errorsArr = array_merge($errorsArr, $this->doErrors());
        if(false == $ret2 && is_array($errorsArr))
            $errorsArr = array_merge($errorsArr, $this->doErrors());
        $ret = $ret1 && $ret2;
        if($ret)
        {
            $ret &= $this->createAdmin();
        }
        return $ret1 && $ret2;
    }

    private function createAdmin()
    {
        $ret = true;
        $ret &= $this->insert(['uid'=>'1', 'uname'=>'系统管理员','callnumber'=>'0','passhash'=>md5('passpass'), 'ugroupId'=>'1']);
        $ret &= $this->ugroupmodel->insert(['ugroupId'=>'1', 'ugroupName'=>'系统管理组']);
        $ret &= $this->ugroupmodel->insert(['ugroupId'=>'2', 'ugroupName'=>'普通用户']);
        return $ret;
    }


    public function dropUniqsTable($errorsArr = null)
    {
        $ret= $this->db->query('drop table if exists uniqs;');
        if(false==$ret && is_array($errorsArr))
            $errorsArr = array_merge($errorsArr, $this->doErrors());
        return $ret;
    }

    public function createUniqsTable($errorsArr = null)
    {
        // uniqs (uniq_idx, uid*, uniq*, sesseionStr, lastAckTime)
        $ret= $this->db->query('create table if not exists uniqs (uniq_idx INTEGER primary key auto_increment, uid INTEGER, uniq varchar(6) not null unique, sessionStr varchar(36) not null, lastAckTime int unsigned default 0);');
        if(false==$ret && is_array($errorsArr))
            $errorsArr = array_merge($errorsArr, $this->doErrors());
        return $ret;
    }

    public function getSessionStr()
    {
        \Config\Services::session();
        print_r(session_id());
        return substr(session_id(), 0,32);
    }


    public function getMe($sesId)
    {
        return $this->db->query("select * from users inner join uniqs on users.uid = uniqs.uid where sessionStr LIKE '".$sesId."'")->getRow();
    }


    /**
     * @return [uniqs] or null
     * */
    public function getMyUniqObj($sesId)
    {
        return $this->db->query("select * from uniqs where sessionStr='".$sesId."'")->getRow();
    }



    /**
     * @return [uniqs] or null
     * */
    public function getUniqObj($u)
    {
        return $this->db->query("select * from uniqs where uniq='$u'")->getRow();
    }

    /**
     * @return [uniqs] or null
     * */
    public function getMyUniq($sesId)
    {
        $u = $this->getMyUniqObj($sesId);
        return $u ? $u->uniq : 0;
    }

    /**
     * @return uid or 0
     * */
    public function getMyUid($sesId)
    {
        $u = $this->getMyUniqObj($sesId);
        return $u ? $u->uid : 0;
    }

    public function getUser($uid)
    {
        $ret = $this->find($uid) ?? null;
        if($ret)
            unset($ret['passhash']);
        return $ret?(object)$ret:null;
    }

    public function getUserThroughUniq($uniq)
    {
        $ret  = $this->db->query("select * from users inner join uniqs on users.uid = uniqs.uid where uniq='$uniq' ;")->getRow();
        if($ret && isset($ret->passhash))
            unset($ret->passhash);
        return $ret;
    }

    public function getUserIncludePass($uid)
    {
        $ret = $this->find($uid) ?? null;
        return $ret?(object)$ret:null;
    }

    /**
     * @return get the first uniq obj
     * */
    public function getUniqObjOfUser($uid)
    {
        if(!$uid || !is_numeric($uid))
            return null;
        return $this->db->query("select * from uniqs where uid=$uid ;")->getRow();
    }

    /**
     * @return [uniqs] of uid
     * */
    public function getAllUniqObjOfUser($uid)
    {
        if(!$uid || !is_numeric($uid))
            return null;
        return $this->db->query("select * from uniqs where uid=$uid;")->getResult();
    }

    /**
     * @return bool
     * */
    function getUserByCallnumber($callnumber)
    {
        return $this->where('callnumber',$callnumber)->get()->getRow();
    }

    /**
     * @return bool
     * */
    function deleteUserByCallnumber($callnumber)
    {
        return $this->db->query("delete from users where callnumber='$callnumber';");
    }

    /**
     * @return all users [userObjects]
     * */
    // returns: null if none, else array of dev.
    public function getAllUsers($sortWithOnlineStatus = true, $includeAdmin=false)
    {
        $rs = $this->db->query('select * from users inner join userGroups on users.ugroupId=userGroups.ugroupId where users.ugroupId!=1 order by uid asc')->getResult();
        if($rs){            
            foreach ($rs as &$r) {
                unset($r->passhash);
            }
        }
        if($sortWithOnlineStatus)
            usort($rs,
                function($b, $a)
                {
                    if($a->ustate == 'OFFLINE'){
                        if($b->ustate == 'OFFLINE')
                            return $a->uid < $b->uid ? 1 : -1;
                        else return -100;
                    }
                    else
                    {
                        if($b->ustate != 'OFFLINE')
                            return (int)$a->uid < (int)$b->uid ? 1 : -1;
                        else return 100;
                    }
                }
            );
        return $rs;
    }

    /**
     * @return [{uniq}]
     * */
    public function findSameSessionUniqObjs($sesId)
    {
        $sessionStr = $sesId;
        return $this->db->query("select * from uniqs where sessionStr='$sessionStr'")->getResult();
    }

    public function getSessionCalls($sesId)
    {
        $devices = $this->findSameSessionUniqObjs($sesId);
        if(!$devices)
            return null;
        $arr = array();
        foreach ($devices as $d) {
            $arr2 = getCallsOfUniq($d['uniq']);
            if($arr2)
                $arr = array_merge($arr,$arr2);
        }
        return count($arr) ? $arr : null;
    }

    /**
     * @return bool
     * */
    function updateState($uid, $state)
    {
        global $validStates;
        if(!in_array($state, $this->validStates))
            return false;
        return $this->update(['ustate'=>$state],$uid);
    }

    function setOnline($uid)
    {
        return $this->update($uid, array('ustate'=>'ONLINE'));
    }
    /*
    function setBusy($uid)
    {
        return $this->update($uid, array('ustate'=>'BUSY'));
    }*/

    function setOffline($uid)
    {
        return $this->update($uid, array('ustate'=>'OFFLINE'));
    }

    /**
     *
     * */
    function insertUniq($uniq, $uid, $sessionStr)
    {
        return $this->uniqmodel->insert(array('sessionStr'=>$sessionStr, 'uniq'=>$uniq, 'uid'=>$uid));
    }

    /**
     *
     * */
    function deleteUniq($uniq)
    {
        return $this->db->query("delete from uniqs where uniq='$uniq'");
    }



    /**
     * @return {user}
     * */
    function validatePass($callnumber, $passhash)
    {
        return $this->where('callnumber',$callnumber)->where('passhash',$passhash)->getRow();
    }

    /**
     * get uid from session
     * */
    function commonGetUid()
    {
        return \Config\Services::session()->get('uid') ?? 0;
    }
}