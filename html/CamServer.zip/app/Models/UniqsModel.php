<?php

namespace App\Models;
use CodeIgniter\Database\ConnectionInterface; 
use CodeIgniter\Model;

class UniqsModel extends Model
{
        // uniqs (uniq_idx, uid*, uniq*, sesseionStr, lastAckTime)
    protected $table      = 'uniqs';
    protected $primaryKey = 'uniq_idx';
    protected $allowedFields = [
        'uid',
        'uniq',
        'sessionStr',
        'lastAckTime'
    ];
}
?>
