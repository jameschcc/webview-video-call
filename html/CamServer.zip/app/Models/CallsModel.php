<?php

namespace App\Models;

use CodeIgniter\Model;


class CallsModel extends Model
{
    protected $table      = 'calls';
    protected $primaryKey = 'callId';
    protected $allowedFields = ['cguniq', 'cduniq', 'sdpOffer', 'sdpAnswer', 'timestamp', 'period','calltype','cduid'];

    public function dropCallsTable()
    {
        return $this->db->query('drop table if exists calls;');
    }

    public function createCallsTable($errorsArr = null)
    {
        // tables: calls(callId, cguniq, cduniq, sdpOffer, sdpAnswer, parentCallId, timestamp, period)


        // cduid is mainly used for delayed calls
        // in which the called side is offline.
        // if cduid has value, then the cduniq shall be set to null,
        // it means a call job, which would be handling when the cd be online

        $ret=$this->db->query('create table if not exists calls (callId INTEGER primary key auto_increment, cguniq varchar(6) not null, cduniq varchar(6), calltype integer, cduid integer unsigned default null, sdpOffer text default null, sdpAnswer text default null, parentCallId integer, timestamp integer default 0, period integer default 0);');

        if(false==$ret && is_array($errorsArr))
            $errorsArr = array_merge($errorsArr, $this->doErrors());
        return $ret;
        // if(!$ret){
        //     echo $db->lastErrorMsg();
        // } else {
        //     echo "Records created successfully\n";
        // }
        // $this->db || (print_r ('loading db \n') && $this->db=db_connect());
    }

    /**
     * @param   side  0=both 1=calling 2=called
     * @return  [callObjects] or null
     * */
    function getCallJobssOfUiq($uid)
    {
        $sql = "select * from calls where cduid='$uid' order by callId asc";
        return $this->db->query($sql)->getResult();
    }

    /**
     * @param   side  0=both 1=calling 2=called
     * @return  [callObjects] or null
     * */
    function getCallsOfUniq($uniq, $side=SIDE_BOTH)
    {
        $sql = null;
        switch ($side) {
            case SIDE_BOTH:
            $sql = "select * from calls where cguniq='$uniq' or cduniq='$uniq'";
            break;
            case SIDE_IC:
            $sql = "select * from calls where cguniq='$uniq'";
            break;
            case SIDE_OG:
            $sql = "select * from calls where cduniq='$uniq'";
            break;
            
            default:
            return null;
            break;
        }
        return $this->db->query($sql)->getResult();
    }
    function getCall($callId)
    {
        if(!$callId)
        {
            return null;
        }
        return $this->db->query("select * from calls where callId = '$callId'")->getRow();
    }

    public function modifyCall($params, $callId)
    {
        return $this->update($callId, $params);
    }

    /**
     * @return the created {call} or null
     * */
    public function createCall($params)
    {
        if(!isset($params['timestamp']))
            $params['timestamp'] = time();
        $callId = $this->insert($params);
        if($callId)
        {
            return $this->db->query("select * from calls where callId = '$callId'")->getRow();
        }
        else
        {
            serverlog("unable to create call");
            return null;
        }
    }


    /**
     * set a call into calljob, by setting its cduniq null and assign the cduid
     * */
    function setCdUid($callId, $cduid)
    {
        return $this->update($callId, array('cduid'=>$cduid, 'cduniq'=>null));
    }
    /**
     * set a call into calljob, by setting its cduniq null and assign the cduid
     * */
    function setCdUniq($callId, $cduniq)
    {
        return $this->update($callId, array('cduid'=>null, 'cduniq'=>$cduniq));
    }
    function setCgUniq($callId, $cduniq)
    {
        return $this->update($callId, array('cguniq'=>$cguniq));
    }
}