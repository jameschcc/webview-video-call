<?php

namespace App\Models;
use CodeIgniter\Database\ConnectionInterface; 
use CodeIgniter\Model;

class UsergroupModel extends Model
{
        // uniqs (uniq_idx, uid*, uniq*, sesseionStr, lastAckTime)
    protected $table      = 'userGroups';
    protected $primaryKey = 'ugroupId';
    protected $allowedFields = [
        'ugroupId',
        'ugroupName'
    ];
}
?>
