<?php

namespace App\Models;

use CodeIgniter\Model;


class CallLogsModel extends Model
{
    protected $table            = 'calllogs';
    protected $primaryKey       = 'callId';
    protected $allowedFields    = ['callId', 'cguid', 'cduid', 'timestamp', 'period'];

    public function dropCallLogsTable()
    {
        return $this->db->query('drop table if exists calllogs;');
    }

    public function createCallLogsTable($errorsArr = null)
    {
        // tables: callogs(callId, cguid, cduid, parentCallId, timestamp, period)
        // the primary key callId is same with calls.callId
        $ret=$this->db->query('create table if not exists calllogs (callId INTEGER primary key, cguid integer not null, cduid integer not null, parentCallId integer default 0, timestamp integer default 0, period integer default 0);');

        if(false==$ret && is_array($errorsArr))
            $errorsArr = array_merge($errorsArr, $this->doErrors());
        return $ret;
    }

    /**
     * @param   side  0=both 1=calling 2=called
     * @return  [callObjects] or null
     * */
    function getCallLogsOfUid($uid, $side=SIDE_BOTH, $withUser = false)
    {
        $sql = null;
        switch ($side) {
            case SIDE_BOTH:
            $sql = "select * from calllogs where cguid='$uid' or cduid='$uid'";
            break;
            case SIDE_IC:
            $sql = "select * from calllogs where cguid='$uid'";
            break;
            case SIDE_OG:
            $sql = "select * from calllogs where cduid='$uid'";
            break;
            
            default:
            return null;
            break;
        }
        $logs = $this->db->query($sql)->getResult();
        if(!$withUser)
            return $logs;
        else
        {
            foreach ($logs as $l) {
                $l->cg = $this->db->query("select * from users where uid={$l->cguid}")->getRow();
                $l->cd = $this->db->query("select * from users where uid={$l->cduid}")->getRow();
            }
        }
        return $logs;
    }

    function getCallLog($callId)
    {
        if(!$callId)
        {
            return null;
        }
        return $this->db->query("select * from calllogs where callId='$callId'")->getRow();
    }

    public function modifyCallLog($params, $callId)
    {
        return $this->update($callId, $params);
    }

    /**
     * @return the created {call} or null
     * */
    public function createCallLog($params)
    {
        $callId = $this->insert($params);
        if($callId)
            return $this->db->query("select * from calllogs where callId='$callId'")->getRow();
        else
        {
            serverlog("unable to create callLog:".json_encode($params));
            return null;
        }
    }
    /**
     * @return true or false
     * */
    public function updatePeriod($callId, $p)
    {
        return $this->update($callId, ['period'=>$p]);
    }

}