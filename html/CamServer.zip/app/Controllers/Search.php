<?php

namespace App\Controllers;

class Search extends BaseController
{
    public function index(): string
    {
        // $session = session();
        // print_r($session->session_id);
        return view('manage/head').
        view('manage/search').
        view('manage/foot');
    }
}
