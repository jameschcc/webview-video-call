<?php

namespace App\Controllers;

class Help extends BaseController
{
    public function api(): string
    {
        return view('manage/head').
        view('help/theApis').
        view('manage/foot');
    }
    public function phpinfo()
    {
        return phpinfo();
    }
}
