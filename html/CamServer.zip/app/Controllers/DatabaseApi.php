<?php
namespace App\Controllers;
use Config\Paths;



// header('content-type:text/plain');
// $db = \Config\Database::connect();
class DatabaseApi extends BaseController
{
    private $usersModel;
    private $callsModel;
    public function __construct()
    {
        $this->usersModel = new \App\Models\UsersModel(); 
        $this->callsModel = new \App\Models\CallsModel();
        $this->callLogsModel = new \App\Models\CallLogsModel();
        $this->ugroupmodel = new \App\Models\UsergroupModel();
        // $this->db = db_connect();
    }

    public function createDatabase()
    {
        $dbpass = trim(file_get_contents('/var/www/dbpass'));
        exec("mysql -uroot -p$dbpass -e 'create database camsrv default character set utf8 collate utf8_general_ci' 2>&1;",$output,$code);
        if(0 == $code)
            return api_return_success();
        else
            return api_return_fail(DB_ERROR, null, $output);
    }

    /**
     * @return {code=0:ok/>0:fail,msg:ErrorMsg,obj:{}}
     */
    private function createTables($errorsArr = null)
    {
        $ret = $this->usersModel->createUsersTable($errorsArr)
        && $this->usersModel->createUniqsTable($errorsArr)
        && $this->callsModel->createCallsTable($errorsArr)
        && $this->callLogsModel->dropCallLogsTable($errorsArr);
        return $ret;
    }

    private function destroyTables($errorsArr = null){
        $ret = $this->usersModel->dropUsersTable($errorsArr)
        && $this->usersModel->dropUniqsTable($errorsArr)
        && $this->callsModel->dropCallsTable($errorsArr)
        && $this->callLogsModel->createCallLogsTable($errorsArr);
        return $ret;
    }

    public function api_createTables()
    {
        $errorsArr = [];
        $ret = $this->createTables($errorsArr);

        if(!$ret)
            api_return_fail(DB_ERROR, '建立数据表失败', $errorsArr);
        else
            api_return_success();
    }

    public function api_initTables(){
        $errorsArr = [];
        $ret = $this->createTables($errorsArr);

        if($ret)
            api_return_success();
        else
            api_return_fail(DB_ERROR, '未能初始化数据库', $errorsArr);
    }

    public function api_resetTables(){
        $errorsArr = [];
        if($this->destroyTables($errorsArr) && $this->createTables($errorsArr))
            api_return_success();
        else
            api_return_fail(DB_ERROR, '未能重置数据库', $errorsArr);
    }

    public function api_resetUniqsTable(){
        $errorsArr = [];
        $ret = $this->usersModel->dropUniqsTable($errorsArr)
        && $this->usersModel->createUniqsTable($errorsArr);

        if($ret)
            api_return_success();
        else
            api_return_fail(DB_ERROR, '重置登录数据失败', $errorsArr);
    }

    public function api_resetCallsTable(){
        $errorsArr = [];
        $ret = $this->callsModel->dropCallsTable($errorsArr)
        && $this->callsModel->createCallsTable($errorsArr);

        if($ret)
            api_return_success();
        else
            api_return_fail(DB_ERROR, '重置登录数据失败', $errorsArr);
    }

    public function index()
    {
    }

    public function api_exportDatabase()
    {
        $subdir = 'backups/db';
        $localsubdir = "public/$subdir";
        $d = ((new Paths())->appDirectory).'/../'.$localsubdir;
        $f = "camsrv-db-backup-".date("Y-m-d-H-i-s").".sql";
        exec("mysqldump -uphp -pphp -h localhost --single-transaction camsrv > $d/$f 2>&1", $out, $retcode);
        if($retcode)
        {
            api_return_fail(DB_ERROR, "导出数据库失败", join(';', $out));
        }
        else
        {
            $url = \Config\Services::uri()->getBaseURL()."$subdir/$f";
            api_return_success(['path'=>"/$localsubdir/$f"],"下载链接：$url");
        }
    }

    public function api_listbackups()
    {
        $subdir = 'public/backups/db';
        $d = ((new Paths())->appDirectory).'/../'.$subdir;
        $fs = scandir($d);
        if(!$fs)
        {
            api_return_fail(COMMON_ERROR, "未能获取到备份文件列表");
        }
        else
        {
            api_return_success($fs);
        }
    }


    public function addTestData()
    {
        $ret = true;
        $errorsArr = [];

        if(!($this->destroyTables($errorsArr) && $this->createTables($errorsArr)))
            api_return_fail(DB_ERROR,"未能重置数据");

        try{
            if(false === $this->ugroupmodel->insert(['ugroupId'=>'3', 'ugroupName'=>'科室']))
                $ret &= false;
            if(false === $this->ugroupmodel->insert(['ugroupId'=>'4', 'ugroupName'=>'职员']))
                $ret &= false;
            if(false === $this->ugroupmodel->insert(['ugroupId'=>'5', 'ugroupName'=>'作业人员']))
                $ret &= false;
        }
        catch(DatabaseException $e)
        {
            $ret &= false;
            $errorsArr = array_merge($errorsArr, $this->ugroupmodel->doErrors());
        }

        try{
            if(false === $this->usersModel->insert(['uname'=>'科室一','callnumber'=>'13000000001','passhash'=>md5('abcde'), 'ugroupId'=>3]))
                $ret &= false;
            if(false === $this->usersModel->insert(['uname'=>'科室二','callnumber'=>'13000000002','passhash'=>md5('abcde'), 'ugroupId'=>3]))
                $ret &= false;
            if(false === $this->usersModel->insert(['uname'=>'科室三','callnumber'=>'13000000003','passhash'=>md5('abcde'), 'ugroupId'=>3]))
                $ret &= false;
            if(false === $this->usersModel->insert(['uname'=>'科室四','callnumber'=>'13000000004','passhash'=>md5('abcde'), 'ugroupId'=>3]))
                $ret &= false;
            if(false === $this->usersModel->insert(['uname'=>'科室五','callnumber'=>'13000000005','passhash'=>md5('abcde'), 'ugroupId'=>3]))
                $ret &= false;

            if(false === $this->usersModel->insert(['uname'=>'用户A','callnumber'=>'15000000001','passhash'=>md5('abcde'), 'ugroupId'=>4]))
                $ret &= false;
            if(false === $this->usersModel->insert(['uname'=>'用户B','callnumber'=>'15000000002','passhash'=>md5('abcde'), 'ugroupId'=>4]))
                $ret &= false;
            if(false === $this->usersModel->insert(['uname'=>'用户C','callnumber'=>'15000000003','passhash'=>md5('abcde'), 'ugroupId'=>4]))
                $ret &= false;
            if(false === $this->usersModel->insert(['uname'=>'用户D','callnumber'=>'15000000004','passhash'=>md5('abcde'), 'ugroupId'=>4]))
                $ret &= false;
            if(false === $this->usersModel->insert(['uname'=>'用户E','callnumber'=>'15000000005','passhash'=>md5('abcde'), 'ugroupId'=>4]))
                $ret &= false;

            if(false === $this->usersModel->insert(['uname'=>'作业人员一','callnumber'=>'18000000001','passhash'=>md5('abcde'), 'ugroupId'=>5]))
                $ret &= false;
            if(false === $this->usersModel->insert(['uname'=>'作业人员二','callnumber'=>'18000000002','passhash'=>md5('abcde'), 'ugroupId'=>5]))
                $ret &= false;
            if(false === $this->usersModel->insert(['uname'=>'作业人员三','callnumber'=>'18000000003','passhash'=>md5('abcde'), 'ugroupId'=>5]))
                $ret &= false;
            if(false === $this->usersModel->insert(['uname'=>'作业人员四','callnumber'=>'18000000004','passhash'=>md5('abcde'), 'ugroupId'=>5]))
                $ret &= false;
            if(false === $this->usersModel->insert(['uname'=>'作业人员五','callnumber'=>'18000000005','passhash'=>md5('abcde'), 'ugroupId'=>5]))
                $ret &= false;
        }
        catch(DatabaseException $e)
        {
            $ret &= false;
            $errorsArr = array_merge($errorsArr, $this->ugroupmodel->doErrors());
        }
        // var_dump($ret);
        // var_dump($errorsArr);
        // die();

        if($ret==true)
        {
            sendMsgToDevice(null, 'tellDevListUpdate');
            api_return_success();
        }
        else
        {
            serverlog(join(';',$errorsArr),'error');
            api_return_fail(COMMON_ERROR, "未能完成添加");
        }

    }

    public function test()
    {
        $this->session = \Config\Services::session();
        print_r(session_id()) ;
        print_r($_COOKIE) ;
    }

}
