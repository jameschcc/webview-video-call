<?php

namespace App\Controllers;

class Client extends BaseController
{
    public function index(): string
    {
        // print_r(session_id());
        // $session = session();
        $this->session = \Config\Services::session();
        // print_r(session_id());
        // print_r(session_id());

        // print_r($session->session_id);
        return view('client/client_view');
    }
    public function download(): string
    {
        return '<html><head></head><body><a download="app-debug.apk.zip" href="/common_assets/apk/app-debug.apk.1.zip">download</a></body></html>';
        // redirect('/common_assets/apk/app-debug.apk.1');
    }
}
