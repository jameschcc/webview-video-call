<?php

namespace App\Controllers;

class Pad extends BaseController
{
    private $db = null;
    private array $dbCfg =  [
        'DSN'         => '',
        'hostname'    => '127.0.0.1',
        'username'    => '',
        'password'    => '',
        'database'    => WRITEPATH.'/db/hospital.sqlite3.db',
        'DBDriver'    => 'SQLite3',
        'DBPrefix'    => 'db_',  // Needed to ensure we're working correctly with prefixes live. DO NOT REMOVE FOR CI DEVS
        'pConnect'    => false,
        'DBDebug'     => true,
        'charset'     => 'utf8',
        'DBCollat'    => 'utf8_general_ci',
        'swapPre'     => '',
        'encrypt'     => false,
        'compress'    => false,
        'strictOn'    => false,
        'failover'    => [],
        'port'        => 3306,
        'foreignKeys' => true,
        'busyTimeout' => 1000,
    ];

    public function getDb()
    {
        if(!$this->db)
        {
            $dir = WRITEPATH.'/db';

            if(!is_dir($dir))
            {            
                if(!mkdir($dir))
                {
                    throw new Exception("Error create db directory", 1);
                }
            }
            $this->db = \Config\Database::connect($this->dbCfg);
            $this->createTablesIfNotExist();
        }
        
        return $this->db;
    }
    public function manage(): string
    {
        return view('pad/manage');
    }

    private function createTablesIfNotExist()
    {
        // for billboard
        $this->getDb()->query('create table if not exists content_billboard (id integer primary key autoincrement, type varchar(16), content varchar(1024), timestamp int unsigned, active small int);');

        // for announcement
        $this->getDb()->query('create table if not exists content_announcement (ann_id integer primary key autoincrement, ann_content varchar(1024), from_ts int, to_ts int, active bool);');

        // for schedule
        $this->getDb()->query('create table if not exists content_doctors (dr_id integer primary key autoincrement, dr_name varchar(32), dr_description varchar(1024), dr_avartar varchar(256), dr_video varchar(256), dr_department varchar(64));');
        $this->getDb()->query('create table if not exists content_patients (pt_id integer primary key autoincrement, age smallint unsigned, pt_name varchar(16), pt_description varchar(1024));');
        $this->getDb()->query('create table if not exists content_schedule (schd_id integer primary key autoincrement, date varchar(10), dr_id int, pt_id varchar(16), from_time int, to_time int, active bool);');
    }

    public function index(): string
    {
        // print_r(session_id());
        // $session = session();
        $this->session = \Config\Services::session();
        // print_r(session_id());
        // print_r(session_id());

        // print_r($session->session_id);
        return view('client/pad_integrated');
    }

    public function api_getNotifications()
    {
        result(SUCCESS, null, [['text'=>'手术室通知 完成后请到大厅','ts'=>1715527703],['text'=>'这是另一条手术室通知','ts'=>1715527303]]);
    }
    public function api_getBroadcasts()
    {
        result(SUCCESS, null, [['text'=>'这是一条通告系统里的消息','ts'=>1715527705],['text'=>'这是另一条通告系统里的消息','ts'=>1715523703]]);
    }

    public function screen(): string
    {
        // print_r(session_id());
        // $session = session();
        $this->session = \Config\Services::session();
        // print_r(session_id());
        // print_r(session_id());

        // print_r($session->session_id);
        return view('pad/large_screen');
    }

    // billboardDiv
    // announcementDiv
    // scheduleDiv


    public function setupData()
    {

    }
    // table : content_doctors (id:int:primary_key, dr_name: dr_description:varchar(1024), dr_avartar:varchar(256:url), dr_video:varchar(256:url), dr_department:varchar(64))
    // table : content_patients (id:int:primary_key, age:smallint unsigned, pt_name:varchar(16), pt_description:varchar(1024))

    public function fetchBillboardContent($value='')
    {
        // table : content_billboard (id:int:primary_key, type:varchar(16), content:varchar(1024), timestamp:int, active:bool)
        //                          type:enum('text'->content,'video'->src,'picture'->src)
        // latest: select * from content_billboard where active = 1 order by timestamp desc
        // all not fetched: select * from content_billboard where timestamp > t and active = 1 order by timestamp asc
        result(SUCCESS, null, [
            ['id'=>1,'timestamp'=>1715527705, 'content'=>'温馨提示内容一', active=>1],
            ['id'=>2,'timestamp'=>1715527705, 'content'=>'温馨提示内容二', active=>0],
            ['id'=>3,'timestamp'=>1715527705, 'content'=>'温馨提示内容三', active=>1],
        ]); 
    }
    public function fetchAnnouncementContent($value='')
    {
        // announcement is active from timestamp to expiration
        // table : content_announcement (id:int:primary_key, content:varchar(1024), from_ts:int, to_ts:int, active:bool)
        // latest: select *  from content_announcement where active=1 and (from_ts < ts and to_ts > ts) order by from_ts asc limit 10
        $arr = $this->getDb()->query("select * from content_announcement;")->getResult();
        foreach ($arr as $idx => $a) {
            $a->ann_content = html_entity_decode($a->ann_content);
        }
        result(SUCCESS, null, $arr); 
    }
    public function fetchScheduleContent($value='')
    {
        // table : content_schedule (id:int:primary_key, date:varchar(10:'YYYY-MM-DD'), doctor_id:int, patient_name:varchar(16), from_time:int:hhmm, to_time:int:hhmm, active:bool)
        // hhmm: 0000~2359
        result(SUCCESS, null, [
        ]); 
    }
    public function manageSchedule($type)
    {
    }

    public function manageAnnouncement($value='')
    {
    }

    public function manageBillboard($value='')
    {
    }

    public function listContent($type)
    {
        return view('pad/head').
        view('pad/list_content',['type'=>$type]).
        view('pad/foot');
    }

    // param obj: {from_ts:int?, text:'...', to_ts:int?}
    // ts ?= current, to_ts ?= time + 1hour
    // return ERR_CODE or obj
    private function funcAddBillboard($obj)
    {
        if(!property_exists($obj, 'text'))
            return -1;
        if(!is_string($obj->text))
            return -2;
        if(!property_exists($obj, 'from_ts'))
            $obj->from_ts = time();
        if(!property_exists($obj, 'to_ts'))
            $obj->to_ts = time() + 60*60;
        if($obj->to_ts < $obj->from_ts)
            return -3;
        $this->getDb()->query("insert into content_billboard(ann_content, from_ts, to_ts, active) values('".htmlentities($obj->text)."', {$obj->from_ts}, {$obj->to_ts}, true)");
        $insert_id = $this->getDb()->insertID();
        if(!$insert_id)
            return -4;
        exec('curl https://cam.smallar.com:8801/new_billboard -vk --connect-timeout 1',$e_out,$e_code);
        if($e_code) {
            return -5;
        }
        return $this->fetchBillboardContent();
    }
    // param: POST_data
    public function apiAddBillboard()
    {
        $post = $this->request->getGetPost(); 
        $ret = $this->funcAddBillboard((object)$post);
        if(is_int($ret))
        {
            api_return_fail($ret);
        }
        else
        {
            print_r($ret);
        }
    }

    // ///////////////////
    // param obj: {from_ts:int?, text:'...', to_ts:int?}
    // ts ?= current, to_ts ?= time + 1hour
    // return ERR_CODE or obj
    private function funcAddSchedule($obj)
    {
        if(!property_exists($obj, 'text'))
            return -1;
        if(!is_string($obj->text))
            return -2;
        if(!property_exists($obj, 'from_ts'))
            $obj->from_ts = time();
        if(!property_exists($obj, 'to_ts'))
            $obj->to_ts = time() + 60*60;
        if($obj->to_ts < $obj->from_ts)
            return -3;
        $this->getDb()->query("insert into content_announcement(ann_content, from_ts, to_ts, active) values('".htmlentities($obj->text)."', {$obj->from_ts}, {$obj->to_ts}, true)");
        $insert_id = $this->getDb()->insertID();
        if(!$insert_id)
            return -4;
        exec('curl https://cam.smallar.com:8801/new_announcement -vk --connect-timeout 1',$e_out,$e_code);
        if($e_code) {
            return -5;
        }
        return $this->fetchAnnouncementContent();
    }
    // param: POST_data
    public function apiAddSchedule()
    {
        $post = $this->request->getGetPost(); 
        $ret = $this->funcAddSchedule((object)$post);
        if(is_int($ret))
        {
            api_return_fail($ret);
        }
        else
        {
            print_r($ret);
        }
    }
    // ///////////////////////
}
