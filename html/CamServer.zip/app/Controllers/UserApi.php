<?php
namespace App\Controllers;


use CodeIgniter\Controller;

class UserApi extends Controller
{
    private $usersModel = null;
    private $callsModel = null;

    public function __construct()
    {
        $this->usersModel = new \App\Models\UsersModel();
        $this->uniqsModel = new \App\Models\UniqsModel();
        $this->ugroupmodel = new \App\Models\UsergroupModel();
        $this->callLogsModel = new \App\Models\CallLogsModel();
    }
    private function loadCallsModel()
    {
        $callsModel = new \App\Models\CallsModel();
    }

    /**
     * @param  $params[]
     * @return true=ok, false=fail
     */
    public function addUser()
    {
        if(!isAdmin())
            api_return_fail(UNAUTHORIZED);
        $post = $this->request->getPost();
        $post['uname']      ?? api_return_fail(PARAM_ERROR, '未提供用户名');
        $post['passhash']   ?? api_return_fail(PARAM_ERROR, '未提供密码');
        $post['callnumber']     ?? api_return_fail(PARAM_ERROR, '未提供呼叫号码');

        $u = $this->usersModel->getUserByCallnumber($post['callnumber']);
        if($u)
            api_return_fail('fail to add user','该呼叫号码('.$post['callnumber'].')已存在');
        $ret = $this->usersModel->insert($post);
        if($ret)
        {
            sendMsgToDevice(null, 'tellDevListUpdate');
            api_return_success();
        }
        else
            api_return_fail('fail to add user');
    }

    /**
     * @param  $params[]
     * @return true=ok, false=fail
     */
    public function getRandomCallnumber()
    {
        $tryTimes = 10; $got = false;
        for ($t=0; $t < $tryTimes; $t++) {
            $allowdDigits = [1,2,5,6,8,9,0];
            $digits = '8';
            $digLen = strlen($digits);
            for ($i=0; $i < CALLNUMBER_LENTH-$digLen; $i++) { 
                $r = $allowdDigits[rand(0,count($allowdDigits)-1)];
                $digits .= $r;
            };
            if(
                callnumberVerify($digits) &&
                !$this->usersModel->getUserByCallnumber($digits)
            )
            {
                $got = true;
                break;
            }
        }

        if($got)
            api_return_success($digits);
        else
            api_return_fail(CALLNUMBER_GEN_FAILED);
    }

    public function verifyAvartarSrc($src)
    {
        if(strlen($src)>230 || !parse_url($src) || !preg_match('/\.(jpg|png|gif|jpeg|bmp)$/', $src))
            return false;
        else
            return true;
    }

    /**
     * @param  $POST[]
     * @return {code=0:ok/>0:fail,msg:ErrorMsg,obj:{}}
     */
    public function registerCallnumber()
    {
        // if(!isAdmin())
        //     api_return_fail(UNAUTHORIZED);
        $post = $this->request->getPost();
        $post['uname']      ?? api_return_fail(PARAM_ERROR, '未提供用户名');
        // if(!isset)
        $post['passhash']   ?? $post['passhash']=md5(DEFAULT_PASSWORD);
        $post['callnumber']     ?? api_return_fail(PARAM_ERROR, '未提供呼叫号码');


        if(!callnumberVerify($post['callnumber']))
            api_return_fail(CALLNUMBER_INVALID);
        $u = $this->usersModel->getUserByCallnumber($post['callnumber']);
        if($u)
            api_return_fail(REGISTER_FAILED,'该呼叫号码('.$post['callnumber'].')已存在');

        if(isset($post['avatarSrc']))
        {
            $src = $post['avatarSrc'];
            if(!$this->verifyAvartarSrc($src))
            {
                $post['avatarSrc'] = null;
            }
        }

        $ret = $this->usersModel->insert($post);
        if($ret)
        {
            sendMsgToDevice(null, 'tellDevListUpdate');
            api_return_success($this->usersModel->getUserByCallnumber($post['callnumber']));
        }
        else
            api_return_fail(REGISTER_FAILED);
    }

    /**
     * @param  $POST[]
     * @return {code=0:ok/>0:fail,msg:ErrorMsg,obj:{}}
     */
    public function modifyCallnumberInfo()
    {
        // if(!isAdmin())
        //     api_return_fail(UNAUTHORIZED);
        $post = $this->request->getPost();
        $post['passhash']   ?? $post['passhash']=md5(DEFAULT_PASSWORD);
        $post['callnumber']     ?? api_return_fail(PARAM_ERROR, '未提供呼叫号码');

        if(!callnumberVerify($post['callnumber']))
            api_return_fail(CALLNUMBER_INVALID);

        $u = $this->usersModel->getUserByCallnumber($post['callnumber']);
        if(!$u)
            api_return_fail(USERMODIFY_FAILED,'该呼叫号码('.$post['callnumber'].')用户不存在');
        $callnumber = $post['callnumber'];
        unset($post['callnumber']);

        if(isset($post['avatarSrc']))
        {
            $src = $post['avatarSrc'];
            if(!$this->verifyAvartarSrc($src))
            {
                $post['avatarSrc'] = null;
            }
        }

        $ret = $this->usersModel->update($u->uid, $post);
        if($ret)
        {
            sendMsgToDevice(null, 'tellDevListUpdate');
            api_return_success($this->usersModel->getUserByCallnumber($callnumber));
        }
        else
            api_return_fail(USERMODIFY_FAILED);
    }

 
    /**
     * @param  $POST[]
     * @return {code=0:ok/>0:fail,msg:ErrorMsg,obj:{}}
     */
    public function deregisterCallnumber()
    {
        $callnumber = $_REQUEST['callnumber'] ?? null;
        if(!$callnumber)
            api_return_fail(PARAM_ERROR);

        $u = $this->usersModel->getUserByCallnumber($callnumber);
        if(!$u)
        {
            serverlog("deregisterCallnumber with invalid param, callnumber=$callnumber", 'warning');
            api_return_fail(USER_NOT_FOUND);
        }

        if($this->usersModel->delete($u->uid))
        {
            sendMsgToDevice(null, 'tellDevListUpdate');
            api_return_success();
        }
        else if($this->usersModel->deleteUserByCallnumber($callnumber))
            api_return_success();
        else
            api_return_fail(DEREGISTER_FAILED);
    }

    public function addUserGroup()
    {
        $ugroupName = $_POST['ugroupName'] ?? null;
        $ret = $this->ugroupmodel->insert(compact('ugroupName'));

        if($ret)
            api_return_success();
        else
            api_return_fail('fail to add group');
    }
    /**
     * @param  $POST[params]
     * @param  $POST[uid]
     * @return {code=0:ok/>0:fail,msg:ErrorMsg,obj:{}}
     */
    public function modifyUser()
    {
        if(!isAdmin() && !isLoggedIn())
            api_return_fail(UNAUTHORIZED);
    }

    /**
     * @param  $POST[uid]
     * @return {code=0:ok/>0:fail,msg:ErrorMsg,obj:{}}
     */
    public function deleteUser()
    {
        if(!isAdmin())
            api_return_fail(UNAUTHORIZED);
    }

    /**
     * @return {code=0:ok/>0:fail,msg:ErrorMsg,obj:{}}
     */
    public function listDetailedUser()
    {
        if(!isAdmin())
            api_return_fail(UNAUTHORIZED);
    }

    /**
     * @return {code=0:ok/>0:fail,msg:ErrorMsg,obj:{}}
     */
    public function listUser()
    {
        if(!isAdmin() && !isLoggedIn())
            api_return_fail(UNAUTHORIZED);
    }

    /**
     * @param  $POST[uid]
     * @return {code=0:ok/>0:fail,msg:ErrorMsg,obj:{}}
     */
    public function activateUser()
    {
        if(!isAdmin())
            api_return_fail(UNAUTHORIZED);
    }

    /**
     * @param  $POST[uid]
     * @return {code=0:ok/>0:fail,msg:ErrorMsg,obj:{}}
     */
    public function deactivateUser()
    {
        if(!isAdmin())
            api_return_fail(UNAUTHORIZED);
    }

    /**
     * @param  $POST[uid]
     * @return {code=0:ok/>0:fail,msg:ErrorMsg,obj:{}}
     */
    public function fetchCallHistoryOfAllUsers()
    {
        if(!isAdmin())
            api_return_fail(UNAUTHORIZED);
    }

    /**
     * @param  
     * @param  $POST[uid]
     * @return {code=0:ok/>0:fail,msg:ErrorMsg,obj:{}}
     */
    public function getDetailedUser()
    {
        if(!isAdmin())
            api_return_fail(UNAUTHORIZED);
    }

    /**
     * @param  $POST[uid]
     * @return {code=0:ok/>0:fail,msg:ErrorMsg,obj:{}}
     */
    public function getUser()
    {
        // if(!isAdmin() && !isLoggedIn())
            // api_return_fail(UNAUTHORIZED);
        $uid = $_REQUEST['uid'] ?? null;
        if(!$uid)
            api_return_fail(PARAM_ERROR);
        $user = $this->usersModel->getUser($uid);
        if(!$user)
        {
            serverlog("getUser with invalid param: uid=$uid", 'warning');
            api_return_fail(USER_NOT_FOUND);
        }
        api_return_success($user);
    }
    /**
     * @param  $POST[uid]
     * @return {code=0:ok/>0:fail,msg:ErrorMsg,obj:{}}
     */
    public function getUserByCallnumber()
    {
        $callnumber = $_REQUEST['callnumber'] ?? null;
        if(!$callnumber)
            api_return_fail(PARAM_ERROR);
        $user = $this->usersModel->getUserByCallnumber($callnumber);
        if(!$user)
        {
            serverlog("getUserByCallnumber with invalid param: callnumber=$callnumber", 'warning');
            api_return_fail(USER_NOT_FOUND,":$callnumber");
        }
        api_return_success($user);
    }

    /**
     * @return {code=0:ok/>0:fail,msg:ErrorMsg,obj:{}}
     */
    public function getAllUsers()
    {
        // if(!isAdmin())
            // api_return_fail(UNAUTHORIZED);
        $users = $this->usersModel->getAllUsers($sort = false);
        api_return_success($users);
    }

    /**
     * @return {code=0:ok/>0:fail,msg:ErrorMsg,obj:{}}
     */
    public function getAllUserGroups()
    {
        if(!isAdmin())
            api_return_fail(UNAUTHORIZED);
        $usergroups = $this->ugroupmodel->findAll();
        api_return_success($usergroups);
    }

    /**
     * @return {code=0:ok/>0:fail,msg:ErrorMsg,obj:{}}
     */
    public function getAllUniqs()
    {
        if(!isAdmin())
            api_return_fail(UNAUTHORIZED);
        api_return_success($this->uniqsModel->findAll());
    }


    /**
     * @return {code=0:ok/>0:fail,msg:ErrorMsg,obj:{}}
     */
    public function listDeactivatedUsers()
    {
        if(!isAdmin())
            api_return_fail(UNAUTHORIZED);
    }

    /**
     * @param  $POST[uid]
     * @return {code=0:ok/>0:fail,msg:ErrorMsg,obj:{}}
     */
    public function getCallHistoryOfUser()
    {
        if(!isAdmin() && !isLoggedIn())
            api_return_fail(UNAUTHORIZED);
    }


    /**
     * to save uniq and sessionStr
     * @param  $params[]
     * @return true=ok, false=fail, carry the sesId to let the page to save
     */
    public function login($passFree=false)
    {
        $callnumber     = $_REQUEST['callnumber'] ?? null;
        $passhash       = $_REQUEST['passhash'] ?? null;
        $uniq           = $_REQUEST['uniq'] ?? null;
        $sesId          = isset($_REQUEST['sesId']) && strlen(trim($_REQUEST['sesId']))>1 ? $_REQUEST['sesId'] : null;

        if(!$callnumber || (!$passhash && !$passFree) || !$uniq)
            api_return_fail('paramcheck failed');

        $u = $this->usersModel->getUserByCallnumber($callnumber);
        if(!$u)
        {
            serverlog("login with invalid param: callnumber=$callnumber,uniq=$uniq,sesId=$sesId", 'warning');
            api_return_fail(USER_NOT_FOUND);
        }

        $ses = $sesId ?? md5(time());

        if(!$ses || strlen($ses)<=1)
            api_return_fail('fail to save uniq');

        $uniqObj = $this->usersModel->getUniqObj($uniq);
        if($uniqObj)
        {
            if($uniqObj->uid == $u->uid)
            {
                $this->uniqsModel->update(
                    $uniqObj->uniq_idx,
                    array('sessionStr'=>$ses, 'lastAckTime'=>time()),
                    );
            }
            else
            {
                $this->uniqsModel->update(
                    $uniqObj->uniq_idx,
                    array('sessionStr'=>$ses, 'lastAckTime'=>time(), 'uid'=>$u->uid)
                    );
            }
                $this->usersModel->setOnline($u->uid);
                \Config\Services::session()->set('uid',$u->uid);
                api_return_success(['uid'=>$u->uid,'uname'=>$u->uname,'callnumber'=>$u->callnumber, 'sesId'=>$ses]);
        }

        if(!$passFree && $passhash != $u->passhash)
        {
            serverlog("login with invalid password, uid={$u->uid}", 'warning');
            api_return_fail(WRONG_PASSWORD);
        }
        $params = ['uid'=>$u->uid,'uniq'=>$uniq,'lastAckTime'=>time(),'sessionStr'=>$ses];
        $r = $this->uniqsModel->insert($params);
        if($r)
        {
            $this->usersModel->setOnline($u->uid);
            api_return_success(['uid'=>$u->uid,'uname'=>$u->uname,'callnumber'=>$u->callnumber, 'sesId'=>$ses]);
        }
        else
            api_return_fail('fail to save uniq');
    }

public function api_loginWithParameter()
{
    return $this->login(true);
}

    /**
     * un-related with call UI
     * */
    public function commonLogin()
    {
        $callnumber = $_POST['callnumber'] ?? null;
        $passhash = $_POST['passhash'] ?? null;
        $commonSesId = $_POST['commonSesId'] ?? md5(time());
        $u = $this->usersModel->getUserByCallnumber($callnumber);
        if(!$u)
        {
            serverlog("commonLogin with invalid param: callnumber=$callnumber,commonSesId=$commonSesId", 'warning');
            api_return_fail(USER_NOT_FOUND);
        }

        if($u->passhash != $passhash)
        {
            api_return_fail(WRONG_PASSWORD);
        }
        else
        {
            $u->commonSesId = $commonSesId;
            $u_logged = $this->usersModel->getMe($commonSesId);
            if($u_logged && $u_logged->uid != $u->uid)
            {
                api_return_fail(PARAM_ERROR,"已经在呼叫页面登录为另一用户，请先从呼叫页面退出登录");
            }
            else
            {
                \Config\Services::session()->set('uid', $u->uid);
                api_return_success();
            }
        }
    }
    public function commonLogout()
    {
        \Config\Services::session()->set('uid', null);
        api_return_success();
    }

    public function api_getCallLogs()
    {
       $sesId = isset($_REQUEST['sesId']) && strlen(trim($_REQUEST['sesId']))>1 ? $_REQUEST['sesId'] : null;
        if(!$sesId)
            api_return_fail(NEED_LOGIN);
        $u = $this->usersModel->getMe($sesId);
        $logs = $this->callLogsModel->getCallLogsOfUid($u->uid, SIDE_BOTH, true);
        api_return_success($logs);
    }
}
