<?php

namespace App\Controllers;

class Server extends BaseController
{
    public function index(): string
    {
        return view('client_view');
    }

    public function test(){
            api_return_success();
    }

    public function api_notifyPeer()
    {
        $url = $_POST['url'];
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
        curl_setopt($ch, CURLOPT_TIMEOUT,1);
        $o = curl_exec($ch);
        // print_r($o);
        if(!$o)
        {
            api_return_fail('fail to visit');
        }
        $j = json_decode($o) ?? null;
        if(!$j)
            api_return_fail('fail to decode');
        if(property_exists($j, 'code') && ((int)$j->code)==1)
            api_return_success($j);
        else
            api_return_fail('got a fail code', "$o");
    }
}
