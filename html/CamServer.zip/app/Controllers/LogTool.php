<?php

namespace App\Controllers;

class LogTool extends BaseController
{
    public function postLog()
    {
        // print_r($_POST);
        $logs = $_POST['msgBuf'];
        $uniq = $_POST['uniq'] ?? 0;

        $s = "";
        $sfull = "";
        foreach ($logs as &$l) {
            $s = "$s$l\n";
            $sfull = "$sfull$uniq :: $l\n";
        }
        if($uniq)
        file_put_contents("/usr/share/nginx/html/logs/clientlogs/$uniq",$s , FILE_APPEND);
        $date = date("Y-m-d");
        file_put_contents("/usr/share/nginx/html/logs/clientlogs/$date.log", $sfull, FILE_APPEND);
        result(SUCCESS,null);
    }

}
