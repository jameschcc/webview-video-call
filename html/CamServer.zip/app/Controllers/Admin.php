<?php

namespace App\Controllers;

class Admin extends BaseController
{
    public function index(): string
    {
        return view('manage/head').
        view('welcome_message').
        view('manage/foot');
    }

    public function db_manage(): string
    {
        if(!isAdmin())
        {
            return $this->need_admin();
        }
        return view('manage/head').
        view('manage/db_manage').
        view('manage/foot');
    }

    public function user_manage(): string
    {
        if(!isAdmin())
        {
            return $this->need_admin();
        }
        return view('manage/head').
        view('manage/user_manage').
        view('manage/foot');
    }
    public function group_manage(): string
    {
        if(!isAdmin())
        {
            return $this->need_admin();
        }
        return view('manage/head').
        view('manage/group_manage').
        view('manage/foot');
    }

    public function need_admin(): string
    {
        return view('manage/head').
        view('common/need_admin').
        view('manage/foot');
    }

    public function readlog(): string
    {
        header('Content-Type: text/plain');
        // return view('manage/head').
        // view('manage/readlog').
        return view('manage/readlog');
        // view('manage/foot');
    }
}
