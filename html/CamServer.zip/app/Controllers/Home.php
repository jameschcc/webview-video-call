<?php

namespace App\Controllers;

class Home extends BaseController
{
    public function index(): string
    {
        return view('manage/head').
        view('welcome_message').
        view('manage/foot');
    }

    public function login(): string
    {

    }

    public function dashboard(): string
    {
    }
}
