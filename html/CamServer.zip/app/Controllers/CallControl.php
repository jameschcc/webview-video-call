<?php
namespace App\Controllers;

use Config\Services;
define('MAX_OFFLINE_TIME', 60);         // 60s lost ack means offline

class CallControl extends BaseController
{
    public function __construct()
    {
        $this->usersModel = new \App\Models\UsersModel(); 
        $this->callsModel = new \App\Models\CallsModel();
        $this->uniqsModel = new \App\Models\UniqsModel();
        $this->callLogsModel = new \App\Models\CallLogsModel();

        $this->session = \Config\Services::session();
    }

    public function index()
    {
    }

    public function createTables(){
        global $db;
        $ret=$db->exec('create table if not exists calls (callId INTEGER primary key auto_increment, cguniq integer, cguniq integer, calltype integer, sdpOffer text default null, sdpAnswer text default null, parentCallId integer, timestamp integer, period integer);');
        if(!$ret){
            echo $db->lastErrorMsg();
        } else {
            echo "Records created successfully\n";
        }
    }

    public function cleanSdps()
    {
    // todo : remove sdps from db
    }

    public function exceptionHandler(Throwable $exception)
    {
        logger()->log('info', $message, $context);
    }

    private function getMyCalls($sesId)
    {
        $uniq    = $this->usersModel->getMyUniq($sesId);
        return $this->callsModel->getCallsOfUniq($uniq);
    }

    public function api_fetchusers()
    {
        return api_return_success($this->usersModel->getAllUsers());
    }

    public function getAllCalls()
    {
        if(!isAdmin())
            api_return_fail(UNAUTHORIZED);
        api_return_success($this->callsModel->findAll());
    }

    /**
     * @return      {call} if its the uid's
     *              null if not found or not the uid's
     */
    private function guardCall($callId, $sesId)
    {
        $uniq    = $this->usersModel->getMyUniq($sesId);
        if(!$uniq)
            return null;

        $c      = $this->callsModel->getCall($callId);
        if(!$c || !$uniq || ($c->cguniq != $uniq && $c->cduniq != $uniq))
            return null;
        else return $c;
    }


    /**
     * 1. if myUniq=0 or myUid=0 return fail
     * 2. if calledUid=0 return fail
     * 3. if found no uniq for uid, retur fail
     * 4. if uid = cduid, return fail
     * 5. if no offer, return fail
     * 6. create call, return fail if not created
     * 7. send msg to called user's uniq, if fail to send msg, return fail
     * 8. return success
     * */
    public function  api_startCall()
    {
        $sesId = isset($_REQUEST['sesId']) && strlen(trim($_REQUEST['sesId']))>1 ? $_REQUEST['sesId'] : null;

        // 1
        $uq = $this->usersModel->getMyUniqObj($sesId);
        if(!$uq || !$uq->uid)
            result(NEED_LOGIN);
        $myUniq = $uq->uniq;
        if(!$myUniq)
            result(CALL_ERROR, 'invalid uniq.');
        $myUid = $uq->uid;

        // 2
        $calledUid = $_REQUEST['calledUid'] ?? null;
        if(!$calledUid)
            result(COMMON_ERROR, '没有被叫方');

        // 3
        $cd_uq = $this->usersModel->getUniqObjOfUser($calledUid);
        if(!$cd_uq || !$cd_uq->uid)
        {
            if($GLOBALS['camsrvConfigs']['enableOfflineCalled']??false)
            {
                $cd_uq = (object)['uniq'=>null];
            }
            else
                result(COMMON_ERROR, '被叫方无效');
        }
        // $cd_u = $this->usersModel->getUser($cd_uq->uid);
        $cd_u = $this->usersModel->getUser($calledUid);
        $calledUniq = $cd_uq->uniq;

        // 4
        if($calledUid == $myUniq)
            result(CALL_ERROR, 'you cannot call yourself.');

        // 5
        $offer = $_REQUEST['offer']??null;
        if(!$offer)
            result(CALL_ERROR, 'no offer provided.');

        // 6
        $offer = trim($offer);
        $c = $this->callsModel->createCall(
            array('cduniq'=>$calledUniq, 'cguniq'=>$myUniq, 'sdpOffer'=>$_REQUEST['offer']??null, 'calltype'=>$_REQUEST['calltype']??0, 'timestamp'=>time())
        );
        if(!$c)
            result(CALL_ERROR, 'fail to generate call');
        $callId = $c->callId;
        $this->callLogsModel->createCallLog(['timestamp'=>$c->timestamp, 'cguid'=>$myUid, 'cduid'=>$cd_u->uid, 'callId'=>$c->callId]);

        // 7
        if(!$calledUniq || !sendMsgToDevice($calledUniq, 'tellRing', array('callId'=>$c->callId)))
        {
            if(getCfg('enableOfflineCalled')??false)
            {
                $this->callsModel->setCdUid($callId, $calledUid);
                result(SUCCESS,null,array('callId'=>$c->callId, 'calledUserObj'=>$cd_u));
            }
            result(SOCKET_ERROR,  "fail to notify uniq=$calledUniq");
        }

        // 8
        $calledUserObj = $this->usersModel->getUserThroughUniq($c->cduniq);
        result(SUCCESS,null,array('callId'=>$c->callId, 'calledUserObj'=>$calledUserObj));
    }

    public function api_answerCall()
    {
        $callId = $_REQUEST['callId'] ?? null;
        $sesId = isset($_REQUEST['sesId']) && strlen(trim($_REQUEST['sesId']))>1 ? $_REQUEST['sesId'] : null;

        if(!array_key_exists('answer',$_REQUEST))
            result(CALL_ERROR, 'no answer provided.');
        $c = $this->guardCall($callId,$sesId);
        if(!$c)
            result(CALL_ERROR, 'call not found or you are not callee.');
        $this->callsModel->modifyCall(array('sdpAnswer'=>$_REQUEST['answer']), $c->callId);
        if(sendMsgToDevice($c->cguniq, 'tellAnswer', array('callId'=>$c->callId)))
            result(SUCCESS,null,array('callId'=>$c->callId));
        else
            result(SOCKET_ERROR,  "fail to notify uniq=$calledUniq");
    }

    private function getCandidateFileName($callId, $myUniq, $appendix=0)
    {
        return "candidates-$callId-$myUniq-$appendix.json";
    }
    private function getCandidateFilePath($callId, $myUniq, $appendix=0)
    {
        return  WRITEPATH."/candidates/".$this->getCandidateFileName($callId, $myUniq, $appendix);
    }

    public function api_updateCandidate()
    {
        $callId = $_REQUEST['callId'] ?? null;
        $sesId = isset($_REQUEST['sesId']) && strlen(trim($_REQUEST['sesId']))>1 ? $_REQUEST['sesId'] : null;

        $c = $this->callsModel->getCall($callId);
        if(!$c)
            result(CALL_ERROR, 'call not found, callId='.$callId);
        $candidatesJson = $_REQUEST['candidatesJson'] ?? null;
        if(!$candidatesJson || !is_string($candidatesJson))
        {
            result(CALL_ERROR, 'api_updateCandidate: candidates not provided');
        }
        $myUniq = $this->usersModel->getMyUniq($sesId);
        $appendix = 0;
        $fname = $this->getCandidateFileName($callId, $myUniq, $appendix);
        $f = $this->getCandidateFilePath($callId, $myUniq, $appendix);
        if(file_exists($f))
        {
            while(file_exists($this->getCandidateFilePath($callId, $myUniq, ++$appendix)))
            {
                ;
            }
            $fname = $this->getCandidateFileName($callId, $myUniq, $appendix);
            $f = $this->getCandidateFilePath($callId, $myUniq, $appendix);
        }
        file_put_contents($f, $candidatesJson);
        $toUniq = $c->cguniq==$myUniq ? $c->cduniq : $c->cguniq;
        sendMsgToDevice($toUniq, 'tellCandidates', array('callId'=>$callId, 'candidates'=>$fname));
        result(SUCCESS, null, compact('fname'));
    }


    public function api_getOffer()
    {
        $sesId = isset($_REQUEST['sesId']) && strlen(trim($_REQUEST['sesId']))>1 ? $_REQUEST['sesId'] : null;

        $callId = $_REQUEST['callId'] ?? null;
        $c = $this->guardCall($callId,$sesId);
        if($c)
        {
            $callingUserObj = $this->usersModel->getUserThroughUniq($c->cguniq);
            result(0, null, array('offer'=>$c->sdpOffer, 'callingUserObj'=>$callingUserObj, 'calltype'=>(int)$c->calltype));
        }
        else
            result(CALL_ERROR, 'api_getOffer: call not found or you are not callee');
    }
    public function api_getAnswer()
    {
        $callId = $_REQUEST['callId'] ?? null;
        $sesId = isset($_REQUEST['sesId']) && strlen(trim($_REQUEST['sesId']))>1 ? $_REQUEST['sesId'] : null;


        $c = $this->guardCall($callId, $sesId);
        if($c)
            result(0, null, array('answer'=>$c->sdpAnswer));
        else
            result(CALL_ERROR, 'api_getAnswer: call not found or you are not callee');
    }

    public function api_heartbeat()
    {
        $sesId = isset($_REQUEST['sesId']) && strlen(trim($_REQUEST['sesId']))>1 ? $_REQUEST['sesId'] : null;

        $u = $this->usersModel->getMe($sesId);
        if(!$u)
        {
            serverlog("$action: user not found.");
        }
        // to be done
    }
    public function api_auditack()
    {
        $sesId = isset($_REQUEST['sesId']) && strlen(trim($_REQUEST['sesId']))>1 ? $_REQUEST['sesId'] : null;

        $u = $this->usersModel->getMe($sesId);
        if(!$u)
        {
            serverlog("$action: user not found.");
        }
        // to be done
    }


    public function api_reject()
    {
        $callId = $_REQUEST['callId']??0;
        $sesId = isset($_REQUEST['sesId']) && strlen(trim($_REQUEST['sesId']))>1 ? $_REQUEST['sesId'] : null;

        $c = $this->guardCall($callId,$sesId);
        if(!$c)
            result(CALL_ERROR, 'api_reject: call not found or you are not caller/callee');
        else
            sendMsgToDevice($c->cguniq, 'tellReject', array('callId'=>$c->callId));
    }

    /**
     * @brief tell the other side call ends
     * @param $notifyPeer : 1:tell other side & clean call info, 0:just clean
     * */
    public function api_callEnd()
    {
        $sesId = isset($_REQUEST['sesId']) && strlen(trim($_REQUEST['sesId']))>1 ? $_REQUEST['sesId'] : null;
        $notifyPeer = isset($_REQUEST['notifyPeer']) ? $_REQUEST['notifyPeer'] : true;

        if(!$sesId)
            api_return_fail(NEED_LOGIN);

        // 1. update devicelist and broadcast
        $callId = $_REQUEST['callId'] ?? null;
        $c = $this->callsModel->getCall($callId);
        if(!$c)
            result(SUCCESS, 'call already cleared');
        $u = $this->usersModel->getMe($sesId);

        if(!$u)
            result(PERMISSION_ERROR, 'devices mismatch'.json_encode(['sesId'=>$sesId,'callId'=>$callId,'u'=>$u]));
        if($notifyPeer)
        {            
            if($c->cguniq == $u->uniq )
                sendMsgToDevice($c->cduniq, 'tellCallClear', array('callId'=>$c->callId));
            elseif($c->cduniq == $u->uniq)
                sendMsgToDevice($c->cguniq, 'tellCallClear', array('callId'=>$c->callId));
        }

        // update callLog history
        if($c->sdpAnswer)
        {
            $period = time() - $c->timestamp;
        // $callLog = $this->callLogsModel->getCallLog($callId);
        // if($callLog)
            $this->callLogsModel->updatePeriod($callId, $period);
        }

        $this->callsModel->delete($callId);
        result(SUCCESS, 'call clear msg sent');
    }

    public function api_releaseComplete()
    {
        $sesId = isset($_REQUEST['sesId']) && strlen(trim($_REQUEST['sesId']))>1 ? $_REQUEST['sesId'] : null;

        if(!$sesId)
            api_return_fail(NEED_LOGIN);
        $callId = $_REQUEST['callId'] ?? null;
        $c = $this->callsModel->getCall($callId);
        if(!$c)
            result(SUCCESS, 'call already cleared');
        $u = $this->usersModel->getMe($sesId);
        if(!$u)
            result(PERMISSION_ERROR, 'devices mismatch'.json_encode(['sesId'=>$sesId,'callId'=>$callId,'u'=>$u]));
        if($c->cduid == $u->uid)
        {
            $c->cduid = null;
            $this->callsModel->setCdUid($callId,null);
        }
        if($c->cduniq == $u->uniq)
        {
            $c->cduniq = null;
            $this->callsModel->setCdUniq($callId,null);
        }
        if($c->cguniq == $u->uniq)
        {
            $c->cguniq = null;
            $this->callsModel->setCgUniq(null);
        }
        if(is_null($c->cduid) && is_null($c->cduniq) && is_null($c->cguniq))
        {
            $this->callsModel->delete($callId);
        }

        if(getCfg('enableOfflineCalled') === true)
        {
            $this->dispatchNextCallRing($u->uid, $u->uniq);
        }
        result(SUCCESS, 'call already cleared');
    }

    public function inapi_fetchConnStates()
    {
        $r = $this->fetchConnStates();
        if($r == 2)
            sendMsgToDevice(null, 'tellDevListUpdate');
    }


    private function abolishUniq(string $uniq)
    {
        if(!$uniq)
            return false;
        $u = $this->usersModel->getUniqObj($uniq);
        $calls = $this->callsModel->getCallsOfUniq($uniq);
        foreach ($calls as $c) {
            $callId = $c->callId;
            if($c->cduniq==$uniq)
            {
                if(getCfg('enableOfflineCalled') === true)
                {
                    $this->callsModel->setCdUid($callId,$u->uid);
                }
                else
                {
                    sendMsgToDevice($c->cguniq, 'tellCallClear',array('callId'=>$c->callId));
                    sendMsgToDevice($c->cduniq, 'tellCallClear',array('callId'=>$c->callId));
                    $this->callsModel->delete($c->callId);
                }
            }
            else
            {
                sendMsgToDevice($c->cguniq, 'tellCallClear',array('callId'=>$c->callId));
                sendMsgToDevice($c->cduniq, 'tellCallClear',array('callId'=>$c->callId));
                $this->callsModel->delete($c->callId);
            }
        }
        $this->uniqsModel->delete($u->uniq_idx);
        sendMsgToDevice($uniq, 'disconnect');
    }


    public function dispatchNextCallRing($cdUid, $cdUniq)
    {
        if(getCfg('enableOfflineCalled') === true)
        {
            $calls = $this->callsModel->getCallJobssOfUiq($cdUid);
            if($calls)
            {
                $callId = $calls[0]->callId;
                $this->callsModel->setCdUniq($callId, $cdUniq);
                sendMsgToDevice($cdUniq, 'tellRing', array('callId'=>$callId));
            }
        }
    }
    /**
     * this method is called when a client page is first opened.
     * here we would detect the uniq+sess+uid from uniqs
     * Steps:
     * 1. if uniq is not provided, return fail
     * 2. if not logged in (find with session), return fail to log in (where we'll save uniq+session+uid)
     * 3. find samesession uniqs, if found, means firstload or page refresh
     *      - if uniq = this uniq, return true 
     *      - else
     *          - disconnect other uniqs's socket and clear their related calls
     *          - and save this one.
     * 4. find same uid uniqs, if found, means multi-login,
     *      - do same as above
     * 5. save the new one.
     * 6. return success
     * 7. if has called job, notify the device
     * */
    public function api_registerUniq()
    {
        // 0.
        $sesId = isset($_REQUEST['sesId']) && strlen(trim($_REQUEST['sesId']))>1 ? $_REQUEST['sesId'] : null;

        if(!$sesId)
        {
            $sesId = md5(time());
        }

        // 1.
        $uniq = $_REQUEST['uniq'] ?? null;
        if(!$uniq)
            result(USER_ERROR, 'no uniq provided.');

        // 2.
        $uniqObjs = $this->usersModel->findSameSessionUniqObjs($sesId);
        if(!$uniqObjs)
            api_return_fail(NEED_LOGIN);

        // 3.
        $found_idx = -1; $uid = 0;
        foreach ($uniqObjs as $k => $u) {
            if($u->uniq != $uniq)
                $this->abolishUniq($u->uniq);
            else
                $found_idx = $k;
            if($uid == 0)
                $uid = $u->uid;
        }
        if(!$uid)
            api_return_fail(NEED_LOGIN);

        // 4.
        $uniqObjs2 = $this->usersModel->getAllUniqObjOfUser($uid);
            // print_r($uniqObjs2);
        if($uniqObjs2)
        {
            foreach ($uniqObjs2 as $k => $u) {
                if($u->uniq != $uniq)
                    $this->abolishUniq($u->uniq);
            }
        }

        // 5.
        if($found_idx !== -1)
        {
            $this->usersModel->setOnline($uniqObjs[$found_idx]->uid);
            sendMsgToDevice(null, 'tellDevListUpdate');
            $uObj = $uniqObjs[$found_idx];
            $uObj->userObj = $this->usersModel->getUser($uid);
            $uObj->sesId = $sesId;
            if(getCfg('enableOfflineCalled') === true)
                $this->dispatchNextCallRing($uid, $uniq);
            api_return_success($uObj);
        }

        // 6.
        $ses = $sesId;
        $uqRes = $this->usersModel->insertUniq($uniq, $uid, $ses);
        if(!$uqRes)
            api_return_fail('fail to save uniq');
        else
        {
            $this->usersModel->setOnline($uid);
            sendMsgToDevice(null, 'tellDevListUpdate');
            $uObj = $this->usersModel->getUniqObj($uniq);
            $uObj->userObj = $this->usersModel->getUser($uid);
            $uObj->sesId = $sesId;
            if(!getCfg('enableOfflineCalled'))
                api_return_success($uObj);
        }

        // 7.
        if(getCfg('enableOfflineCalled') === true)
        {
            $this->dispatchNextCallRing($uid, $uniq);
        }
        api_return_success($uObj);



        return;
        // end
        // 
        // 

        if(!$this->usersModel->getMe($sesId) && !$this->usersModel->findSameSessionUniqObjs($sesId))
        {
            if($this->usersModel->insertUniq($uniq, 0, $ses))
            {
                $this->fetchConnStates();
                sendMsgToDevice(null, 'tellDevListUpdate');
                result(0);
            }
            else
                result(DB_ERROR, 'device register failed');
        }
        else
        {
            // user already exists
            $calls = $this->getMyCalls($sesId);
            $otherLoginedUniqs = $this->usersModel->findSameSessionUniqObjs();
            serverlog('Got my current logins: '.json_encode($otherLoginedUniqs));
            $othermyUniqs = array();
            foreach($otherLoginedUniqs as $l)
                array_push($othermyUniqs, $l->uniq);
            if($calls)
            {
                if(isset($_REQUEST['force']))
                {
                // tobedone: 1.cancel all calls, 2.disconnect old socket, 3.bind new uniq
                    $calls = getSessionCalls($sesId);
                    $uniqsToDisconnect = array();
                    $uniqsToClearCall = array();
                    if($calls)
                    {
                        foreach ($calls as $c) {
                            foreach(array($c->cguniq, $c->cduid) as $u) {
                            // print_r($u.'\n');
                                if(in_array($u,$othermyUniqs))
                                    array_push($uniqsToDisconnect, $u);
                                else
                                    array_push($uniqsToClearCall, $u);
                            }
                            serverlog('uniqsToDisconnect'.json_encode($uniqsToDisconnect));
                            foreach($uniqsToDisconnect as $u)
                            {
                                sendMsgToDevice($u, 'disconnect');
                                deleteDevice($u);                            
                            }
                            foreach($uniqsToClearCall as $u)
                            {
                                sendMsgToDevice($c->cguniq, 'tellCallClear',array('callId'=>$c->callId));
                            }
                            $this->callsModel->delete($c->callId);
                        }
                    }
                    $this->usersModel->insertUniq($uniq, $uid, $ses);
                    $this->fetchConnStates();
                    sendMsgToDevice(null, 'tellDevListUpdate');
                    result(0, 'all other calls of this session have been released');
                }
                else
                    result(MULTILOGIN_ERROR, 'multi login. reject.');
            }
            else
            {
                // disconnect other logins, and accept this one.
                $userDeleted = false;
                if($otherLoginedUniqs)
                {
                    serverlog('otherLoginedUniqs ToDisconnect'.json_encode($otherLoginedUniqs));

                    foreach($otherLoginedUniqs as $r)
                    {
                        serverlog("api_registerUniq: sending disconnect to old uniq={$r->uniq}.");
                        if(!sendMsgToDevice($r->uniq,'disconnect'))
                            serverlog("api_registerUniq: send disconnect to old uniq={$r->uniq} failed. directly removed.");
                        $this->deleteDevice($r->uniq);
                    }
                    $this->usersModel->insertUniq($uniq, $uid, $ses);
                    $this->fetchConnStates();
                    sendMsgToDevice(null, 'tellDevListUpdate');
                    result(0,'other logins have been disconnectted');
                }
            }
        }
    }




    // returns: true if deleted or no this call
    //          false if delete failed
/*    function deleteCall($callId)
    {
        if(!$callId or trim('callId')=='')
            return true;
        if(!is_integer($callId))
            return false;
        $c = $this->callsModel->getCall($callId);
        if(!$c)
            return true;
        return $this->callsModel->query('delete from calls where callId='.$callId);
    }*/

/*    function deleteDevice($uniq)
    {
        if(!$uniq or trim('uniq')=='')
            return true;
        if(!is_string($uniq))
            return false;
        $d = getUser($uniq);
    // print_r($d);
        if(!$d)
            return true;
        $GLOBALS['db']->exec("delete from devices where uniq='{$uniq}'");
        return $GLOBALS['db']->changes() ? true : false;
    }
*/

    ///////
    // fetchConnStates
    // :: to update the devices state in table
    // :: returns : 0 if fail, 1 if ok (not changed), 2 if need to notify(some changed)
    function fetchConnStates()
    {
        $ch = curl_init();

        curl_setopt($ch, CURLOPT_URL, 'http://localhost:2121?action=getDevicesStatus');
        curl_setopt($ch, CURLOPT_RETURNTRANSFER,true);
        curl_setopt($ch, CURLOPT_TIMEOUT,2);
        $o = curl_exec($ch);
        if(!$o)
        {
            return 0;
        }
        $j = json_decode($o) ?? null;
        if(!$j)
            return 0;

        $onlineUniqObjs = $j->rslt ?? null;
        if(!is_object($onlineUniqObjs))
            return 0;

        $onlineUniqs  = array_keys((array)$onlineUniqObjs);

        /* overwritten */
        $changed = false;
        $users = $this->usersModel->getAllUsers(false);
        $indexedUsers = array_column($users, null, 'uid');

        $allUniqs = $this->uniqsModel->findAll();
        $ts = time();
        foreach($allUniqs as $uq)
        {
            $uid = $uq['uid'];
            if(in_array($uq['uniq'], $onlineUniqs))
            {
                $this->uniqsModel->update($uq, ['lastAckTime'=>$ts]);
                if(array_key_exists($uid, $indexedUsers) && $indexedUsers[$uid]->ustate != 'ONLINE')
                {
                    $this->usersModel->setOnline($uid);
                    $changed = true;
                }
            }
            else
            {
                if(array_key_exists($uid, $indexedUsers) && $indexedUsers[$uid]->ustate=='ONLINE' && (time() - $uq['lastAckTime']) > MAX_OFFLINE_TIME)
                {
                    $this->usersModel->setOffline($uid);
                    $changed = true;
                }
            }
        }
        return $changed ? 2 : 1;

        /*
        $users = $this->usersModel->getAllUsers();
        $indexedUsers = array_column($users, null, 'uid');

        foreach ($allUniqs as &$uq) {
            $uq['u'] = &$indexedUsers[$uq['uid']];
        }
        foreach ($indexedUsers as &$idu) {
            $idu->visited = false;
        }

        $offlineUniqs = array();
        $offlineUids = array();
        $ts = time();

        $changed = false;
        foreach($allUniqs as $uq)
        {
            // the offline ones
            if(!in_array($uq['uniq'], $onlineUniqs))
            {
                if($uq['u']->ustate=='ONLINE' && (time() - $uq['lastAckTime']) > MAX_OFFLINE_TIME)
                {

                array_push($offlineUniqs, $uq['uniq']);
                array_push($offlineUids,  $uq['uid']);
                serverlog("uid={$uq['uid']} need to be set offline.\n");
                }
            }
            // the online ones
            else
            {
                $this->uniqsModel->update($uq, ['lastAckTime'=>$ts]);
                if($uq['u']->ustate != 'ONLINE')
                {
                    // print_r($uq);
                    serverlog("fetchConnStates: uid={$uq['u']->uid} set online.");
                    $this->usersModel->setOnline($uq['u']->uid);
                    $changed = true;
                }
            }
            $uq['u']->visited = true;
        }
        foreach ($indexedUsers as &$idu) {
            if($idu->visited == false && $idu->ustate=='ONLINE')
            {
                $this->usersModel->setOffline($idu->uid);
                $changed = true; 
            }
        }

        if(count($offlineUids))
        {
            // foreach($offlineUids as &$i) {$i = "'$i'";}
            foreach($offlineUids as &$i) 
            {
                if($uq['u']->ustate == 'ONLINE')
                {
                $this->usersModel->setOffline($i);
                $changed = true; 
                }
            } 
        }
        */
        if($changed)
            return 2;

        else
            return 1;
    }




}

