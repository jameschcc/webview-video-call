<?php
use Config\Services;
use App\Models\UsersModel;


define('SIDE_BOTH'  , 0);
define('SIDE_IC'    , 1);
define('SIDE_OG'    , 2);

define('CALLNUMBER_LENTH', 8);
define('DEFAULT_PASSWORD', 'abcde');


// Session::start();
// $session = \Config\Services::session($config);

define('SUCCESS', 0);
function api_return_success($obj=null, $extramsg=null)
{
    header ("HTTP/1.0 200 OK");
    header ("Content-Type: application/json");
    print_r(
        json_encode(
            [
                'code'=>0,
                'msg'=>$extramsg,
                'obj'=>$obj
            ]
        )
    );
    die();
}

define('COMMON_ERROR',      'common failure');
define('DB_ERROR',          'db action fail');
define('CALL_ERROR',        'common call error');
define('PERMISSION_ERROR',  'permission error');
define('UNAUTHORIZED',      'unauthorized');
define('SOCKET_ERROR',      'socket failure');
define('USER_ERROR',        'user related err');
define('MULTILOGIN_ERROR',  'multilogin error');
define('PARAM_ERROR',       'paramcheck failed');
define('NEED_LOGIN',        'need login');
define('USER_NOT_FOUND',    'user not exists');
define('WRONG_PASSWORD',    'wrong password');
define('REGISTER_FAILED',   'fail to add user');
define('USERMODIFY_FAILED', 'fail to modify user');
define('DEREGISTER_FAILED', 'fail to del user');
define('CALLNUMBER_GEN_FAILED',   'callnumber gen failed');
define('CALLNUMBER_INVALID','callnumber format invalid');

global $camsrvConfigs;
$camsrvConfigs = ['enableOfflineCalled'=> OFFLINE_CALLED];
function getCfg($type)
{
    return $GLOBALS['camsrvConfigs'][$type] ?? null;
}

/**
 *  0       success
 *  1 -9    common
 *  10-39   user related
 *  40-79   call related
 *  80-99   network related
 *  100-119   group related
 */

global $failures;
$failures = [
    1=> ['common failure'   , '错误'],
    2=> ['unauthorized'     , '未经授权的操作'],
    3=> ['admin only'       , '仅管理员可进行此操作'],
    4=> ['registered only'  , '登录后才可以执行此操作'],
    5=> ['db action fail'   , '数据库操作失败'],
    6=> ['permission error' , '权限不足'],
    7=> ['paramcheck failed', '参数检查失败'],
    8=> ['need login'       , '需要登录'],
    9=> ['wrong password'   , '密码错误'],

    10=>['user related err' , '用户信息相关问题'],
    11=>['user not exists'  , '用户无法找到'],
    12=>['user inactivated' , '此用户处于未激活的状态'],
    13=>['user busy'        , '此用户正忙'],
    14=>['user inreachable' , '无法连接到此用户'],
    15=>['user offline'     , '此用户当前不在线'],
    16=>['multilogin error' , '多点登录问题'],
    17=>['fail to add user' , '未能插入用户'],
    18=>['fail to del user' , '未能删除用户'],
    19=>['fail to save uniq', '未能更新用户状态'],
    20=>['callnumber gen failed', '未能生成呼叫号码'],
    21=>['callnumber format invalid', '呼叫号码不合规则'],
    22=>['fail to modify user','未能成功修改用户信息'],

    40=>['common call error', '呼叫相关错误'],
    41=>['rejected'         , '呼叫被拒绝'],
    42=>['call inconsistent', '呼叫状态不一致'],

    80=>['network failure'  , '网络出现问题'],
    81=>['socket failure'   , 'Socket故障'],

    90=>['fail to visit'    , '访问失败'],
    91=>['fail to decode'   , '解码失败'],
    92=>['got a fail code'  , '收到错误码'],

    100=>['fail to add group', '未能添加用户组']
];


function parseFailCode(string $s)
{
    global $failures;
    foreach($failures as $k=>$f)
    {
        if($f[0] == $s)
            return $k;
    }
    return 1;
}

function callnumberVerify($callnumber)
{
    return preg_match("/\d{".CALLNUMBER_LENTH."}/", $callnumber);
}

function api_return_fail($code=1, $extramsg=null, $obj=null, $depth=2)
{
    header ("HTTP/1.0 200 OK");
    header ("Content-Type: application/json");
    global $failures;
    if(!is_numeric($code))
        $code = parseFailCode($code);
    $f = $failures[$code]??null;
    $m = $f?$f[1]:'';
    $msg = $m.($extramsg?": $extramsg":null);
    print_r(
        json_encode(
            [
                'code'  =>  $code==0?1:$code,
                'msg'   =>  $msg,
                'obj'   =>  $obj??null
            ]
        )
    );
    serverlog($msg, 'error', $depth);
    die();
    // Services::logger()->error($m);
}

function result($code, $extramsg=null, $obj=null)
{
    return $code==0 ? api_return_success($obj, $extramsg=null) : api_return_fail($code, $extramsg, $obj, 3);
}

/**
 * @param $msg : Object or String
 * @param $level: 'warning' or 'error' or 'info' or 'debug'
 * */
function serverlog($msg, $level = 'warning', $backDepth=0)
{
    if(!is_string($msg))
        $msg = json_encode($msg);
    // $usersModel = new UsersModel();
    // $uniq = $usersModel->getMyUid();
    $line = debug_backtrace()[$backDepth]['line'];
    $file = basename(debug_backtrace()[$backDepth]['file']);
    $func = debug_backtrace()[$backDepth]['function'];
    // $trimmedMsg = "[uniq=$uniq]"." @ $file:$line $func :: ".preg_replace('/\s/', ' ', $msg);
    $trimmedMsg = "$file:$line $func :: ".preg_replace('/\s/', ' ', $msg);
    // return Services::logger()->log($level, $trimmedMsg);
    $d = date("Y-m-d");
    $t = date("H:i:j");
    $fname = "/usr/share/nginx/html/writable/logs/log-$d.log";
    $fmt = "\n$level - $t --> $trimmedMsg";
    file_put_contents($fname, $fmt, FILE_APPEND);
}

function isAdmin()
{
    return \Config\Services::session()->get('uid') == 1;
}