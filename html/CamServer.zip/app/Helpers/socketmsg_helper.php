<?php

/**
 * @param  uniq     the page to be notified
 * @param  msgtype  the MSG_ID to be identified by msg receiver
 * @param  msgObj   the obj to be sent
 * 
 * @return true     if send OK or got no response from sending thread
 *         false    sending fail or thread not working well
 **/
//////
// param msgObj: obj {uniq?, msg_type msg_or_obj, others...}
function sendMsgToDevice($uniq=0, $msgType, $msgObj = null)
{
    if(isset($msgObj['msgType']))
        unset($msgObj['uniq']);
    if(isset($msgObj['msgType']))
        unset($msgObj['uniq']);
    $curl = "curl 'localhost:2121?uniq=$uniq&action=$msgType".($msgObj?'&'. http_build_query($msgObj):'')."' -o /dev/null";
    serverlog("sendMsgToDevice uniq=$uniq, msgType=$msgType, msgObj=".json_encode($msgObj));
    // serverlog($curl);
    exec("curl --connect-timeout 1  --max-time 1 'localhost:2121?uniq=$uniq&action=$msgType".($msgObj?'&'. http_build_query($msgObj):'')."' -o - 2>/dev/null",$o,$r);

    serverlog("sendMsgToDevice to uniq=$uniq, rslt=".implode('', $o));
    $output = json_decode(implode('', $o));

    return $r==0 ? (is_object($output) ? $output->code==0 : true) : false;
}